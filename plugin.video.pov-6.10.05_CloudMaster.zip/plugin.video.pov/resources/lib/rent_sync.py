# -*- coding: utf-8 -*-
"""
Kodi Cloud Debrid Sync Engine (Auto Time-Based Key Management & Rotation)
Tự động đồng bộ API Key theo thời hạn thuê từ Cloudflare Worker.
"""
import json
import os
import ssl
import time
import urllib.parse
import urllib.request

ADDON_TYPE = 'pov'
ADDON_ID_MAP = {
    "pov": "plugin.video.pov",
    "torus": "plugin.video.torus",
    "umbrella": "plugin.video.umbrella",
}
ADDON_ID = ADDON_ID_MAP.get(ADDON_TYPE, "plugin.video.pov")
SYNC_CACHE_TTL = 20  # Kiểm tra đồng bộ nhanh mỗi 20 giây để nhận lệnh Update từ Web Admin ngay lập tức

DEFAULT_PRIMARY_SERVER = "https://phim4k-vip.trongtuanatt.workers.dev"
FALLBACK_SERVERS = [
    "https://phim4k-vip.trongtuanatt.workers.dev",
    "https://debrid-vip.trongtuanatt.workers.dev",
]
BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"


def _clean_srv(url):
    u = (url or "").strip().rstrip("/")
    for s in ("/admin/login", "/admin", "/kodi-sync", "/kodi"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u


def _get_kodi_objs():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    addon = xbmcaddon.Addon(ADDON_ID)
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    base = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    os.makedirs(profile, exist_ok=True)
    return xbmc, xbmcaddon, xbmcgui, xbmcvfs, addon, profile, base


def _load_config(profile, base):
    cfg = {"server_url": DEFAULT_PRIMARY_SERVER, "customer_code": ""}
    preset_path = os.path.join(base, "debrid_cloud_config.json")
    if os.path.exists(preset_path):
        try:
            with open(preset_path, "r", encoding="utf-8") as f:
                p = json.load(f)
                if p.get("server_url"):
                    cfg["server_url"] = p["server_url"]
                if p.get("customer_code"):
                    cfg["customer_code"] = p["customer_code"]
        except Exception:
            pass
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    if os.path.exists(user_path):
        try:
            with open(user_path, "r", encoding="utf-8") as f:
                u = json.load(f)
                if u.get("server_url"):
                    cfg["server_url"] = u["server_url"]
                if "customer_code" in u and u["customer_code"]:
                    cfg["customer_code"] = u["customer_code"]
                if "last_state" in u and isinstance(u["last_state"], dict):
                    cfg["last_state"] = u["last_state"]
        except Exception:
            pass
    # Nếu cấu hình cũ đang trỏ vào debrid-vip mà chưa kích hoạt thành công, ưu tiên phim4k-vip trước
    cleaned = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    cfg["server_url"] = cleaned
    return cfg


def _save_user_config(profile, server_url, customer_code, last_state=None):
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    data = {"server_url": _clean_srv(server_url) or DEFAULT_PRIMARY_SERVER, "customer_code": customer_code.strip().lower()}
    if last_state is not None:
        data["last_state"] = last_state
    try:
        with open(user_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_customer_code():
    try:
        _, _, _, _, _, profile, base = _get_kodi_objs()
        cfg = _load_config(profile, base)
        return (cfg.get("customer_code") or "").strip()
    except Exception:
        return ""


def _http_get_json(url, timeout=10):
    """Gửi request tới Cloudflare Worker với User-Agent trình duyệt (tránh lỗi 403/1010) và bỏ qua lỗi chứng chỉ SSL trên Android TV Box cũ."""
    headers = {"User-Agent": BROWSER_UA, "Accept": "application/json"}
    # Ưu tiên 1: Dùng thư viện requests của Kodi nếu có
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout)
        return r.json()
    except Exception:
        pass
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout, verify=False)
        return r.json()
    except Exception:
        pass

    # Ưu tiên 2: Dùng urllib với SSL Context không kiểm tra chứng chỉ (chống lỗi SSL trên Android Box)
    req = urllib.request.Request(url, headers=headers)
    try:
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))


def _fetch_sync_with_fallback(primary_server, customer_code, report_dead=False):
    """Tự động thử Server chính và các Server dự phòng nếu khách nằm ở Worker mới (phim4k-vip) hoặc Worker cũ (debrid-vip)."""
    q = urllib.parse.urlencode({
        "user": customer_code,
        "addon": ADDON_TYPE,
        "report_dead": "1" if report_dead else "0",
    })
    candidates = []
    for srv in [primary_server] + FALLBACK_SERVERS:
        c = _clean_srv(srv)
        if c and c not in candidates:
            candidates.append(c)

    last_data = None
    used_server = primary_server
    last_err = None

    for srv in candidates:
        url = f"{srv}/kodi-sync?{q}"
        try:
            data = _http_get_json(url, timeout=10)
            if isinstance(data, dict):
                last_data = data
                used_server = srv
                # Nếu tìm thấy tài khoản (dù còn hạn, hết hạn hay bị khóa) thì dừng ngay tại Server này
                if data.get("status") != "invalid_user":
                    return data, srv, None
        except Exception as exc:
            last_err = exc

    return last_data, used_server, last_err


def _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=False):
    """Ghi hoặc thu hồi (xóa trắng) API Key trên từng loại Addon."""
    tb = (keys_map.get("torbox") or "").strip()
    rd = (keys_map.get("realdebrid") or "").strip()
    ad = (keys_map.get("alldebrid") or "").strip()
    pm = (keys_map.get("premiumize") or "").strip()
    oc = (keys_map.get("offcloud") or "").strip()

    if ADDON_TYPE == "pov":
        pairs = [
            ("tb.token", tb), ("tb.enabled", "true" if tb else "false"),
            ("rd.token", rd), ("rd.enabled", "true" if rd else "false"),
            ("ad.token", ad), ("ad.enabled", "true" if ad else "false"),
            ("pm.token", pm), ("pm.enabled", "true" if pm else "false"),
            ("oc.token", oc), ("oc.enabled", "true" if oc else "false"),
            ("subtitles.subs_action", "1"),
            ("subtitles.language", "Vietnamese"),
            ("subtitles.auto_enable", "true"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("pov_settings")
            try:
                from modules import kodi_utils
                kodi_utils.make_settings_dict()
            except Exception:
                pass

    elif ADDON_TYPE == "torus":
        # Hỗ trợ cả TorBox lẫn tài khoản đa dịch vụ (Real-Debrid, AllDebrid, Premiumize, Offcloud) trên Torus!
        any_tok = tb or rd or ad or pm or oc
        if force_write or addon.getSetting("torbox_api_key") != any_tok:
            addon.setSetting("torbox_api_key", any_tok)
        tok_file = os.path.join(profile, "torbox_token.json")
        if any_tok:
            try:
                with open(tok_file, "w", encoding="utf-8") as f:
                    json.dump({
                        "token": any_tok,
                        "torbox": tb,
                        "realdebrid": rd,
                        "alldebrid": ad,
                        "premiumize": pm,
                        "offcloud": oc,
                    }, f)
            except Exception:
                pass
        else:
            try:
                if os.path.exists(tok_file):
                    os.remove(tok_file)
            except Exception:
                pass

    elif ADDON_TYPE == "umbrella":
        pairs = [
            ("torboxtoken", tb), ("torbox.enable", "true" if tb else "false"),
            ("realdebridtoken", rd), ("realdebrid.enable", "true" if rd else "false"),
            ("alldebridtoken", ad), ("alldebrid.enable", "true" if ad else "false"),
            ("premiumizetoken", pm), ("premiumize.enable", "true" if pm else "false"),
            ("offcloudtoken", oc), ("offcloud.enable", "true" if oc else "false"),
            ("subtitles", "true"),
            ("subtitles.lang.1", "Vietnamese"),
            ("subtitles.utf", "true"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("umbrella_settings")


def sync_now(force=False, interactive=False, force_rotate=False, report_dead=False):
    """Đồng bộ API key với Cloudflare Worker (Zero-Scan mặc định, tự động báo thay Key khi phát hiện Key Die)."""
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    win = xbmcgui.Window(10000)
    prop_ts = f"{ADDON_ID}.rent_sync_ts"
    now = time.time()

    if not force and not interactive and not force_rotate and not report_dead:
        last_ts = float(win.getProperty(prop_ts) or "0")
        if now - last_ts < SYNC_CACHE_TTL:
            return True

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    customer_code = (cfg.get("customer_code") or "").strip().lower()
    prev_state = cfg.get("last_state") if isinstance(cfg.get("last_state"), dict) else {}
    prev_ver = str(prev_state.get("version") or "")
    prev_keys = prev_state.get("keys") if isinstance(prev_state.get("keys"), dict) else {}

    if not customer_code:
        if interactive:
            return prompt_and_activate()
        return False

    data, active_srv, err = _fetch_sync_with_fallback(
        server_url,
        customer_code,
        report_dead=bool(report_dead or interactive),
    )

    if not isinstance(data, dict):
        if interactive:
            xbmcgui.Dialog().ok(
                "Lỗi kết nối Server",
                f"Không thể kết nối tới Server quản lý ({server_url}) - Chi tiết: {err}",
            )
        return False

    server_url = active_srv
    win.setProperty(prop_ts, str(now))
    keys_map = data.get("keys") or {}
    ok = bool(data.get("ok"))
    status = data.get("status") or ""
    msg = data.get("message") or ""
    warn = data.get("warning") or ""
    new_ver = str(data.get("version") or "")
    days_left = data.get("days_left", "")
    auto_rotated = bool(data.get("auto_rotated"))
    keys_changed = bool(prev_keys and keys_map != prev_keys)
    version_changed = bool(new_ver and prev_ver and new_ver != prev_ver)

    if ok:
        _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=(version_changed or keys_changed or auto_rotated or interactive))
        _save_user_config(profile, server_url, customer_code, last_state=data)
        warn_prop = f"{ADDON_ID}.warn_shown"
        if not warn or version_changed:
            win.clearProperty(warn_prop)
        if interactive:
            xbmcgui.Dialog().ok("Kích hoạt VIP Debrid thành công", msg)
        elif auto_rotated or keys_changed:
            xbmcgui.Dialog().notification(
                "Đã tự động thay Key VIP mới",
                f"Hệ thống đã tự động chuyển sang Key VIP sống mới (Còn {days_left} ngày)",
                xbmcgui.NOTIFICATION_INFO,
                4500,
            )
        elif version_changed:
            xbmcgui.Dialog().notification(
                "Đã cập nhật VIP Debrid",
                f"Đồng bộ bản v{new_ver} thành công (Còn {days_left} ngày)",
                xbmcgui.NOTIFICATION_INFO,
                4500,
            )
        elif warn:
            if not win.getProperty(warn_prop):
                win.setProperty(warn_prop, "1")
                xbmcgui.Dialog().notification("Sắp hết hạn VIP", warn, xbmcgui.NOTIFICATION_WARNING, 6000)
        return True
    else:
        # Hết hạn, bị khóa hoặc mã sai -> Tự động xóa sạch key trên Kodi để ngắt quyền xem
        empty_keys = {"torbox": "", "realdebrid": "", "alldebrid": "", "premiumize": "", "offcloud": ""}
        _apply_keys_to_addon(addon, profile, xbmcgui, empty_keys, force_write=True)
        _save_user_config(profile, server_url, customer_code, last_state=data)
        if interactive or status in ("expired", "locked"):
            xbmcgui.Dialog().ok("Thông báo Tài khoản VIP", msg or "Gói dịch vụ đã hết hạn hoặc tạm khóa.")
        return False


def prompt_and_activate():
    """Hộp thoại trên TV/Kodi cho phép khách nhập Mã khách hàng, Kiểm tra hạn dùng hoặc Đổi Server."""
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    current_code = (cfg.get("customer_code") or "").strip()

    if current_code:
        choices = [
            f"Đồng bộ & Kiểm tra hạn dùng (Mã: {current_code})",
            "Nhập Mã khách hàng (PIN) khác",
            f"Đổi địa chỉ Server (Hiện tại: {server_url})",
        ]
        sel = xbmcgui.Dialog().select("Quản lý Tài khoản VIP Debrid", choices)
        if sel < 0:
            return False
        if sel == 0:
            return sync_now(force=True, interactive=True, force_rotate=False)
        if sel == 2:
            new_srv = xbmcgui.Dialog().input("Nhập địa chỉ Cloudflare Worker", defaultt=server_url, type=xbmcgui.INPUT_ALPHANUM)
            if new_srv and new_srv.strip():
                server_url = _clean_srv(new_srv)
                _save_user_config(profile, server_url, current_code)
            return sync_now(force=True, interactive=True, force_rotate=False)

    new_code = xbmcgui.Dialog().input(
        "Nhập Mã kích hoạt VIP (Admin cấp)",
        defaultt=current_code,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not new_code or not new_code.strip():
        return False

    _save_user_config(profile, server_url, new_code.strip().lower())
    ok = sync_now(force=True, interactive=True, force_rotate=False)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    return ok


# ==============================================================================
# HỆ THỐNG PHỤ ĐỀ TIẾNG VIỆT TỰ ĐỘNG (SUBDL + SUBSOURCE + AIO WORKER)
# ==============================================================================
AIO_SUB_WORKER = "https://aioaddon.trongtuanatt.workers.dev"

SUBDL_UPSTREAMS = [
    "https://subdl.strem.top/c3ViZGxfMWd0MlNTRnQ0WlJNcGd4dG44SlN4ZE52MDhheTNkaE82blY4MGNlZUNndy9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfTVJaNE5IX0RkNjhJaG9LWGtpUUxlS2U3d1V0NUhsTVotaTlRWGNEU2R3QS9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfTkJXcVNIX2pHc1d0QnFWbGRnZlhraFA2NThINnQ4aDduRkdGRW8yMXp1OC9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfY1kyRUxOaXY2bUdTeXlGcDU2REtzYnRfUGFJci10TVQwNm1qMU9hcHhFWS9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfejhSVTJLM2w3TERyS21xNlNQRUdKRWNhSU9Hc1FDYWh2LVVLX2hvZXptSS9WSS9oaUluY2x1ZGUv",
]

SUBSOURCE_UPSTREAMS = [
    "https://subsource.strem.top/c2tfOGZjODA2YzBlYTI3ZGU1MDM3OTUwMzc1NjA4Yzc1MzMwYzY2NjAzMzY2N2ViNzA4OWM0Zjg4YTE0NWE3ZjYzNC92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
    "https://subsource.strem.top/c2tfMWIyZDYzZTU3ODNmYzFlY2M2Y2E4NjZkMzc5OGMyNjU3NDA2YzE5YmFlOTdlNTdmZTVjYmJhN2QzYzUzNGJmOC92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
    "https://subsource.strem.top/c2tfN2QwZmI2NzU2MTg0MjZmZDlhZDMyYjhhZWVmYmZjZTM3OGY1NDQwN2NhNGEzYWRiODNlNTcyMjIzMzM4YzFlNy92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
]

SUBDL_API_KEYS = [
    "subdl_1gt2SSFt4ZRMpgxtn8JSxdNv08ay3dhO6nV80ceeCgw",
    "subdl_MRZ4NH_Dd68IhoKXkiQLeKe7wUt5HlMZ-i9QXcDSdwA",
    "subdl_NBWqSH_jGsWtBqVldgfXkhP658H6t8h7nFGFEo21zu8",
    "subdl_cY2ELNiv6mGSyyFp56DKsbt_PaIr-tMT06mj1OapxEY",
    "subdl_z8RU2K3l7LDrKmq6SPEGJEcaIOGsQCahv-UK_hoezmI",
]


def _http_get_bytes(url, timeout=10):
    headers = {"User-Agent": BROWSER_UA, "Accept": "*/*"}
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout, verify=False)
        if 200 <= r.status_code < 300 and r.content:
            return r.content
    except Exception:
        pass
    req = urllib.request.Request(url, headers=headers)
    try:
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return resp.read()
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()


def _extract_srt_from_bytes(raw_bytes):
    """Giải nén file .srt nếu dữ liệu trả về là file nén .zip (SubDL trực tiếp) hoặc chuẩn hóa UTF-8."""
    if not raw_bytes:
        return b""
    if raw_bytes[:4] == b"PK\x03\x04":
        try:
            import io
            import zipfile
            with zipfile.ZipFile(io.BytesIO(raw_bytes)) as zf:
                srt_names = [n for n in zf.namelist() if n.lower().endswith((".srt", ".ass", ".ssa", ".vtt", ".sub"))]
                if srt_names:
                    raw_bytes = zf.read(srt_names[0])
        except Exception:
            return b""
    # Đảm bảo mã hóa UTF-8 chuẩn cho Tiếng Việt trên Kodi
    for enc in ("utf-8-sig", "utf-8", "cp1258", "utf-16", "latin-1"):
        try:
            txt = raw_bytes.decode(enc)
            if "\x00" not in txt:
                return txt.encode("utf-8")
        except Exception:
            continue
    return raw_bytes


def _fetch_stremio_subtitles_list(imdb_id, tmdb_id="", mtype="movie", season=None, episode=None):
    """Lấy danh sách phụ đề Tiếng Việt từ AIO Worker (SubDL + SubSource) và các nhánh dự phòng."""
    import random
    import threading

    vid_id = str(imdb_id or "").strip()
    if vid_id and vid_id.isdigit():
        vid_id = "tt" + vid_id
    if not vid_id and tmdb_id:
        vid_id = f"tmdb:{tmdb_id}"
    if not vid_id:
        return []

    has_se = False
    try:
        s_num = int(season) if season not in (None, "", "0", 0) else 0
        e_num = int(episode) if episode not in (None, "", "0", 0) else 0
        has_se = s_num > 0 and e_num > 0
    except Exception:
        s_num, e_num = 0, 0

    is_series = has_se or str(mtype).lower() in ("series", "episode", "tv", "show")
    if is_series and has_se:
        stremio_type = "series"
        stremio_id = f"{vid_id}:{s_num}:{e_num}"
    else:
        stremio_type = "movie"
        stremio_id = vid_id

    sub_path = f"/subtitles/{stremio_type}/{stremio_id}.json"
    collected = []

    # Tầng 1: Gọi song song AIO Worker (aioaddon.trongtuanatt.workers.dev) + 1 nhánh SubDL + 1 nhánh SubSource
    targets = [f"{AIO_SUB_WORKER}{sub_path}", f"{DEFAULT_PRIMARY_SERVER}{sub_path}"]
    if SUBDL_UPSTREAMS:
        targets.append(f"{random.choice(SUBDL_UPSTREAMS)}{sub_path}")
    if SUBSOURCE_UPSTREAMS:
        targets.append(f"{random.choice(SUBSOURCE_UPSTREAMS)}{sub_path}")

    results_box = [[] for _ in targets]

    def _worker_fetch(idx, u):
        try:
            data = _http_get_json(u, timeout=7)
            if isinstance(data, dict) and isinstance(data.get("subtitles"), list):
                results_box[idx] = data["subtitles"]
        except Exception:
            pass

    threads = [threading.Thread(target=_worker_fetch, args=(i, u)) for i, u in enumerate(targets)]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(timeout=8)

    for sub_list in results_box:
        if sub_list:
            collected.extend(sub_list)

    # Tầng 2: Nếu các cầu Stremio chưa trả về kết quả, gọi trực tiếp API gốc của SubDL.com bằng kho 5 API Key
    if not collected and vid_id.startswith("tt") and SUBDL_API_KEYS:
        try:
            api_k = random.choice(SUBDL_API_KEYS)
            q_params = {
                "api_key": api_k,
                "imdb_id": vid_id,
                "languages": "VI",
                "subs_per_page": "10",
                "type": "tv" if (is_series and has_se) else "movie",
            }
            if is_series and has_se:
                q_params["season_number"] = str(s_num)
                q_params["episode_number"] = str(e_num)
            direct_url = "https://api.subdl.com/api/v1/subtitles?" + urllib.parse.urlencode(q_params)
            d_res = _http_get_json(direct_url, timeout=7)
            if isinstance(d_res, dict) and isinstance(d_res.get("subtitles"), list):
                for item in d_res["subtitles"]:
                    dl_link = item.get("url") or ""
                    if dl_link and not dl_link.startswith("http"):
                        dl_link = "https://dl.subdl.com" + (dl_link if dl_link.startswith("/") else "/" + dl_link)
                    if dl_link:
                        collected.append({
                            "id": item.get("release_name") or item.get("name") or "SubDL_VI",
                            "url": dl_link,
                            "lang": "vie",
                        })
        except Exception:
            pass

    # Lọc trùng URL và ưu tiên phụ đề Tiếng Việt
    seen_urls = set()
    vi_subs = []
    other_subs = []
    for s in collected:
        if not isinstance(s, dict):
            continue
        u = str(s.get("url") or "").strip()
        if not u or u in seen_urls:
            continue
        seen_urls.add(u)
        lang = str(s.get("lang") or s.get("language") or "vie").lower()
        if any(w in lang for w in ("vi", "vie", "viet", "vn")) or "subdl.strem.top" in u or "subsource.strem.top" in u:
            vi_subs.append(s)
        else:
            other_subs.append(s)

    return vi_subs if vi_subs else other_subs


def _rank_subtitles_for_file(subs_list, filename=""):
    """Chấm điểm độ khớp tên bản phát hành (Release Name) để chọn đúng bản phụ đề khớp thời gian nhất."""
    if not subs_list or not filename:
        return subs_list
    try:
        from difflib import SequenceMatcher
        import re
        clean_fn = re.sub(r"\W+", " ", str(filename).lower()).strip()
        if not clean_fn:
            return subs_list

        scored = []
        for idx, s in enumerate(subs_list):
            cand_label = " ".join(
                str(s.get(k) or "") for k in ("id", "title", "release_name", "SubFileName", "url")
            ).lower()
            clean_cand = re.sub(r"\W+", " ", cand_label).strip()
            ratio = SequenceMatcher(None, clean_fn, clean_cand).ratio() if clean_cand else 0.0
            scored.append((ratio, -idx, s))
        scored.sort(reverse=True)
        return [item[2] for item in scored]
    except Exception:
        return subs_list


def auto_load_stremio_subtitles(player=None, imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", poster=""):
    """Tự động tải và bật phụ đề Tiếng Việt từ SubDL + SubSource (AIO) ngay khi phát phim trên Kodi."""
    try:
        xbmc, _, xbmcgui, xbmcvfs, addon, profile, _ = _get_kodi_objs()
    except Exception:
        return False

    vid_key = f"{imdb_id or tmdb_id}_{season or 0}_{episode or 0}"
    if not imdb_id and not tmdb_id:
        return False

    # Chống gọi trùng lặp trong vòng 6 giây cho cùng 1 tập phim
    win = xbmcgui.Window(10000)
    lock_prop = f"{ADDON_ID}.sub_lock"
    now = time.time()
    last_lock = win.getProperty(lock_prop) or ""
    if last_lock.startswith(vid_key + "|"):
        try:
            if now - float(last_lock.split("|")[1]) < 6.0:
                return True
        except Exception:
            pass
    win.setProperty(lock_prop, f"{vid_key}|{now}")

    subs = _fetch_stremio_subtitles_list(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode)
    if not subs:
        return False

    ranked = _rank_subtitles_for_file(subs, filename=filename)
    temp_dir = xbmcvfs.translatePath("special://temp/")
    os.makedirs(temp_dir, exist_ok=True)

    # Dọn các file phụ đề tạm cũ
    try:
        for fn in os.listdir(temp_dir):
            if fn.startswith("SubVIP_") and fn.endswith((".srt", ".ass", ".vtt")):
                try:
                    os.remove(os.path.join(temp_dir, fn))
                except Exception:
                    pass
    except Exception:
        pass

    # Tải tối đa 4 bản phụ đề Tiếng Việt tốt nhất về máy để khách có thể chuyển đổi nếu cần
    downloaded_paths = []
    clean_tag = "".join(c for c in vid_key if c.isalnum() or c == "_")
    for idx, sub_item in enumerate(ranked[:4], 1):
        sub_url = str(sub_item.get("url") or "").strip()
        if not sub_url:
            continue
        try:
            raw_bytes = _http_get_bytes(sub_url, timeout=8)
            srt_bytes = _extract_srt_from_bytes(raw_bytes)
            if srt_bytes and len(srt_bytes) > 60:
                local_path = os.path.join(temp_dir, f"SubVIP_{clean_tag}_{idx}.vi.srt")
                with open(local_path, "wb") as f:
                    f.write(srt_bytes)
                downloaded_paths.append(local_path)
        except Exception:
            continue

    if not downloaded_paths:
        return False

    if player is None:
        player = xbmc.Player()

    # Chờ tối đa 12 giây cho tới khi trình phát Video của Kodi thực sự bắt đầu chạy hình
    for _ in range(24):
        try:
            if player.isPlayingVideo():
                break
        except Exception:
            pass
        time.sleep(0.5)

    try:
        # Nạp các bản phụ đề dự phòng trước, nạp bản khớp nhất (#1) cuối cùng để kích hoạt ngay trên màn hình
        for p in reversed(downloaded_paths):
            player.setSubtitles(p)
        player.showSubtitles(True)
        xbmcgui.Dialog().notification(
            "Phụ đề Tiếng Việt (SubDL + SubSource)",
            f"Đã tự động bật phụ đề Tiếng Việt ({len(downloaded_paths)} bản dịch)",
            poster or xbmcgui.NOTIFICATION_INFO,
            3800,
        )
        # Bồi thêm 1 lần sau 1.5s phòng trường hợp luồng video đổi track khi vừa mở
        time.sleep(1.5)
        if player.isPlayingVideo():
            player.setSubtitles(downloaded_paths[0])
            player.showSubtitles(True)
        return True
    except Exception:
        return False


def auto_load_stremio_subtitles_async(imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", player=None, poster=""):
    """Chạy tải phụ đề Tiếng Việt tự động trên luồng nền (Background Thread) để không làm chậm tốc độ mở phim."""
    import threading
    t = threading.Thread(
        target=auto_load_stremio_subtitles,
        kwargs={
            "player": player,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "mtype": mtype,
            "season": season,
            "episode": episode,
            "filename": filename,
            "poster": poster,
        },
    )
    t.daemon = True
    t.start()
    return t
