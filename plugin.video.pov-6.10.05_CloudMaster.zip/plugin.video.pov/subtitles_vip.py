# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
import rent_sync
if __name__ == '__main__':
    rent_sync.handle_kodi_subtitle_module(sys.argv)
