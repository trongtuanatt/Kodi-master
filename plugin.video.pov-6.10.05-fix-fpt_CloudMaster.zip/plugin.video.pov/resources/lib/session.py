import json
import socket
import ssl
import threading
import urllib3
import urllib3.util.connection as urllib3_cn
import requests
from requests.adapters import HTTPAdapter, Retry

# 1. Force IPv4 to avoid ISP IPv6 blackhole/timeout issues (e.g. FPT Telecom)
urllib3_cn.allowed_gai_family = lambda: socket.AF_INET

_orig_create_connection = urllib3_cn.create_connection
_lock = threading.Lock()
_WORKING_IP_CACHE = {}

# Verified CloudFront / CDN Anycast fallback IPs for TMDB
_STATIC_HOSTS = {
	'api.tmdb.org': ['65.9.189.48', '13.227.219.97', '65.8.161.83', '52.85.151.28', '18.154.144.99'],
	'api.themoviedb.org': ['65.9.189.27', '13.227.219.97', '65.8.161.83', '52.85.151.28', '3.169.173.63'],
	'www.themoviedb.org': ['18.67.51.21', '99.86.91.3', '13.227.219.97'],
	'image.tmdb.org': ['169.150.247.36', '138.199.37.230', '138.199.37.231']
}

def _is_valid_public_ip(ip):
	if not ip or not isinstance(ip, str):
		return False
	if ip.startswith(('0.', '127.', '10.', '192.168.', '169.254.')):
		return False
	parts = ip.split('.')
	if len(parts) == 4 and parts[0] == '172' and parts[1].isdigit() and 16 <= int(parts[1]) <= 31:
		return False
	return True

def _query_doh(hostname):
	"""Resolve hostname via Cloudflare (1.1.1.1) or Google (8.8.8.8) DNS-over-HTTPS using direct IP."""
	doh_endpoints = [
		('1.1.1.1', 'cloudflare-dns.com', '/dns-query?name=%s&type=A' % hostname),
		('8.8.8.8', 'dns.google', '/resolve?name=%s&type=A' % hostname),
	]
	ctx = ssl.create_default_context()
	for doh_ip, sni_host, path in doh_endpoints:
		sock = None
		try:
			raw_sock = _orig_create_connection((doh_ip, 443), timeout=2.0)
			sock = ctx.wrap_socket(raw_sock, server_hostname=sni_host)
			req = (
				'GET %s HTTP/1.1\r\n'
				'Host: %s\r\n'
				'Accept: application/dns-json\r\n'
				'Connection: close\r\n\r\n'
			) % (path, sni_host)
			sock.sendall(req.encode('utf-8'))
			data = b''
			while True:
				chunk = sock.recv(4096)
				if not chunk:
					break
				data += chunk
			body = data.split(b'\r\n\r\n', 1)[-1].decode('utf-8', errors='ignore')
			start = body.find('{')
			end = body.rfind('}')
			if start != -1 and end != -1:
				parsed = json.loads(body[start:end + 1])
				ips = [
					ans['data'] for ans in parsed.get('Answer', [])
					if ans.get('type') == 1 and _is_valid_public_ip(ans.get('data'))
				]
				if ips:
					return ips
		except Exception:
			pass
		finally:
			if sock:
				try: sock.close()
				except Exception: pass
	return []

def _get_candidate_ips(host, port):
	candidates = []
	# 1. Try clean DNS-over-HTTPS (bypasses ISP UDP port 53 DNS poisoning)
	for ip in _query_doh(host):
		if ip not in candidates:
			candidates.append(ip)
	# 2. Try system IPv4 DNS (if not poisoned)
	try:
		for res in socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM):
			ip = res[4][0]
			if _is_valid_public_ip(ip) and ip not in candidates:
				candidates.append(ip)
	except Exception:
		pass
	# 3. Append static CloudFront / CDN IPs (hosts fallback)
	for ip in _STATIC_HOSTS.get(host, []):
		if ip not in candidates:
			candidates.append(ip)
	return candidates

def _custom_create_connection(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None, socket_options=None):
	host, port = address
	if host in _STATIC_HOSTS:
		# Fast path: use verified cached IP if available
		cached_ip = _WORKING_IP_CACHE.get(host)
		if cached_ip:
			try:
				return _orig_create_connection((cached_ip, port), timeout=timeout, source_address=source_address, socket_options=socket_options)
			except Exception:
				_WORKING_IP_CACHE.pop(host, None)

		with _lock:
			cached_ip = _WORKING_IP_CACHE.get(host)
			if cached_ip:
				try:
					return _orig_create_connection((cached_ip, port), timeout=timeout, source_address=source_address, socket_options=socket_options)
				except Exception:
					_WORKING_IP_CACHE.pop(host, None)

			last_err = None
			for ip in _get_candidate_ips(host, port):
				try:
					sock = _orig_create_connection((ip, port), timeout=2.5, source_address=source_address, socket_options=socket_options)
					_WORKING_IP_CACHE[host] = ip
					return sock
				except Exception as e:
					last_err = e
			if last_err is not None:
				raise last_err

	return _orig_create_connection(address, timeout=timeout, source_address=source_address, socket_options=socket_options)

urllib3_cn.create_connection = _custom_create_connection

retry = urllib3.util.Retry(total=None, status=1, status_forcelist=(429, 502, 503, 504), backoff_factor=1)
http = urllib3.PoolManager(maxsize=10, retries=retry, timeout=urllib3.util.Timeout(connect=3.05, read=6.05))
http.headers.update(urllib3.util.make_headers(keep_alive=True, accept_encoding=True))

class TimeoutSession(requests.Session):
	CUSTOM_ERRORS = requests.exceptions.ConnectionError, requests.exceptions.Timeout
	def __init__(self, timeout=None):
		requests.Session.__init__(self)
		self.timeout = timeout or (3.05, 6.05)

	def request(self, *args, **kwargs):
		kwargs.setdefault('timeout', self.timeout)
		return requests.Session.request(self, *args, **kwargs)

session = TimeoutSession()
