# -*- coding: utf-8 -*-
import os, json, hashlib

def apply():
    try:
        import xbmcaddon, xbmcvfs, xbmcgui
        addon = xbmcaddon.Addon('plugin.video.umbrella')
        base = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        preset = os.path.join(base, 'debrid_preset.json')
        if os.path.exists(preset):
            with open(preset, 'rb') as f: raw = f.read()
            digest = hashlib.sha1(raw).hexdigest()
            profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
            marker = os.path.join(profile, '.debrid_preset')
            already = False
            if os.path.exists(marker):
                with open(marker, 'r') as f:
                    if f.read().strip() == digest: already = True
            if not already:
                data = json.loads(raw.decode('utf-8'))
                for key, value in data.items():
                    addon.setSetting(key, value)
                if not os.path.exists(profile): xbmcvfs.mkdirs(profile)
                with open(marker, 'w') as f: f.write(digest)
                xbmcgui.Window(10000).clearProperty('umbrella_settings')
    except Exception:
        pass
    try:
        from resources.lib.modules import rent_sync
        rent_sync.sync_now(force=False)
    except Exception:
        pass
