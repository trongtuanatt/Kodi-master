# -*- coding: utf-8 -*-
"""
Kodi Cloud Debrid Sync Engine (Auto Time-Based Key Management & Rotation)
Tự động đồng bộ API Key theo thời hạn thuê từ Cloudflare Worker.
"""
import json
import os
import ssl
import time
import urllib.parse
import urllib.request

ADDON_TYPE = 'umbrella'
ADDON_ID_MAP = {
    "pov": "plugin.video.pov",
    "torus": "plugin.video.torus",
    "umbrella": "plugin.video.umbrella",
}
ADDON_ID = ADDON_ID_MAP.get(ADDON_TYPE, "plugin.video.pov")
SYNC_CACHE_TTL = 20  # Kiểm tra đồng bộ nhanh mỗi 20 giây để nhận lệnh Update từ Web Admin ngay lập tức

DEFAULT_PRIMARY_SERVER = "https://phim4k-vip.trongtuanatt.workers.dev"
FALLBACK_SERVERS = [
    "https://phim4k-vip.trongtuanatt.workers.dev",
    "https://debrid-vip.trongtuanatt.workers.dev",
]
BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"


def _clean_srv(url):
    u = (url or "").strip().rstrip("/")
    for s in ("/admin/login", "/admin", "/kodi-sync", "/kodi"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u


def _get_kodi_objs():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    addon = xbmcaddon.Addon(ADDON_ID)
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    base = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    os.makedirs(profile, exist_ok=True)
    return xbmc, xbmcaddon, xbmcgui, xbmcvfs, addon, profile, base


def _load_config(profile, base):
    cfg = {"server_url": DEFAULT_PRIMARY_SERVER, "customer_code": ""}
    preset_path = os.path.join(base, "debrid_cloud_config.json")
    if os.path.exists(preset_path):
        try:
            with open(preset_path, "r", encoding="utf-8") as f:
                p = json.load(f)
                if p.get("server_url"):
                    cfg["server_url"] = p["server_url"]
                if p.get("customer_code"):
                    cfg["customer_code"] = p["customer_code"]
        except Exception:
            pass
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    if os.path.exists(user_path):
        try:
            with open(user_path, "r", encoding="utf-8") as f:
                u = json.load(f)
                if u.get("server_url"):
                    cfg["server_url"] = u["server_url"]
                if "customer_code" in u and u["customer_code"]:
                    cfg["customer_code"] = u["customer_code"]
                if "last_state" in u and isinstance(u["last_state"], dict):
                    cfg["last_state"] = u["last_state"]
        except Exception:
            pass
    # Nếu cấu hình cũ đang trỏ vào debrid-vip mà chưa kích hoạt thành công, ưu tiên phim4k-vip trước
    cleaned = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    cfg["server_url"] = cleaned
    return cfg


def _save_user_config(profile, server_url, customer_code, last_state=None):
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    data = {"server_url": _clean_srv(server_url) or DEFAULT_PRIMARY_SERVER, "customer_code": customer_code.strip().lower()}
    if last_state is not None:
        data["last_state"] = last_state
    try:
        with open(user_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_customer_code():
    try:
        _, _, _, _, _, profile, base = _get_kodi_objs()
        cfg = _load_config(profile, base)
        return (cfg.get("customer_code") or "").strip()
    except Exception:
        return ""


def _http_get_json(url, timeout=10):
    """Gửi request tới Cloudflare Worker với User-Agent trình duyệt (tránh lỗi 403/1010) và bỏ qua lỗi chứng chỉ SSL trên Android TV Box cũ."""
    headers = {"User-Agent": BROWSER_UA, "Accept": "application/json"}
    # Ưu tiên 1: Dùng thư viện requests của Kodi nếu có
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout)
        return r.json()
    except Exception:
        pass
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout, verify=False)
        return r.json()
    except Exception:
        pass

    # Ưu tiên 2: Dùng urllib với SSL Context không kiểm tra chứng chỉ (chống lỗi SSL trên Android Box)
    req = urllib.request.Request(url, headers=headers)
    try:
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))


def _fetch_sync_with_fallback(primary_server, customer_code, report_dead=False):
    """Tự động thử Server chính và các Server dự phòng nếu khách nằm ở Worker mới (phim4k-vip) hoặc Worker cũ (debrid-vip)."""
    q = urllib.parse.urlencode({
        "user": customer_code,
        "addon": ADDON_TYPE,
        "report_dead": "1" if report_dead else "0",
    })
    candidates = []
    for srv in [primary_server] + FALLBACK_SERVERS:
        c = _clean_srv(srv)
        if c and c not in candidates:
            candidates.append(c)

    last_data = None
    used_server = primary_server
    last_err = None

    for srv in candidates:
        url = f"{srv}/kodi-sync?{q}"
        try:
            data = _http_get_json(url, timeout=10)
            if isinstance(data, dict):
                last_data = data
                used_server = srv
                # Nếu tìm thấy tài khoản (dù còn hạn, hết hạn hay bị khóa) thì dừng ngay tại Server này
                if data.get("status") != "invalid_user":
                    return data, srv, None
        except Exception as exc:
            last_err = exc

    return last_data, used_server, last_err


def _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=False):
    """Ghi hoặc thu hồi (xóa trắng) API Key trên từng loại Addon."""
    tb = (keys_map.get("torbox") or "").strip()
    rd = (keys_map.get("realdebrid") or "").strip()
    ad = (keys_map.get("alldebrid") or "").strip()
    pm = (keys_map.get("premiumize") or "").strip()
    oc = (keys_map.get("offcloud") or "").strip()

    if ADDON_TYPE == "pov":
        pairs = [
            ("tb.token", tb), ("tb.enabled", "true" if tb else "false"),
            ("rd.token", rd), ("rd.enabled", "true" if rd else "false"),
            ("ad.token", ad), ("ad.enabled", "true" if ad else "false"),
            ("pm.token", pm), ("pm.enabled", "true" if pm else "false"),
            ("oc.token", oc), ("oc.enabled", "true" if oc else "false"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("pov_settings")
            try:
                from modules import kodi_utils
                kodi_utils.make_settings_dict()
            except Exception:
                pass

    elif ADDON_TYPE == "torus":
        if force_write or addon.getSetting("torbox_api_key") != tb:
            addon.setSetting("torbox_api_key", tb)
        tok_file = os.path.join(profile, "torbox_token.json")
        if tb:
            try:
                with open(tok_file, "w", encoding="utf-8") as f:
                    json.dump({"token": tb}, f)
            except Exception:
                pass
        else:
            try:
                if os.path.exists(tok_file):
                    os.remove(tok_file)
            except Exception:
                pass

    elif ADDON_TYPE == "umbrella":
        pairs = [
            ("torboxtoken", tb), ("torbox.enable", "true" if tb else "false"),
            ("realdebridtoken", rd), ("realdebrid.enable", "true" if rd else "false"),
            ("alldebridtoken", ad), ("alldebrid.enable", "true" if ad else "false"),
            ("premiumizetoken", pm), ("premiumize.enable", "true" if pm else "false"),
            ("offcloudtoken", oc), ("offcloud.enable", "true" if oc else "false"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("umbrella_settings")


def sync_now(force=False, interactive=False, force_rotate=False, report_dead=False):
    """Đồng bộ API key với Cloudflare Worker (Zero-Scan mặc định, tự động báo thay Key khi phát hiện Key Die)."""
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    win = xbmcgui.Window(10000)
    prop_ts = f"{ADDON_ID}.rent_sync_ts"
    now = time.time()

    if not force and not interactive and not force_rotate and not report_dead:
        last_ts = float(win.getProperty(prop_ts) or "0")
        if now - last_ts < SYNC_CACHE_TTL:
            return True

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    customer_code = (cfg.get("customer_code") or "").strip().lower()
    prev_state = cfg.get("last_state") if isinstance(cfg.get("last_state"), dict) else {}
    prev_ver = str(prev_state.get("version") or "")
    prev_keys = prev_state.get("keys") if isinstance(prev_state.get("keys"), dict) else {}

    if not customer_code:
        if interactive:
            return prompt_and_activate()
        return False

    data, active_srv, err = _fetch_sync_with_fallback(
        server_url,
        customer_code,
        report_dead=bool(report_dead or interactive),
    )

    if not isinstance(data, dict):
        if interactive:
            xbmcgui.Dialog().ok(
                "Lỗi kết nối Server",
                f"Không thể kết nối tới Server quản lý ({server_url}) - Chi tiết: {err}",
            )
        return False

    server_url = active_srv
    win.setProperty(prop_ts, str(now))
    keys_map = data.get("keys") or {}
    ok = bool(data.get("ok"))
    status = data.get("status") or ""
    msg = data.get("message") or ""
    warn = data.get("warning") or ""
    new_ver = str(data.get("version") or "")
    days_left = data.get("days_left", "")
    auto_rotated = bool(data.get("auto_rotated"))
    keys_changed = bool(prev_keys and keys_map != prev_keys)
    version_changed = bool(new_ver and prev_ver and new_ver != prev_ver)

    if ok:
        _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=(version_changed or keys_changed or auto_rotated or interactive))
        _save_user_config(profile, server_url, customer_code, last_state=data)
        warn_prop = f"{ADDON_ID}.warn_shown"
        if not warn or version_changed:
            win.clearProperty(warn_prop)
        if interactive:
            xbmcgui.Dialog().ok("Kích hoạt VIP Debrid thành công", msg)
        elif auto_rotated or keys_changed:
            xbmcgui.Dialog().notification(
                "Đã tự động thay Key VIP mới",
                f"Hệ thống đã tự động chuyển sang Key VIP sống mới (Còn {days_left} ngày)",
                xbmcgui.NOTIFICATION_INFO,
                4500,
            )
        elif version_changed:
            xbmcgui.Dialog().notification(
                "Đã cập nhật VIP Debrid",
                f"Đồng bộ bản v{new_ver} thành công (Còn {days_left} ngày)",
                xbmcgui.NOTIFICATION_INFO,
                4500,
            )
        elif warn:
            if not win.getProperty(warn_prop):
                win.setProperty(warn_prop, "1")
                xbmcgui.Dialog().notification("Sắp hết hạn VIP", warn, xbmcgui.NOTIFICATION_WARNING, 6000)
        return True
    else:
        # Hết hạn, bị khóa hoặc mã sai -> Tự động xóa sạch key trên Kodi để ngắt quyền xem
        empty_keys = {"torbox": "", "realdebrid": "", "alldebrid": "", "premiumize": "", "offcloud": ""}
        _apply_keys_to_addon(addon, profile, xbmcgui, empty_keys, force_write=True)
        _save_user_config(profile, server_url, customer_code, last_state=data)
        if interactive or status in ("expired", "locked"):
            xbmcgui.Dialog().ok("Thông báo Tài khoản VIP", msg or "Gói dịch vụ đã hết hạn hoặc tạm khóa.")
        return False


def prompt_and_activate():
    """Hộp thoại trên TV/Kodi cho phép khách nhập Mã khách hàng, Kiểm tra hạn dùng hoặc Đổi Server."""
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    current_code = (cfg.get("customer_code") or "").strip()

    if current_code:
        choices = [
            f"Đồng bộ & Kiểm tra hạn dùng (Mã: {current_code})",
            "Nhập Mã khách hàng (PIN) khác",
            f"Đổi địa chỉ Server (Hiện tại: {server_url})",
        ]
        sel = xbmcgui.Dialog().select("Quản lý Tài khoản VIP Debrid", choices)
        if sel < 0:
            return False
        if sel == 0:
            return sync_now(force=True, interactive=True, force_rotate=False)
        if sel == 2:
            new_srv = xbmcgui.Dialog().input("Nhập địa chỉ Cloudflare Worker", defaultt=server_url, type=xbmcgui.INPUT_ALPHANUM)
            if new_srv and new_srv.strip():
                server_url = _clean_srv(new_srv)
                _save_user_config(profile, server_url, current_code)
            return sync_now(force=True, interactive=True, force_rotate=False)

    new_code = xbmcgui.Dialog().input(
        "Nhập Mã kích hoạt VIP (Admin cấp)",
        defaultt=current_code,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not new_code or not new_code.strip():
        return False

    _save_user_config(profile, server_url, new_code.strip().lower())
    ok = sync_now(force=True, interactive=True, force_rotate=False)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    return ok
