# -*- coding: utf-8 -*-
import json
import sys
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import rent_sync

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon("plugin.video.tuankaka.aio")
WIN = xbmcgui.Window(10000)
DEFAULT_WORKER_URL = 'https://aioaddon.trongtuanatt.workers.dev'


def get_worker_url():
    u = (ADDON.getSetting("worker_url") or DEFAULT_WORKER_URL).strip().rstrip("/")
    for s in ("/manifest.json", "/admin"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u or DEFAULT_WORKER_URL


def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"


def fetch_json_cached(path, ttl_sec=1800):
    cache_key = f"tuankaka.cache.{path}"
    now = time.time()
    raw_cached = WIN.getProperty(cache_key)
    if raw_cached:
        try:
            obj = json.loads(raw_cached)
            if now - float(obj.get("ts", 0)) < ttl_sec and isinstance(obj.get("data"), dict):
                return obj["data"]
        except Exception:
            pass

    url = f"{get_worker_url()}{path}"
    try:
        data = rent_sync._http_get_json(url, timeout=12)
        if isinstance(data, dict) and data:
            try:
                WIN.setProperty(cache_key, json.dumps({"ts": now, "data": data}))
            except Exception:
                pass
            return data
    except Exception as e:
        xbmc.log(f"[TuanKaka-AIO] Lỗi tải JSON ({url}): {e}", xbmc.LOGERROR)
    return {}


def has_addon(addon_id):
    return xbmc.getCondVisibility(f"System.HasAddon({addon_id})") == 1


def set_item_info(li, title, plot="", year="", imdb_id="", season=None, episode=None, tvshowtitle="", mediatype="movie"):
    try:
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType(mediatype)
        info_tag.setTitle(title)
        if plot:
            info_tag.setPlot(plot)
        if str(year).isdigit():
            info_tag.setYear(int(year))
        if imdb_id:
            info_tag.setIMDBNumber(imdb_id)
        if tvshowtitle:
            info_tag.setTVShowTitle(tvshowtitle)
        if season is not None and str(season).isdigit():
            info_tag.setSeason(int(season))
        if episode is not None and str(episode).isdigit():
            info_tag.setEpisode(int(episode))
    except Exception:
        info = {"title": title, "plot": plot, "mediatype": mediatype}
        if str(year).isdigit():
            info["year"] = int(year)
        if imdb_id:
            info["imdbnumber"] = imdb_id
        if tvshowtitle:
            info["tvshowtitle"] = tvshowtitle
        if season is not None and str(season).isdigit():
            info["season"] = int(season)
        if episode is not None and str(episode).isdigit():
            info["episode"] = int(episode)
        li.setInfo("video", info)


def list_catalogs():
    vip_li = xbmcgui.ListItem(label="[COLOR gold][B]🔑 Quản lý / Kích hoạt Tài khoản VIP Debrid[/B][/COLOR]")
    vip_url = build_url({"action": "vip_auth"})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, vip_url, vip_li, isFolder=False)

    manifest = fetch_json_cached("/manifest.json", ttl_sec=3600)
    catalogs = manifest.get("catalogs", [])
    xbmcplugin.setContent(ADDON_HANDLE, "movies")

    for idx, cat in enumerate(catalogs):
        cat_type = cat.get("type", "movie")
        cat_name = cat.get("name", f"Danh mục {idx + 1}")
        badge = "Phim Lẻ" if cat_type == "movie" else "Phim Bộ"
        label = f"[COLOR deepskyblue][Hàng {idx + 1} • {badge}][/COLOR] {cat_name}"

        li = xbmcgui.ListItem(label=label)
        url = build_url({"action": "slot", "index": idx, "skip": 0})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def open_slot(slot_index, skip=0):
    manifest = fetch_json_cached("/manifest.json", ttl_sec=3600)
    catalogs = manifest.get("catalogs", [])
    idx = int(slot_index)
    if idx < 0 or idx >= len(catalogs):
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    cat = catalogs[idx]
    list_catalog_items(cat.get("type", "movie"), cat.get("id", ""), skip, idx)


def list_catalog_items(cat_type, cat_id, skip=0, slot_index=None):
    enc_id = urllib.parse.quote(str(cat_id), safe=":-_.")
    path = f"/catalog/{cat_type}/{enc_id}.json" if int(skip) == 0 else f"/catalog/{cat_type}/{enc_id}/skip={skip}.json"
    data = fetch_json_cached(path, ttl_sec=1800)
    metas = data.get("metas", [])
    xbmcplugin.setContent(ADDON_HANDLE, "movies" if cat_type == "movie" else "tvshows")

    for item in metas:
        item_id = str(item.get("id", ""))
        imdb_id = str(item.get("imdb_id") or (item_id if item_id.startswith("tt") else ""))
        tmdb_id = item_id.replace("tmdb:", "") if item_id.startswith("tmdb:") else str(item.get("tmdb_id") or "")
        title = item.get("name", "Không rõ tên")
        poster = item.get("poster", "")
        fanart = item.get("background", "")
        logo = item.get("logo", "")
        plot = item.get("description", "")
        year = str(item.get("releaseInfo", ""))[:4]

        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart, "landscape": fanart, "clearlogo": logo})
        set_item_info(li, title=title, plot=plot, year=year, imdb_id=imdb_id, mediatype=("movie" if cat_type == "movie" else "tvshow"))

        if cat_type == "movie":
            li.setProperty("IsPlayable", "true")
            url = build_url({
                "action": "play",
                "type": "movie",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
                "poster": poster,
                "fanart": fanart,
            })
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)
        else:
            url = build_url({
                "action": "series_seasons",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
                "poster": poster,
                "fanart": fanart,
            })
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    if len(metas) >= 20:
        next_skip = int(skip) + len(metas)
        next_li = xbmcgui.ListItem(label="[COLOR yellow]>> Trang tiếp theo >>[/COLOR]")
        if slot_index is not None:
            next_url = build_url({"action": "slot", "index": slot_index, "skip": next_skip})
        else:
            next_url = build_url({"action": "catalog", "type": cat_type, "id": cat_id, "skip": next_skip})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url, next_li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def list_seasons(series_id, imdb_id, tmdb_id, series_title, year, poster, fanart):
    enc_id = urllib.parse.quote(str(series_id), safe=":-_.")
    data = fetch_json_cached(f"/meta/series/{enc_id}.json", ttl_sec=3600)
    meta_obj = data.get("meta", {})
    if not imdb_id:
        imdb_id = str(meta_obj.get("imdb_id") or (series_id if str(series_id).startswith("tt") else ""))
    videos = meta_obj.get("videos", [])
    seasons = sorted(list({int(v.get("season", 1)) for v in videos if v.get("season", 0) > 0}))
    xbmcplugin.setContent(ADDON_HANDLE, "seasons")

    for s in seasons:
        li = xbmcgui.ListItem(label=f"Phần {s}")
        li.setArt({"poster": poster, "fanart": fanart})
        set_item_info(li, title=f"Phần {s}", tvshowtitle=series_title, season=s, imdb_id=imdb_id, mediatype="season")
        url = build_url({
            "action": "series_episodes",
            "id": series_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": s,
            "title": series_title,
            "year": year,
            "poster": poster,
            "fanart": fanart,
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def list_episodes(series_id, imdb_id, tmdb_id, season, series_title, year, poster, fanart):
    enc_id = urllib.parse.quote(str(series_id), safe=":-_.")
    data = fetch_json_cached(f"/meta/series/{enc_id}.json", ttl_sec=3600)
    meta_obj = data.get("meta", {})
    if not imdb_id:
        imdb_id = str(meta_obj.get("imdb_id") or (series_id if str(series_id).startswith("tt") else ""))
    videos = meta_obj.get("videos", [])
    xbmcplugin.setContent(ADDON_HANDLE, "episodes")

    for v in videos:
        if str(v.get("season")) != str(season):
            continue
        ep_num = v.get("episode", v.get("number", 1))
        ep_title = v.get("name", v.get("title", f"Tập {ep_num}"))
        thumb = v.get("thumbnail", poster)
        plot = v.get("overview", v.get("description", ""))

        li = xbmcgui.ListItem(label=f"{ep_num}. {ep_title}")
        li.setArt({"thumb": thumb, "poster": poster, "fanart": fanart})
        li.setProperty("IsPlayable", "true")
        set_item_info(
            li,
            title=ep_title,
            plot=plot,
            year=year,
            imdb_id=imdb_id,
            season=season,
            episode=ep_num,
            tvshowtitle=series_title,
            mediatype="episode",
        )

        url = build_url({
            "action": "play",
            "type": "series",
            "id": series_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": season,
            "episode": ep_num,
            "title": series_title,
            "year": year,
            "poster": poster,
            "fanart": fanart,
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def _resolve_ids(media_type, raw_id, imdb_id, tmdb_id):
    if (not imdb_id or not tmdb_id) and raw_id:
        enc_id = urllib.parse.quote(str(raw_id), safe=":-_.")
        meta_obj = fetch_json_cached(f"/meta/{media_type}/{enc_id}.json", ttl_sec=86400).get("meta", {})
        if not imdb_id:
            imdb_id = str(meta_obj.get("imdb_id") or "")
        if not tmdb_id and meta_obj.get("moviedb_id"):
            tmdb_id = str(meta_obj.get("moviedb_id"))
    return imdb_id, tmdb_id


def _delegate_to_external_addon(engine, media_type, title, year, imdb_id, tmdb_id, season, episode):
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
    xbmc.executebuiltin("Dialog.Close(busydialog,true)")
    q_title = urllib.parse.quote(title)

    if engine == "pov":
        if media_type == "movie":
            u = f"plugin://plugin.video.pov/?mode=play_media&media_type=movie&query={q_title}&year={year}&imdb_id={imdb_id}&tmdb_id={tmdb_id}"
        else:
            u = f"plugin://plugin.video.pov/?mode=play_media&media_type=episode&query={q_title}&year={year}&imdb_id={imdb_id}&tmdb_id={tmdb_id}&season={season}&episode={episode}"
    else:
        if media_type == "movie":
            u = f"plugin://plugin.video.umbrella/?action=play_Item&title={q_title}&year={year}&imdb={imdb_id}&tmdb={tmdb_id}"
        else:
            u = f"plugin://plugin.video.umbrella/?action=play_Item&title={q_title}&tvshowtitle={q_title}&year={year}&imdb={imdb_id}&tmdb={tmdb_id}&season={season}&episode={episode}"

    xbmc.sleep(150)
    xbmc.executebuiltin(f'PlayMedia("{u}")')


def play_item(params):
    media_type = params.get("type", "movie")
    raw_id = params.get("id", "")
    imdb_id = params.get("imdb_id", "") or (raw_id if raw_id.startswith("tt") else "")
    tmdb_id = params.get("tmdb_id", "") or (raw_id.replace("tmdb:", "") if raw_id.startswith("tmdb:") else "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    title = params.get("title", "")
    year = params.get("year", "")
    poster = params.get("poster", "")
    fanart = params.get("fanart", "")

    imdb_id, tmdb_id = _resolve_ids(media_type, raw_id, imdb_id, tmdb_id)
    rent_sync.save_playing_context(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=media_type, season=season, episode=episode, filename=title)

    play_mode = ADDON.getSetting("play_mode") or "0"
    if play_mode == "2" and has_addon("plugin.video.pov"):
        _delegate_to_external_addon("pov", media_type, title, year, imdb_id, tmdb_id, season, episode)
        return
    if play_mode == "3" and has_addon("plugin.video.umbrella"):
        _delegate_to_external_addon("umbrella", media_type, title, year, imdb_id, tmdb_id, season, episode)
        return

    streams = rent_sync.fetch_direct_debrid_streams(imdb_id=imdb_id, mtype=media_type, season=season, episode=episode)

    if not streams:
        keys = rent_sync.get_shared_debrid_keys()
        if not any(keys.values()):
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            if xbmcgui.Dialog().yesno("Chưa kích hoạt VIP Debrid", "Bạn chưa nhập Mã khách hàng VIP Debrid. Bạn có muốn nhập Mã kích hoạt ngay bây giờ không?"):
                rent_sync.prompt_and_activate()
            return

        if has_addon("plugin.video.pov"):
            _delegate_to_external_addon("pov", media_type, title, year, imdb_id, tmdb_id, season, episode)
            return
        if has_addon("plugin.video.umbrella"):
            _delegate_to_external_addon("umbrella", media_type, title, year, imdb_id, tmdb_id, season, episode)
            return

        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("Tuấn Kaká AIO", "Không tìm thấy nguồn phát cho phim này!", xbmcgui.NOTIFICATION_WARNING, 3500)
        return

    chosen_stream = None
    if play_mode == "1":
        chosen_stream = streams[0]
    else:
        labels = [s["label"] for s in streams]
        extra_actions = []
        if has_addon("plugin.video.pov"):
            labels.append("[COLOR orange][B]👉 Quét thêm nguồn bằng POV[/B][/COLOR]")
            extra_actions.append("pov")
        if has_addon("plugin.video.umbrella"):
            labels.append("[COLOR orange][B]👉 Quét thêm nguồn bằng Umbrella[/B][/COLOR]")
            extra_actions.append("umbrella")

        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        header_title = f"{title} (S{season}E{episode})" if (season and episode) else f"{title} ({year})"
        sel = xbmcgui.Dialog().select(f"Chọn nguồn phát ({len(streams)} link): {header_title}", labels)
        if sel < 0:
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return
        if sel >= len(streams):
            ext_eng = extra_actions[sel - len(streams)]
            _delegate_to_external_addon(ext_eng, media_type, title, year, imdb_id, tmdb_id, season, episode)
            return
        chosen_stream = streams[sel]

    rent_sync.save_playing_context(
        imdb_id=imdb_id,
        tmdb_id=tmdb_id,
        mtype=media_type,
        season=season,
        episode=episode,
        filename=chosen_stream.get("filename") or title,
    )

    final_play_url = rent_sync.resolve_playable_stream_url(chosen_stream["url"])
    play_li = xbmcgui.ListItem(path=final_play_url)
    play_li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    set_item_info(
        play_li,
        title=title,
        year=year,
        imdb_id=imdb_id,
        season=season if season else None,
        episode=episode if episode else None,
        tvshowtitle=title if media_type == "series" else "",
        mediatype=("episode" if media_type == "series" else "movie"),
    )
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, play_li)


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action")

    if not action:
        list_catalogs()
    elif action == "vip_auth":
        rent_sync.prompt_and_activate()
    elif action == "slot":
        open_slot(params["index"], params.get("skip", 0))
    elif action == "catalog":
        list_catalog_items(params["type"], params["id"], params.get("skip", 0))
    elif action == "series_seasons":
        list_seasons(
            params["id"], params.get("imdb_id", ""), params.get("tmdb_id", ""),
            params.get("title", ""), params.get("year", ""), params.get("poster", ""), params.get("fanart", "")
        )
    elif action == "series_episodes":
        list_episodes(
            params["id"], params.get("imdb_id", ""), params.get("tmdb_id", ""),
            params["season"], params.get("title", ""), params.get("year", ""), params.get("poster", ""), params.get("fanart", "")
        )
    elif action == "play":
        play_item(params)


if __name__ == "__main__":
    router()