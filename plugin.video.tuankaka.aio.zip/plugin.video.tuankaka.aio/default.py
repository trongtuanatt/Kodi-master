# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import rent_sync

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon("plugin.video.tuankaka.aio")


def get_worker_url():
    u = (ADDON.getSetting("worker_url") or 'https://aioaddon.trongtuanatt.workers.dev').strip().rstrip("/")
    for s in ("/manifest.json", "/admin"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u or 'https://aioaddon.trongtuanatt.workers.dev'


def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"


def fetch_json(path):
    url = f"{get_worker_url()}{path}"
    try:
        data = rent_sync._http_get_json(url, timeout=15)
        if isinstance(data, dict):
            return data
    except Exception as e:
        xbmc.log(f"[TuanKaka-AIO] Lỗi tải JSON ({url}): {e}", xbmc.LOGERROR)
    return {}


def has_addon(addon_id):
    return xbmc.getCondVisibility(f"System.HasAddon({addon_id})") == 1


def set_item_info(li, title, plot="", year="", imdb_id="", season=None, episode=None, tvshowtitle="", mediatype="movie"):
    """Tương thích đồng thời cả Kodi 19 (Matrix) lẫn Kodi 20/21 (Nexus/Omega)"""
    try:
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType(mediatype)
        info_tag.setTitle(title)
        if plot:
            info_tag.setPlot(plot)
        if str(year).isdigit():
            info_tag.setYear(int(year))
        if imdb_id:
            info_tag.setIMDBNumber(imdb_id)
        if tvshowtitle:
            info_tag.setTVShowTitle(tvshowtitle)
        if season is not None and str(season).isdigit():
            info_tag.setSeason(int(season))
        if episode is not None and str(episode).isdigit():
            info_tag.setEpisode(int(episode))
    except Exception:
        info = {"title": title, "plot": plot, "mediatype": mediatype}
        if str(year).isdigit():
            info["year"] = int(year)
        if imdb_id:
            info["imdbnumber"] = imdb_id
        if tvshowtitle:
            info["tvshowtitle"] = tvshowtitle
        if season is not None and str(season).isdigit():
            info["season"] = int(season)
        if episode is not None and str(episode).isdigit():
            info["episode"] = int(episode)
        li.setInfo("video", info)


def list_catalogs():
    rent_sync._set_kodi_default_subtitle_addon(xbmc)
    manifest = fetch_json("/manifest.json")
    catalogs = manifest.get("catalogs", [])
    xbmcplugin.setContent(ADDON_HANDLE, "movies")

    if not catalogs:
        li = xbmcgui.ListItem(label="[COLOR red]Không tải được danh mục từ Worker! Kiểm tra lại kết nối mạng.[/COLOR]")
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, BASE_URL, li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)
        return

    for idx, cat in enumerate(catalogs):
        cat_type = cat.get("type", "movie")
        cat_name = cat.get("name", f"Danh mục {idx + 1}")
        badge = "Phim Lẻ" if cat_type == "movie" else "Phim Bộ"
        label = f"[COLOR deepskyblue][Hàng {idx + 1} • {badge}][/COLOR] {cat_name}"

        li = xbmcgui.ListItem(label=label)
        url = build_url({"action": "slot", "index": idx, "skip": 0})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


def open_slot(slot_index, skip=0):
    manifest = fetch_json("/manifest.json")
    catalogs = manifest.get("catalogs", [])
    idx = int(slot_index)
    if idx < 0 or idx >= len(catalogs):
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    cat = catalogs[idx]
    list_catalog_items(cat.get("type", "movie"), cat.get("id", ""), skip, idx)


def list_catalog_items(cat_type, cat_id, skip=0, slot_index=None):
    enc_id = urllib.parse.quote(str(cat_id), safe=":-_.")
    path = f"/catalog/{cat_type}/{enc_id}.json" if int(skip) == 0 else f"/catalog/{cat_type}/{enc_id}/skip={skip}.json"
    data = fetch_json(path)
    metas = data.get("metas", [])
    xbmcplugin.setContent(ADDON_HANDLE, "movies" if cat_type == "movie" else "tvshows")

    for item in metas:
        item_id = str(item.get("id", ""))
        imdb_id = str(item.get("imdb_id") or (item_id if item_id.startswith("tt") else ""))
        tmdb_id = item_id.replace("tmdb:", "") if item_id.startswith("tmdb:") else str(item.get("tmdb_id") or "")
        title = item.get("name", "Không rõ tên")
        poster = item.get("poster", "")
        fanart = item.get("background", "")
        logo = item.get("logo", "")
        plot = item.get("description", "")
        year = str(item.get("releaseInfo", ""))[:4]

        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart, "landscape": fanart, "clearlogo": logo})
        set_item_info(li, title=title, plot=plot, year=year, imdb_id=imdb_id, mediatype=("movie" if cat_type == "movie" else "tvshow"))

        if cat_type == "movie":
            url = build_url({
                "action": "play",
                "type": "movie",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
            })
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)
        else:
            url = build_url({
                "action": "series_seasons",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
                "poster": poster,
                "fanart": fanart,
            })
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    if len(metas) >= 20:
        next_skip = int(skip) + len(metas)
        next_li = xbmcgui.ListItem(label="[COLOR yellow]>> Trang tiếp theo >>[/COLOR]")
        if slot_index is not None:
            next_url = build_url({"action": "slot", "index": slot_index, "skip": next_skip})
        else:
            next_url = build_url({"action": "catalog", "type": cat_type, "id": cat_id, "skip": next_skip})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url, next_li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def list_seasons(series_id, imdb_id, tmdb_id, series_title, year, poster, fanart):
    enc_id = urllib.parse.quote(str(series_id), safe=":-_.")
    data = fetch_json(f"/meta/series/{enc_id}.json")
    meta_obj = data.get("meta", {})
    if not imdb_id:
        imdb_id = str(meta_obj.get("imdb_id") or (series_id if str(series_id).startswith("tt") else ""))
    videos = meta_obj.get("videos", [])
    seasons = sorted(list({int(v.get("season", 1)) for v in videos if v.get("season", 0) > 0}))
    xbmcplugin.setContent(ADDON_HANDLE, "seasons")

    for s in seasons:
        li = xbmcgui.ListItem(label=f"Phần {s}")
        li.setArt({"poster": poster, "fanart": fanart})
        set_item_info(li, title=f"Phần {s}", tvshowtitle=series_title, season=s, imdb_id=imdb_id, mediatype="season")
        url = build_url({
            "action": "series_episodes",
            "id": series_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": s,
            "title": series_title,
            "year": year,
            "poster": poster,
            "fanart": fanart,
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def list_episodes(series_id, imdb_id, tmdb_id, season, series_title, year, poster, fanart):
    enc_id = urllib.parse.quote(str(series_id), safe=":-_.")
    data = fetch_json(f"/meta/series/{enc_id}.json")
    meta_obj = data.get("meta", {})
    if not imdb_id:
        imdb_id = str(meta_obj.get("imdb_id") or (series_id if str(series_id).startswith("tt") else ""))
    videos = meta_obj.get("videos", [])
    xbmcplugin.setContent(ADDON_HANDLE, "episodes")

    for v in videos:
        if str(v.get("season")) != str(season):
            continue
        ep_num = v.get("episode", v.get("number", 1))
        ep_title = v.get("name", v.get("title", f"Tập {ep_num}"))
        thumb = v.get("thumbnail", poster)
        plot = v.get("overview", v.get("description", ""))

        li = xbmcgui.ListItem(label=f"{ep_num}. {ep_title}")
        li.setArt({"thumb": thumb, "poster": poster, "fanart": fanart})
        set_item_info(
            li,
            title=ep_title,
            plot=plot,
            year=year,
            imdb_id=imdb_id,
            season=season,
            episode=ep_num,
            tvshowtitle=series_title,
            mediatype="episode",
        )

        url = build_url({
            "action": "play",
            "type": "series",
            "id": series_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": season,
            "episode": ep_num,
            "title": series_title,
            "year": year,
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def build_player_url(engine, media_type, title, year, imdb_id, tmdb_id, season, episode):
    q_title = urllib.parse.quote(title)
    if engine == "pov":
        if media_type == "movie":
            return f"plugin://plugin.video.pov/?mode=play_media&media_type=movie&query={q_title}&year={year}&imdb_id={imdb_id}&tmdb_id={tmdb_id}"
        return f"plugin://plugin.video.pov/?mode=play_media&media_type=episode&query={q_title}&year={year}&imdb_id={imdb_id}&tmdb_id={tmdb_id}&season={season}&episode={episode}"

    if engine == "torus":
        if media_type == "movie":
            return f"plugin://plugin.video.torus/?action=streams&mtype=movie&imdb={imdb_id}&tmdb={tmdb_id}&title={q_title}&year={year}"
        return f"plugin://plugin.video.torus/?action=streams&mtype=series&imdb={imdb_id}&tmdb={tmdb_id}&title={q_title}&year={year}&season={season}&episode={episode}"

    if engine == "umbrella":
        if media_type == "movie":
            return f"plugin://plugin.video.umbrella/?action=play_Item&title={q_title}&year={year}&imdb={imdb_id}&tmdb={tmdb_id}"
        return f"plugin://plugin.video.umbrella/?action=play_Item&title={q_title}&tvshowtitle={q_title}&year={year}&imdb={imdb_id}&tmdb={tmdb_id}&season={season}&episode={episode}"

    return ""


def play_item(params):
    media_type = params.get("type", "movie")
    raw_id = params.get("id", "")
    imdb_id = params.get("imdb_id", "") or (raw_id if raw_id.startswith("tt") else "")
    tmdb_id = params.get("tmdb_id", "") or (raw_id.replace("tmdb:", "") if raw_id.startswith("tmdb:") else "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    title = params.get("title", "")
    year = params.get("year", "")

    if not imdb_id and raw_id:
        enc_id = urllib.parse.quote(str(raw_id), safe=":-_.")
        meta_data = fetch_json(f"/meta/{media_type}/{enc_id}.json").get("meta", {})
        imdb_id = str(meta_data.get("imdb_id") or "")

    # Lưu thông tin phim vào bộ nhớ tạm để khi khách bấm nút Phụ đề sẽ nhận diện đúng phim ngay lập tức
    rent_sync.save_playing_context(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=media_type, season=season, episode=episode)

    available = []
    if has_addon("plugin.video.pov"):
        available.append(("pov", "⚡ Phát bằng POV (Nhanh & Đa nguồn Debrid)"))
    if has_addon("plugin.video.torus"):
        available.append(("torus", "🔥 Phát bằng Torus (Torrentio + Comet giống Stremio)"))
    if has_addon("plugin.video.umbrella"):
        available.append(("umbrella", "☂️ Phát bằng Umbrella (Bộ lọc 4K / Dolby Vision / HDR)"))

    if not available:
        xbmcgui.Dialog().ok("Thiếu Addon Nguồn Phát", "Vui lòng cài đặt ít nhất 1 trong 3 addon: POV, Torus hoặc Umbrella!")
        return

    play_mode = ADDON.getSetting("play_mode") or "0"
    chosen_engine = None

    if play_mode == "1" and has_addon("plugin.video.pov"):
        chosen_engine = "pov"
    elif play_mode == "2" and has_addon("plugin.video.torus"):
        chosen_engine = "torus"
    elif play_mode == "3" and has_addon("plugin.video.umbrella"):
        chosen_engine = "umbrella"
    elif len(available) == 1:
        chosen_engine = available[0][0]
    else:
        labels = [item[1] for item in available]
        sel = xbmcgui.Dialog().select(f"Chọn nguồn phát cho: {title}", labels)
        if sel < 0:
            return
        chosen_engine = available[sel][0]

    plugin_url = build_player_url(chosen_engine, media_type, title, year, imdb_id, tmdb_id, season, episode)
    if chosen_engine == "torus":
        xbmc.executebuiltin(f'ActivateWindow(Videos,"{plugin_url}",return)')
    else:
        xbmc.executebuiltin(f'PlayMedia("{plugin_url}")')


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action")

    if not action:
        list_catalogs()
    elif action == "slot":
        open_slot(params["index"], params.get("skip", 0))
    elif action == "catalog":
        list_catalog_items(params["type"], params["id"], params.get("skip", 0))
    elif action == "series_seasons":
        list_seasons(
            params["id"], params.get("imdb_id", ""), params.get("tmdb_id", ""),
            params.get("title", ""), params.get("year", ""), params.get("poster", ""), params.get("fanart", "")
        )
    elif action == "series_episodes":
        list_episodes(
            params["id"], params.get("imdb_id", ""), params.get("tmdb_id", ""),
            params["season"], params.get("title", ""), params.get("year", ""), params.get("poster", ""), params.get("fanart", "")
        )
    elif action == "play":
        play_item(params)


if __name__ == "__main__":
    router()