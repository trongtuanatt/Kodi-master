# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import rent_sync

ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).lstrip("-").isdigit() else -1
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon("plugin.video.tuankaka.aio")
WIN = xbmcgui.Window(10000)
DEFAULT_WORKER_URL = 'https://aioaddon.trongtuanatt.workers.dev'
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
os.makedirs(PROFILE_DIR, exist_ok=True)
SEARCH_HISTORY_FILE = os.path.join(PROFILE_DIR, "search_history.json")


def get_worker_url():
    u = (ADDON.getSetting("worker_url") or DEFAULT_WORKER_URL).strip().rstrip("/")
    for s in ("/manifest.json", "/admin"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u or DEFAULT_WORKER_URL


def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"


def format_seconds(sec):
    s = max(0, int(float(sec or 0)))
    h = s // 3600
    m = (s % 3600) // 60
    rem = s % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{rem:02d}"
    return f"{m:02d}:{rem:02d}"


def fetch_json_cached(path, ttl_sec=1800):
    cache_key = f"tuankaka.cache.{path}"
    now = time.time()
    raw_cached = WIN.getProperty(cache_key)
    if raw_cached:
        try:
            obj = json.loads(raw_cached)
            if now - float(obj.get("ts", 0)) < ttl_sec and isinstance(obj.get("data"), dict):
                return obj["data"]
        except Exception:
            pass

    url = f"{get_worker_url()}{path}"
    try:
        data = rent_sync._http_get_json(url, timeout=12)
        if isinstance(data, dict) and data:
            try:
                WIN.setProperty(cache_key, json.dumps({"ts": now, "data": data}))
            except Exception:
                pass
            return data
    except Exception as e:
        xbmc.log(f"[TuanKaka-AIO] Lỗi tải JSON ({url}): {e}", xbmc.LOGERROR)
    return {}


def has_addon(addon_id):
    return xbmc.getCondVisibility(f"System.HasAddon({addon_id})") == 1


def set_item_info(li, title, plot="", year="", imdb_id="", season=None, episode=None, tvshowtitle="", mediatype="movie", resume_time=0, total_time=0):
    try:
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType(mediatype)
        info_tag.setTitle(title)
        if plot:
            info_tag.setPlot(plot)
        if str(year).isdigit():
            info_tag.setYear(int(year))
        if imdb_id and str(imdb_id).startswith("tt"):
            info_tag.setIMDBNumber(imdb_id)
            try:
                info_tag.setUniqueIDs({"imdb": str(imdb_id)}, "imdb")
            except Exception:
                pass
        if tvshowtitle:
            info_tag.setTVShowTitle(tvshowtitle)
        if season is not None and str(season).isdigit():
            info_tag.setSeason(int(season))
        if episode is not None and str(episode).isdigit():
            info_tag.setEpisode(int(episode))
        if float(resume_time or 0) > 0 and float(total_time or 0) > 0:
            try:
                info_tag.setResumePoint(float(resume_time), float(total_time))
            except Exception:
                pass
    except Exception:
        info = {"title": title, "plot": plot, "mediatype": mediatype}
        if str(year).isdigit():
            info["year"] = int(year)
        if imdb_id and str(imdb_id).startswith("tt"):
            info["imdbnumber"] = imdb_id
        if tvshowtitle:
            info["tvshowtitle"] = tvshowtitle
        if season is not None and str(season).isdigit():
            info["season"] = int(season)
        if episode is not None and str(episode).isdigit():
            info["episode"] = int(episode)
        li.setInfo("video", info)

    if float(resume_time or 0) > 0 and float(total_time or 0) > 0:
        li.setProperty("ResumeTime", str(int(float(resume_time))))
        li.setProperty("TotalTime", str(int(float(total_time))))


def list_catalogs():
    xbmcplugin.setContent(ADDON_HANDLE, "movies")

    # 1. Mục Tìm kiếm Phim Lẻ & Phim Bộ (Giống Stremio)
    search_li = xbmcgui.ListItem(label="[COLOR springgreen][B]🔍 Tìm kiếm Phim Lẻ & Phim Bộ (Search)[/B][/COLOR]")
    search_li.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({"action": "search_menu"}), search_li, isFolder=True)

    # 2. Mục Phim đang xem dở (Continue Watching - Giống Stremio)
    cw_count = len(rent_sync.load_continue_watching())
    cw_badge = f" ({cw_count} phim)" if cw_count > 0 else ""
    cw_li = xbmcgui.ListItem(label=f"[COLOR orange][B]▶️ Phim đang xem dở (Continue Watching){cw_badge}[/B][/COLOR]")
    cw_li.setArt({"icon": "DefaultInProgressShows.png"})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({"action": "continue_watching"}), cw_li, isFolder=True)

    # 3. Quản lý / Kích hoạt VIP Debrid
    vip_li = xbmcgui.ListItem(label="[COLOR gold][B]🔑 Quản lý / Kích hoạt Tài khoản VIP Debrid[/B][/COLOR]")
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({"action": "vip_auth"}), vip_li, isFolder=False)

    # 4. Danh sách 16 hàng Xperience
    manifest = fetch_json_cached("/manifest.json", ttl_sec=3600)
    catalogs = manifest.get("catalogs", [])

    for idx, cat in enumerate(catalogs):
        cat_type = cat.get("type", "movie")
        cat_name = cat.get("name", f"Danh mục {idx + 1}")
        badge = "Phim Lẻ" if cat_type == "movie" else "Phim Bộ"
        label = f"[COLOR deepskyblue][Hàng {idx + 1} • {badge}][/COLOR] {cat_name}"

        li = xbmcgui.ListItem(label=label)
        url = build_url({"action": "slot", "index": idx, "skip": 0})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


# ==============================================================================
# TÍNH NĂNG 1: PHIM ĐANG XEM DỞ (CONTINUE WATCHING GIỐNG STREMIO)
# ==============================================================================
def list_continue_watching():
    items = rent_sync.load_continue_watching()
    xbmcplugin.setContent(ADDON_HANDLE, "movies")

    for item in items:
        item_id = str(item.get("id") or item.get("imdb_id") or "")
        imdb_id = str(item.get("imdb_id") or (item_id if item_id.startswith("tt") else ""))
        tmdb_id = str(item.get("tmdb_id") or "")
        mtype = str(item.get("type") or "movie")
        title = str(item.get("title") or "Không rõ tên")
        year = str(item.get("year") or "")
        season = str(item.get("season") or "")
        episode = str(item.get("episode") or "")
        ep_title = str(item.get("ep_title") or "")
        poster = str(item.get("poster") or "")
        fanart = str(item.get("fanart") or "")
        plot = str(item.get("plot") or "")
        resume_time = float(item.get("resume_time") or 0)
        total_time = float(item.get("total_time") or 0)

        # Tạo nhãn hiển thị tiến độ % hoặc Tập phim giống Stremio
        prog_str = ""
        if resume_time > 15 and total_time > 0:
            pct = min(99, int((resume_time / total_time) * 100))
            prog_str = f" [COLOR springgreen][{format_seconds(resume_time)} / {format_seconds(total_time)} • {pct}%][/COLOR]"

        if mtype == "series" and season and episode:
            se_tag = f"[COLOR cyan][S{int(season):02d}E{int(episode):02d}][/COLOR] "
            display_title = f"{se_tag}{title}{prog_str}"
        else:
            display_title = f"{title}{prog_str}"

        li = xbmcgui.ListItem(label=display_title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart, "landscape": fanart})
        li.setProperty("IsPlayable", "true")

        full_plot = plot
        if prog_str:
            full_plot = f"▶️ Đang xem dở tại: {format_seconds(resume_time)} / {format_seconds(total_time)}\n{plot}"

        set_item_info(
            li,
            title=display_title,
            plot=full_plot,
            year=year,
            imdb_id=imdb_id,
            season=season if mtype == "series" else None,
            episode=episode if mtype == "series" else None,
            tvshowtitle=title if mtype == "series" else "",
            mediatype=("episode" if mtype == "series" else "movie"),
            resume_time=resume_time,
            total_time=total_time,
        )

        # Menu chuột phải (Context Menu) để xóa khỏi Đang xem dở hoặc Chọn tập khác
        cm = []
        if mtype == "series":
            seasons_url = build_url({
                "action": "series_seasons",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
                "poster": poster,
                "fanart": fanart,
            })
            cm.append(("📂 Danh sách tất cả các Phần/Tập", f"Container.Update({seasons_url})"))

        del_url = build_url({"action": "cw_remove", "id": item_id})
        clear_url = build_url({"action": "cw_clear"})
        cm.append(("🗑️ Xóa phim này khỏi Đang xem dở", f"RunPlugin({del_url})"))
        cm.append(("🧹 Xóa toàn bộ danh sách Đang xem dở", f"RunPlugin({clear_url})"))
        li.addContextMenuItems(cm)

        play_url = build_url({
            "action": "play",
            "type": mtype,
            "id": item_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": season,
            "episode": episode,
            "title": title,
            "year": year,
            "poster": poster,
            "fanart": fanart,
            "plot": plot,
            "resume_time": str(int(resume_time)),
            "from_cw": "1",
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, play_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


# ==============================================================================
# TÍNH NĂNG 2: TÌM KIẾM PHIM LẺ & PHIM BỘ (SEARCH GIỐNG STREMIO)
# ==============================================================================
def _load_search_history():
    if os.path.exists(SEARCH_HISTORY_FILE):
        try:
            with open(SEARCH_HISTORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            pass
    return []


def _save_search_query(q):
    q = str(q or "").strip()
    if not q:
        return
    hist = [x for x in _load_search_history() if x.lower() != q.lower()]
    hist.insert(0, q)
    try:
        with open(SEARCH_HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(hist[:20], f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def show_search_menu():
    xbmcplugin.setContent(ADDON_HANDLE, "movies")

    new_li = xbmcgui.ListItem(label="[COLOR springgreen][B]⌨️ Nhập từ khóa tìm kiếm mới...[/B][/COLOR]")
    new_li.setArt({"icon": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({"action": "search_input"}), new_li, isFolder=True)

    history = _load_search_history()
    for q in history:
        h_li = xbmcgui.ListItem(label=f"🕒 {q}")
        h_li.setArt({"icon": "DefaultAddonsSearch.png"})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({"action": "search_exec", "query": q}), h_li, isFolder=True)

    if history:
        clr_li = xbmcgui.ListItem(label="[COLOR salmon]🗑️ Xóa lịch sử tìm kiếm[/COLOR]")
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_url({"action": "search_clear"}), clr_li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


def prompt_and_search():
    kb = xbmc.Keyboard("", "Tìm kiếm Phim Lẻ & Phim Bộ (Nhập tên Tiếng Việt hoặc Tiếng Anh)")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    query = (kb.getText() or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    _save_search_query(query)
    execute_search_results(query)


def execute_search_results(query):
    metas = rent_sync.search_all_catalogs(query)
    xbmcplugin.setContent(ADDON_HANDLE, "movies")

    if not metas:
        xbmcgui.Dialog().notification("Tìm kiếm", f"Không tìm thấy phim cho: {query}", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    _render_metas_list(metas, default_type="movie", show_type_badge=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


# ==============================================================================
# HIỂN THỊ DANH MỤC & PHÁT PHIM TRỰC TIẾP
# ==============================================================================
def open_slot(slot_index, skip=0):
    manifest = fetch_json_cached("/manifest.json", ttl_sec=3600)
    catalogs = manifest.get("catalogs", [])
    idx = int(slot_index)
    if idx < 0 or idx >= len(catalogs):
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    cat = catalogs[idx]
    list_catalog_items(cat.get("type", "movie"), cat.get("id", ""), skip, idx)


def _render_metas_list(metas, default_type="movie", show_type_badge=False):
    for item in metas:
        cat_type = str(item.get("type") or default_type)
        item_id = str(item.get("id", ""))
        imdb_id = str(item.get("imdb_id") or (item_id if item_id.startswith("tt") else ""))
        tmdb_id = item_id.replace("tmdb:", "") if item_id.startswith("tmdb:") else str(item.get("tmdb_id") or (item_id if item_id.isdigit() else ""))
        title = item.get("name", "Không rõ tên")
        poster = item.get("poster") or (f"https://images.metahub.space/poster/medium/{imdb_id}/img" if imdb_id.startswith("tt") else "")
        fanart = item.get("background") or (f"https://images.metahub.space/background/medium/{imdb_id}/img" if imdb_id.startswith("tt") else "")
        logo = item.get("logo") or (f"https://images.metahub.space/logo/medium/{imdb_id}/img" if imdb_id.startswith("tt") else "")
        plot = item.get("description", "")
        year = str(item.get("releaseInfo") or item.get("year") or "")[:4]

        if show_type_badge:
            t_badge = "[COLOR deepskyblue][Phim Lẻ][/COLOR] " if cat_type == "movie" else "[COLOR gold][Phim Bộ][/COLOR] "
            year_sfx = f" ({year})" if year.isdigit() else ""
            label = f"{t_badge}{title}{year_sfx}"
        else:
            label = title

        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart, "landscape": fanart, "clearlogo": logo})
        set_item_info(li, title=title, plot=plot, year=year, imdb_id=imdb_id, mediatype=("movie" if cat_type == "movie" else "tvshow"))

        if cat_type == "movie":
            li.setProperty("IsPlayable", "true")
            url = build_url({
                "action": "play",
                "type": "movie",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
                "poster": poster,
                "fanart": fanart,
                "plot": plot[:300],
            })
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)
        else:
            url = build_url({
                "action": "series_seasons",
                "id": item_id,
                "imdb_id": imdb_id,
                "tmdb_id": tmdb_id,
                "title": title,
                "year": year,
                "poster": poster,
                "fanart": fanart,
                "plot": plot[:300],
            })
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)


def list_catalog_items(cat_type, cat_id, skip=0, slot_index=None):
    enc_id = urllib.parse.quote(str(cat_id), safe=":-_.")
    path = f"/catalog/{cat_type}/{enc_id}.json" if int(skip) == 0 else f"/catalog/{cat_type}/{enc_id}/skip={skip}.json"
    data = fetch_json_cached(path, ttl_sec=1800)
    metas = data.get("metas", [])
    xbmcplugin.setContent(ADDON_HANDLE, "movies" if cat_type == "movie" else "tvshows")

    _render_metas_list(metas, default_type=cat_type, show_type_badge=False)

    if len(metas) >= 20:
        next_skip = int(skip) + len(metas)
        next_li = xbmcgui.ListItem(label="[COLOR yellow]>> Trang tiếp theo >>[/COLOR]")
        if slot_index is not None:
            next_url = build_url({"action": "slot", "index": slot_index, "skip": next_skip})
        else:
            next_url = build_url({"action": "catalog", "type": cat_type, "id": cat_id, "skip": next_skip})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url, next_li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def _fetch_series_meta_with_fallback(series_id, imdb_id=""):
    enc_id = urllib.parse.quote(str(series_id), safe=":-_.")
    data = fetch_json_cached(f"/meta/series/{enc_id}.json", ttl_sec=3600)
    meta_obj = data.get("meta") if isinstance(data, dict) else None
    if isinstance(meta_obj, dict) and meta_obj.get("videos"):
        return meta_obj
    # Dự phòng qua Cinemeta nếu phim tìm kiếm từ ngoài Xperience
    tt = imdb_id if str(imdb_id).startswith("tt") else (series_id if str(series_id).startswith("tt") else "")
    if tt:
        c_data = rent_sync._http_get_json(f"https://v3-cinemeta.strem.io/meta/series/{tt}.json", timeout=8)
        if isinstance(c_data, dict) and isinstance(c_data.get("meta"), dict):
            return c_data["meta"]
    return meta_obj or {}


def list_seasons(series_id, imdb_id, tmdb_id, series_title, year, poster, fanart):
    meta_obj = _fetch_series_meta_with_fallback(series_id, imdb_id)
    if not imdb_id:
        imdb_id = str(meta_obj.get("imdb_id") or (series_id if str(series_id).startswith("tt") else ""))
        if not imdb_id:
            m_tt = re.search(r"\b(tt\d{7,9})\b", json.dumps(meta_obj))
            if m_tt:
                imdb_id = m_tt.group(1)
    videos = meta_obj.get("videos", [])
    seasons = sorted(list({int(v.get("season", 1)) for v in videos if v.get("season", 0) > 0}))
    xbmcplugin.setContent(ADDON_HANDLE, "seasons")

    for s in seasons:
        li = xbmcgui.ListItem(label=f"Phần {s}")
        li.setArt({"poster": poster, "fanart": fanart})
        set_item_info(li, title=f"Phần {s}", tvshowtitle=series_title, season=s, imdb_id=imdb_id, mediatype="season")
        url = build_url({
            "action": "series_episodes",
            "id": series_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": s,
            "title": series_title,
            "year": year,
            "poster": poster,
            "fanart": fanart,
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def list_episodes(series_id, imdb_id, tmdb_id, season, series_title, year, poster, fanart):
    meta_obj = _fetch_series_meta_with_fallback(series_id, imdb_id)
    if not imdb_id:
        imdb_id = str(meta_obj.get("imdb_id") or (series_id if str(series_id).startswith("tt") else ""))
        if not imdb_id:
            m_tt = re.search(r"\b(tt\d{7,9})\b", json.dumps(meta_obj))
            if m_tt:
                imdb_id = m_tt.group(1)
    videos = meta_obj.get("videos", [])
    xbmcplugin.setContent(ADDON_HANDLE, "episodes")

    for v in videos:
        if str(v.get("season")) != str(season):
            continue
        ep_num = v.get("episode", v.get("number", 1))
        ep_title = v.get("name", v.get("title", f"Tập {ep_num}"))
        thumb = v.get("thumbnail", poster)
        plot = v.get("overview", v.get("description", ""))

        li = xbmcgui.ListItem(label=f"{ep_num}. {ep_title}")
        li.setArt({"thumb": thumb, "poster": poster, "fanart": fanart})
        li.setProperty("IsPlayable", "true")
        set_item_info(
            li,
            title=ep_title,
            plot=plot,
            year=year,
            imdb_id=imdb_id,
            season=season,
            episode=ep_num,
            tvshowtitle=series_title,
            mediatype="episode",
        )

        url = build_url({
            "action": "play",
            "type": "series",
            "id": series_id,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "season": season,
            "episode": ep_num,
            "ep_title": ep_title,
            "title": series_title,
            "year": year,
            "poster": poster,
            "fanart": fanart,
            "plot": plot[:300],
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=True)


def _resolve_ids(media_type, raw_id, imdb_id, tmdb_id, title="", year=""):
    if (not str(imdb_id).startswith("tt") or not tmdb_id) and raw_id:
        enc_id = urllib.parse.quote(str(raw_id), safe=":-_.")
        meta_obj = fetch_json_cached(f"/meta/{media_type}/{enc_id}.json", ttl_sec=86400).get("meta", {})
        if not str(imdb_id).startswith("tt"):
            cand_tt = str(meta_obj.get("imdb_id") or "")
            if not cand_tt.startswith("tt"):
                m_tt = re.search(r"\b(tt\d{7,9})\b", json.dumps(meta_obj))
                if m_tt:
                    cand_tt = m_tt.group(1)
            if cand_tt.startswith("tt"):
                imdb_id = cand_tt
        if not tmdb_id and meta_obj.get("moviedb_id"):
            tmdb_id = str(meta_obj.get("moviedb_id"))
        if not title and meta_obj.get("name"):
            title = str(meta_obj.get("name"))

    if not str(imdb_id).startswith("tt"):
        imdb_id = rent_sync.resolve_imdb_id_fast(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title, year=year, mtype=media_type)

    return imdb_id, tmdb_id


def _delegate_to_external_addon(engine, media_type, title, year, imdb_id, tmdb_id, season, episode):
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
    xbmc.executebuiltin("Dialog.Close(busydialog,true)")
    q_title = urllib.parse.quote(title)

    if engine == "pov":
        if media_type == "movie":
            u = f"plugin://plugin.video.pov/?mode=play_media&media_type=movie&query={q_title}&year={year}&imdb_id={imdb_id}&tmdb_id={tmdb_id}"
        else:
            u = f"plugin://plugin.video.pov/?mode=play_media&media_type=episode&query={q_title}&year={year}&imdb_id={imdb_id}&tmdb_id={tmdb_id}&season={season}&episode={episode}"
    else:
        if media_type == "movie":
            u = f"plugin://plugin.video.umbrella/?action=play_Item&title={q_title}&year={year}&imdb={imdb_id}&tmdb={tmdb_id}"
        else:
            u = f"plugin://plugin.video.umbrella/?action=play_Item&title={q_title}&tvshowtitle={q_title}&year={year}&imdb={imdb_id}&tmdb={tmdb_id}&season={season}&episode={episode}"

    xbmc.sleep(150)
    xbmc.executebuiltin(f'PlayMedia("{u}")')


def play_item(params):
    media_type = params.get("type", "movie")
    raw_id = params.get("id", "")
    imdb_id = params.get("imdb_id", "") or (raw_id if raw_id.startswith("tt") else "")
    tmdb_id = params.get("tmdb_id", "") or (raw_id.replace("tmdb:", "") if raw_id.startswith("tmdb:") else (raw_id if raw_id.isdigit() else ""))
    season = params.get("season", "")
    episode = params.get("episode", "")
    ep_title = params.get("ep_title", "")
    title = params.get("title", "")
    year = params.get("year", "")
    poster = params.get("poster", "")
    fanart = params.get("fanart", "")
    plot = params.get("plot", "")

    imdb_id, tmdb_id = _resolve_ids(media_type, raw_id, imdb_id, tmdb_id, title=title, year=year)
    cw_key = raw_id or imdb_id

    # Kiểm tra xem bộ phim này có vị trí đang xem dở (Resume Point) trong Continue Watching không
    saved_resume = float(params.get("resume_time") or 0)
    if saved_resume <= 0 and cw_key:
        for cw_it in rent_sync.load_continue_watching():
            if str(cw_it.get("id") or cw_it.get("imdb_id") or "") == cw_key:
                if media_type == "movie" or (str(cw_it.get("season", "")) == str(season) and str(cw_it.get("episode", "")) == str(episode)):
                    saved_resume = float(cw_it.get("resume_time") or 0)
                break

    start_offset = 0.0
    if saved_resume >= 20:
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        resume_choices = [
            f"▶️ Tiếp tục xem từ {format_seconds(saved_resume)}",
            "🔄 Xem lại từ đầu (00:00)",
        ]
        r_sel = xbmcgui.Dialog().select(f"Phim đang xem dở: {title}", resume_choices)
        if r_sel < 0:
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return
        if r_sel == 0:
            start_offset = saved_resume

    # Lưu ngay vào đầu danh sách "Phim đang xem dở (Continue Watching)"
    if not poster and imdb_id.startswith("tt"):
        poster = f"https://images.metahub.space/poster/medium/{imdb_id}/img"
    if not fanart and imdb_id.startswith("tt"):
        fanart = f"https://images.metahub.space/background/medium/{imdb_id}/img"

    rent_sync.upsert_continue_watching_item({
        "id": cw_key,
        "imdb_id": imdb_id,
        "tmdb_id": tmdb_id,
        "type": media_type,
        "title": title,
        "year": year,
        "season": str(season or ""),
        "episode": str(episode or ""),
        "ep_title": ep_title,
        "poster": poster,
        "fanart": fanart,
        "plot": plot,
    })

    rent_sync.save_playing_context(
        imdb_id=imdb_id,
        tmdb_id=tmdb_id,
        mtype=media_type,
        season=season,
        episode=episode,
        filename=title,
        title=title,
        year=year,
        raw_id=cw_key,
    )

    play_mode = ADDON.getSetting("play_mode") or "0"
    if play_mode == "2" and has_addon("plugin.video.pov"):
        _delegate_to_external_addon("pov", media_type, title, year, imdb_id, tmdb_id, season, episode)
        return
    if play_mode == "3" and has_addon("plugin.video.umbrella"):
        _delegate_to_external_addon("umbrella", media_type, title, year, imdb_id, tmdb_id, season, episode)
        return

    streams = rent_sync.fetch_direct_debrid_streams(
        imdb_id=imdb_id,
        mtype=media_type,
        season=season,
        episode=episode,
        tmdb_id=tmdb_id,
        title=title,
        year=year,
    )

    if not streams:
        keys = rent_sync.get_shared_debrid_keys()
        if not any(keys.values()):
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            xbmc.executebuiltin("Dialog.Close(busydialog,true)")
            if xbmcgui.Dialog().yesno("Chưa kích hoạt VIP Debrid", "Bạn chưa nhập Mã khách hàng VIP Debrid. Bạn có muốn nhập Mã kích hoạt ngay bây giờ không?"):
                rent_sync.prompt_and_activate()
            return

        if has_addon("plugin.video.pov"):
            _delegate_to_external_addon("pov", media_type, title, year, imdb_id, tmdb_id, season, episode)
            return
        if has_addon("plugin.video.umbrella"):
            _delegate_to_external_addon("umbrella", media_type, title, year, imdb_id, tmdb_id, season, episode)
            return

        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("Tuấn Kaká AIO", "Không tìm thấy nguồn phát cho phim này!", xbmcgui.NOTIFICATION_WARNING, 3500)
        return

    chosen_stream = None
    if play_mode == "1":
        chosen_stream = streams[0]
    else:
        labels = [s["label"] for s in streams]
        extra_actions = []
        if has_addon("plugin.video.pov"):
            labels.append("[COLOR orange][B]👉 Quét thêm nguồn bằng POV[/B][/COLOR]")
            extra_actions.append("pov")
        if has_addon("plugin.video.umbrella"):
            labels.append("[COLOR orange][B]👉 Quét thêm nguồn bằng Umbrella[/B][/COLOR]")
            extra_actions.append("umbrella")

        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
        header_title = f"{title} (S{season}E{episode})" if (season and episode) else f"{title} ({year})"
        sel = xbmcgui.Dialog().select(f"Chọn nguồn phát ({len(streams)} link): {header_title}", labels)
        if sel < 0:
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return
        if sel >= len(streams):
            ext_eng = extra_actions[sel - len(streams)]
            _delegate_to_external_addon(ext_eng, media_type, title, year, imdb_id, tmdb_id, season, episode)
            return
        chosen_stream = streams[sel]

    rent_sync.save_playing_context(
        imdb_id=imdb_id,
        tmdb_id=tmdb_id,
        mtype=media_type,
        season=season,
        episode=episode,
        filename=chosen_stream.get("filename") or title,
        title=title,
        year=year,
        raw_id=cw_key,
    )

    final_play_url = rent_sync.resolve_playable_stream_url(chosen_stream["url"])
    play_li = xbmcgui.ListItem(path=final_play_url)
    play_li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    if start_offset > 0:
        play_li.setProperty("StartOffset", str(float(start_offset)))

    set_item_info(
        play_li,
        title=title,
        year=year,
        imdb_id=imdb_id,
        season=season if season else None,
        episode=episode if episode else None,
        tvshowtitle=title if media_type == "series" else "",
        mediatype=("episode" if media_type == "series" else "movie"),
        resume_time=start_offset,
    )
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, play_li)


def router():
    qs = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
    params = dict(urllib.parse.parse_qsl(qs))
    action = params.get("action")

    # ĐỊNH TUYẾN TRỰC TIẾP CHO HỘP THOẠI TÌM & TẢI PHỤ ĐỀ CỦA KODI
    if action in ("search", "manualsearch"):
        import subtitles
        subtitles.search_subtitles(ADDON_HANDLE, params)
        return
    if action == "download":
        import subtitles
        subtitles.download_selected_subtitle(ADDON_HANDLE, params)
        return

    if not action:
        list_catalogs()
    elif action == "continue_watching":
        list_continue_watching()
    elif action == "cw_remove":
        rent_sync.remove_continue_watching_item(params.get("id", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif action == "cw_clear":
        if xbmcgui.Dialog().yesno("Xóa Đang xem dở", "Bạn có chắc muốn xóa toàn bộ danh sách Phim đang xem dở?"):
            rent_sync.save_continue_watching([])
            xbmc.executebuiltin("Container.Refresh")
    elif action == "search_menu":
        show_search_menu()
    elif action == "search_input":
        prompt_and_search()
    elif action == "search_exec":
        execute_search_results(params.get("query", ""))
    elif action == "search_clear":
        try:
            if os.path.exists(SEARCH_HISTORY_FILE):
                os.remove(SEARCH_HISTORY_FILE)
        except Exception:
            pass
        xbmc.executebuiltin("Container.Refresh")
    elif action == "vip_auth":
        rent_sync.prompt_and_activate()
    elif action == "slot":
        open_slot(params["index"], params.get("skip", 0))
    elif action == "catalog":
        list_catalog_items(params["type"], params["id"], params.get("skip", 0))
    elif action == "series_seasons":
        list_seasons(
            params["id"], params.get("imdb_id", ""), params.get("tmdb_id", ""),
            params.get("title", ""), params.get("year", ""), params.get("poster", ""), params.get("fanart", "")
        )
    elif action == "series_episodes":
        list_episodes(
            params["id"], params.get("imdb_id", ""), params.get("tmdb_id", ""),
            params["season"], params.get("title", ""), params.get("year", ""), params.get("poster", ""), params.get("fanart", "")
        )
    elif action == "play":
        play_item(params)


if __name__ == "__main__":
    router()