# -*- coding: utf-8 -*-
import json
import os
import re
import sys
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import rent_sync

ADDON = xbmcaddon.Addon("plugin.video.tuankaka.aio")
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
SUB_SAVE_DIR = os.path.join(PROFILE_DIR, "subtitles_selected")
os.makedirs(SUB_SAVE_DIR, exist_ok=True)


def _get_player_rpc_metadata():
    info = {"imdb": "", "tmdb": "", "title": "", "year": "", "season": "", "episode": "", "file": ""}
    try:
        rpc_q = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Player.GetItem",
            "params": {
                "playerid": 1,
                "properties": ["title", "originaltitle", "tvshowtitle", "year", "imdbnumber", "season", "episode", "uniqueid", "file"],
            },
        })
        res = json.loads(xbmc.executeJSONRPC(rpc_q))
        item = (res.get("result") or {}).get("item") or {}
        uids = item.get("uniqueid") or {}
        if isinstance(uids, dict):
            for k, v in uids.items():
                sv = str(v or "").strip()
                if sv.startswith("tt"):
                    info["imdb"] = sv
                elif "tmdb" in str(k).lower() and sv.isdigit():
                    info["tmdb"] = sv

        raw_imdb = str(item.get("imdbnumber") or "").strip()
        if raw_imdb.startswith("tt") and not info["imdb"]:
            info["imdb"] = raw_imdb
        elif raw_imdb.isdigit() and not info["tmdb"]:
            info["tmdb"] = raw_imdb

        info["title"] = str(item.get("tvshowtitle") or item.get("originaltitle") or item.get("title") or "").strip()
        if item.get("year") and int(item.get("year", 0)) > 1900:
            info["year"] = str(item["year"])
        if item.get("season") and int(item.get("season", -1)) > 0:
            info["season"] = str(item["season"])
        if item.get("episode") and int(item.get("episode", -1)) > 0:
            info["episode"] = str(item["episode"])
        if item.get("file"):
            info["file"] = str(item["file"])
    except Exception:
        pass
    return info


def _get_current_playing_metadata(params=None):
    win = xbmcgui.Window(10000)
    rpc_meta = _get_player_rpc_metadata()

    playing_path = ""
    try:
        playing_path = xbmc.Player().getPlayingFile()
    except Exception:
        pass
    if not playing_path:
        playing_path = rpc_meta.get("file") or ""

    saved_fn = win.getProperty("tuankaka.filename") or ""
    url_fn = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(playing_path).path)) if playing_path else ""
    filename = saved_fn if (len(saved_fn) > len(url_fn) and "." in saved_fn) else (url_fn or saved_fn)

    imdb_id = ""
    tmdb_id = ""
    for cand in (
        rpc_meta.get("imdb"),
        xbmc.getInfoLabel("VideoPlayer.IMDBNumber"),
        win.getProperty("tuankaka.imdb_id"),
        win.getProperty("tuankaka.media_id"),
    ):
        s_cand = str(cand or "").strip()
        if s_cand.startswith("tt") and not imdb_id:
            imdb_id = s_cand
        elif s_cand.startswith("tmdb:") and not tmdb_id:
            tmdb_id = s_cand.replace("tmdb:", "").strip()
        elif s_cand.isdigit() and not tmdb_id:
            tmdb_id = s_cand

    if not tmdb_id:
        tmdb_id = rpc_meta.get("tmdb") or (win.getProperty("tuankaka.tmdb_id") or "").strip()

    manual_q = urllib.parse.unquote(str((params or {}).get("searchstring") or "")).strip()
    title = (
        manual_q
        or rpc_meta.get("title")
        or xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
        or xbmc.getInfoLabel("VideoPlayer.OriginalTitle")
        or xbmc.getInfoLabel("VideoPlayer.Title")
        or win.getProperty("tuankaka.title")
        or ""
    ).strip()
    year = (
        rpc_meta.get("year")
        or xbmc.getInfoLabel("VideoPlayer.Year")
        or win.getProperty("tuankaka.year")
        or ""
    ).strip()

    if title and ("." in title or "_" in title):
        m_yr = re.search(r"^(.*?)[._ \((]+((?:19|20)\d{2})[._ \))]", title)
        if m_yr:
            title = re.sub(r"[._]+", " ", m_yr.group(1)).strip()
            if not year:
                year = m_yr.group(2)

    season = rpc_meta.get("season") or xbmc.getInfoLabel("VideoPlayer.Season") or win.getProperty("tuankaka.season") or ""
    episode = rpc_meta.get("episode") or xbmc.getInfoLabel("VideoPlayer.Episode") or win.getProperty("tuankaka.episode") or ""

    if (not str(season).isdigit() or int(season) <= 0) and (filename or manual_q):
        m_se = re.search(r"[sS](\d{1,2})[._ -]?[eE](\d{1,3})", f"{manual_q} {filename}")
        if m_se:
            season = m_se.group(1)
            episode = m_se.group(2)

    mtype = "series" if (str(season).isdigit() and int(season) > 0 and str(episode).isdigit() and int(episode) > 0) else "movie"

    if manual_q:
        clean_manual_title = re.sub(r"[sS]\d{1,2}[._ -]?[eE]\d{1,3}.*$", "", manual_q).strip()
        resolved_manual_tt = rent_sync.resolve_imdb_id_fast(title=clean_manual_title or manual_q, year=year, mtype=mtype)
        if resolved_manual_tt:
            imdb_id = resolved_manual_tt
            title = clean_manual_title or manual_q

    if not imdb_id:
        imdb_id = rent_sync.resolve_imdb_id_fast(imdb_id=imdb_id, tmdb_id=tmdb_id, title=title, year=year, mtype=mtype)

    return imdb_id, tmdb_id, mtype, season, episode, filename, title, year


def search_subtitles(handle=None, params=None):
    if handle is None:
        handle = int(sys.argv[1])
    if params is None:
        qs = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
        params = dict(urllib.parse.parse_qsl(qs))

    imdb_id, tmdb_id, mtype, season, episode, filename, title, year = _get_current_playing_metadata(params)

    raw_subs = rent_sync._fetch_stremio_subtitles_list(
        imdb_id=imdb_id,
        tmdb_id=tmdb_id,
        mtype=mtype,
        season=season,
        episode=episode,
        title=title,
        year=year,
    )

    if not raw_subs:
        xbmcplugin.endOfDirectory(handle)
        return

    ranked_subs = rent_sync.rank_and_annotate_subtitles(raw_subs, filename=filename)

    for idx, sub in enumerate(ranked_subs):
        sub_url = sub.get("url") or ""
        if not sub_url:
            continue

        display_label = sub.get("display_label") or f"Phụ đề #{idx + 1}"
        rating_str = str(sub.get("rating_5") or "4")
        is_synced = bool(sub.get("sync_flag", False))
        lang_name = sub.get("kodi_lang_name") or "Vietnamese"
        lang_flag = sub.get("kodi_lang_flag") or "vi"
        extra_headers = json.dumps(sub.get("headers") or {})

        li = xbmcgui.ListItem(label=lang_name, label2=display_label)
        li.setArt({"icon": rating_str, "thumb": lang_flag})
        li.setProperty("sync", "true" if is_synced else "false")
        li.setProperty("hearing_imp", "false")

        dl_params = urllib.parse.urlencode({
            "action": "download",
            "url": sub_url,
            "season": str(season or ""),
            "episode": str(episode or ""),
            "headers": extra_headers,
        })
        plugin_url = f"plugin://plugin.video.tuankaka.aio/?{dl_params}"
        xbmcplugin.addDirectoryItem(handle, plugin_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


def download_selected_subtitle(handle=None, params=None):
    if handle is None:
        handle = int(sys.argv[1])
    if params is None:
        qs = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
        params = dict(urllib.parse.parse_qsl(qs))

    sub_url = params.get("url", "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    headers_raw = params.get("headers", "{}")
    try:
        extra_headers = json.loads(headers_raw)
    except Exception:
        extra_headers = {}

    raw_bytes = rent_sync._http_get_bytes(sub_url, extra_headers=extra_headers, timeout=12)
    srt_bytes = rent_sync._extract_srt_from_bytes(raw_bytes, season=season, episode=episode)

    if srt_bytes and len(srt_bytes) > 60:
        local_file = os.path.join(SUB_SAVE_DIR, f"TuanKaka_Selected_{int(time.time())}.vi.srt")
        try:
            for fn in os.listdir(SUB_SAVE_DIR):
                if fn.startswith("TuanKaka_Selected_"):
                    try:
                        os.remove(os.path.join(SUB_SAVE_DIR, fn))
                    except Exception:
                        pass
        except Exception:
            pass

        with open(local_file, "wb") as f:
            f.write(srt_bytes)

        li = xbmcgui.ListItem(label=local_file)
        xbmcplugin.addDirectoryItem(handle, local_file, li, isFolder=False)
    else:
        xbmcgui.Dialog().notification(
            "Tuấn Kaká Subtitles",
            "Phụ đề này bị lỗi định dạng, vui lòng chọn dòng kế tiếp!",
            xbmcgui.NOTIFICATION_WARNING,
            3500,
        )

    xbmcplugin.endOfDirectory(handle)


if __name__ == "__main__":
    handle_arg = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).lstrip("-").isdigit() else -1
    qs_arg = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
    params_arg = dict(urllib.parse.parse_qsl(qs_arg))
    if params_arg.get("action") == "download":
        download_selected_subtitle(handle_arg, params_arg)
    else:
        search_subtitles(handle_arg, params_arg)