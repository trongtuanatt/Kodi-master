# -*- coding: utf-8 -*-
"""
Module Phụ đề rời chuẩn Kodi (xbmc.subtitle.module)
Khi khách bấm vào nút "Tải phụ đề (Download subtitle)" trên trình phát:
1. Tự động lấy tên file video thực tế đang phát (từ POV / Torus / Umbrella / Kodi Player).
2. Quét phụ đề từ AIO Worker + SubDL + SubSource.
3. Chấm điểm độ khớp với tên file video (Release Group, WEB-DL/BluRay, 2160p/1080p...)
   và XẾP CÁC BẢN PHỤ ĐỀ KHỚP NHẤT LÊN ĐẦU DANH SÁCH để khách chọn!
"""
import os
import re
import sys
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import rent_sync

HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon("plugin.video.tuankaka.aio")
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
SUB_SAVE_DIR = os.path.join(PROFILE_DIR, "subtitles_selected")
os.makedirs(SUB_SAVE_DIR, exist_ok=True)


def _get_current_playing_metadata():
    win = xbmcgui.Window(10000)

    # 1. Lấy tên file video thực tế đang phát để so khớp Release
    playing_path = ""
    try:
        playing_path = xbmc.Player().getPlayingFile()
    except Exception:
        pass
    saved_fn = win.getProperty("tuankaka.filename") or ""
    url_fn = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(playing_path).path)) if playing_path else ""
    filename = saved_fn if (len(saved_fn) > len(url_fn) and "." in saved_fn) else (url_fn or saved_fn or xbmc.getInfoLabel("VideoPlayer.Title"))

    # 2. Lấy IMDb ID / TMDb ID
    imdb_id = (
        xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
        or win.getProperty("tuankaka.imdb_id")
        or win.getProperty("tuankaka.media_id")
        or ""
    ).strip()
    tmdb_id = (win.getProperty("tuankaka.tmdb_id") or "").strip()

    # 3. Lấy Season & Episode (từ trình phát, từ Window property, hoặc tự bóc SxxExx trong tên file)
    season = xbmc.getInfoLabel("VideoPlayer.Season") or win.getProperty("tuankaka.season") or ""
    episode = xbmc.getInfoLabel("VideoPlayer.Episode") or win.getProperty("tuankaka.episode") or ""

    if (not str(season).isdigit() or int(season) <= 0) and filename:
        m_se = re.search(r"[sS](\d{1,2})[._ -]?[eE](\d{1,3})", filename)
        if m_se:
            season = m_se.group(1)
            episode = m_se.group(2)

    mtype = "series" if (str(season).isdigit() and int(season) > 0 and str(episode).isdigit() and int(episode) > 0) else "movie"
    return imdb_id, tmdb_id, mtype, season, episode, filename


def search_subtitles():
    imdb_id, tmdb_id, mtype, season, episode, filename = _get_current_playing_metadata()

    if not imdb_id and not tmdb_id:
        xbmcgui.Dialog().notification(
            "Tuấn Kaká Subtitles",
            "Không tìm thấy mã IMDb của video đang phát!",
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )
        xbmcplugin.endOfDirectory(HANDLE)
        return

    raw_subs = rent_sync._fetch_stremio_subtitles_list(
        imdb_id=imdb_id,
        tmdb_id=tmdb_id,
        mtype=mtype,
        season=season,
        episode=episode,
    )

    if not raw_subs:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Chấm điểm và xếp các bản phụ đề khớp với tên file phim nhất lên đầu danh sách!
    ranked_subs = rent_sync.rank_and_annotate_subtitles(raw_subs, filename=filename)

    for idx, sub in enumerate(ranked_subs):
        sub_url = sub.get("url") or ""
        if not sub_url:
            continue

        display_label = sub.get("display_label") or f"Phụ đề Tiếng Việt #{idx + 1}"
        rating_str = str(sub.get("rating_5") or "4")
        is_synced = bool(sub.get("sync_flag", False))
        extra_headers = json.dumps(sub.get("headers") or {})

        li = xbmcgui.ListItem(label="Vietnamese", label2=display_label)
        li.setArt({"icon": rating_str, "thumb": "vi"})
        li.setProperty("sync", "true" if is_synced else "false")
        li.setProperty("hearing_imp", "false")

        dl_params = urllib.parse.urlencode({
            "action": "download",
            "url": sub_url,
            "season": str(season or ""),
            "episode": str(episode or ""),
            "headers": extra_headers,
        })
        plugin_url = f"plugin://plugin.video.tuankaka.aio/?{dl_params}"
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def download_selected_subtitle(params):
    sub_url = params.get("url", "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    headers_raw = params.get("headers", "{}")
    try:
        extra_headers = json.loads(headers_raw)
    except Exception:
        extra_headers = {}

    raw_bytes = rent_sync._http_get_bytes(sub_url, extra_headers=extra_headers, timeout=12)
    srt_bytes = rent_sync._extract_srt_from_bytes(raw_bytes, season=season, episode=episode)

    if srt_bytes and len(srt_bytes) > 60:
        local_file = os.path.join(SUB_SAVE_DIR, f"TuanKaka_Selected_{int(time.time())}.vi.srt")
        # Dọn các file phụ đề cũ trong thư mục chọn tay
        try:
            for fn in os.listdir(SUB_SAVE_DIR):
                if fn.startswith("TuanKaka_Selected_"):
                    try:
                        os.remove(os.path.join(SUB_SAVE_DIR, fn))
                    except Exception:
                        pass
        except Exception:
            pass

        with open(local_file, "wb") as f:
            f.write(srt_bytes)

        li = xbmcgui.ListItem(label=local_file)
        xbmcplugin.addDirectoryItem(HANDLE, local_file, li, isFolder=False)
    else:
        xbmcgui.Dialog().notification(
            "Tuấn Kaká Subtitles",
            "Phụ đề này bị lỗi định dạng, vui lòng chọn dòng kế tiếp!",
            xbmcgui.NOTIFICATION_WARNING,
            3500,
        )

    xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    import json
    import time
    qs = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
    params = dict(urllib.parse.parse_qsl(qs))
    if params.get("action") == "download":
        download_selected_subtitle(params)
    else:
        search_subtitles()