# -*- coding: utf-8 -*-
"""
Tiến trình nền siêu nhẹ (Background Service) theo dõi tiến độ xem phim (Continue Watching Tracker):
- Tự động ghi nhớ giây đang xem (ResumeTime / TotalTime) mỗi 5 giây khi đang phát video.
- Khi dừng hoặc xem xong tập phim, tự động cập nhật Widget "Phim đang xem dở" ngoài màn hình chính.
"""
import time
import xbmc
import xbmcgui
import rent_sync


class ContinueWatchingTracker(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.tracking = False
        self.last_pos = 0.0
        self.total_len = 0.0
        self.cw_key = ""
        self.season = ""
        self.episode = ""

    def onAVStarted(self):
        win = xbmcgui.Window(10000)
        if win.getProperty("tuankaka.cw_active") != "1":
            self.tracking = False
            return
        self.cw_key = win.getProperty("tuankaka.cw_key_id") or win.getProperty("tuankaka.imdb_id") or ""
        self.season = win.getProperty("tuankaka.season") or ""
        self.episode = win.getProperty("tuankaka.episode") or ""
        self.last_pos = 0.0
        self.total_len = 0.0
        self.tracking = bool(self.cw_key)

    def onPlayBackStopped(self):
        self._flush_and_refresh()

    def onPlayBackEnded(self):
        if self.tracking and self.total_len > 0:
            self.last_pos = self.total_len
        self._flush_and_refresh()

    def _flush_and_refresh(self):
        if not self.tracking:
            return
        self.tracking = False
        win = xbmcgui.Window(10000)
        win.clearProperty("tuankaka.cw_active")
        if self.cw_key and self.total_len > 0:
            rent_sync.update_continue_watching_progress(
                self.cw_key,
                season=self.season,
                episode=self.episode,
                resume_time=self.last_pos,
                total_time=self.total_len,
            )
            try:
                xbmc.executebuiltin("Container.Refresh")
            except Exception:
                pass

    def tick(self):
        if not self.tracking or not self.isPlayingVideo():
            return
        try:
            pos = float(self.getTime())
            tot = float(self.getTotalTime())
            if tot > 60 and pos > 5:
                self.last_pos = pos
                self.total_len = tot
                rent_sync.update_continue_watching_progress(
                    self.cw_key,
                    season=self.season,
                    episode=self.episode,
                    resume_time=pos,
                    total_time=tot,
                )
        except Exception:
            pass


if __name__ == "__main__":
    tracker = ContinueWatchingTracker()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break
        tracker.tick()