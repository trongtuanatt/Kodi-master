# -*- coding: utf-8 -*-
"""
Kodi Cloud Debrid Sync Engine & Smart Subtitle Matcher
- Đồng bộ API Key Debrid theo thời hạn thuê từ Cloudflare Worker.
- Lưu ngữ cảnh tên file video đang phát và chấm điểm xếp hạng phụ đề khớp với tên file nhất.
"""
import json
import os
import re
import ssl
import time
import urllib.parse
import urllib.request

ADDON_TYPE = 'aio'
AUTO_DOWNLOAD_SUB_ON_PLAY = False

ADDON_ID_MAP = {
    "pov": "plugin.video.pov",
    "torus": "plugin.video.torus",
    "umbrella": "plugin.video.umbrella",
    "aio": "plugin.video.tuankaka.aio",
}
ADDON_ID = ADDON_ID_MAP.get(ADDON_TYPE, "plugin.video.pov")
SYNC_CACHE_TTL = 20

DEFAULT_PRIMARY_SERVER = "https://debrid-vip.trongtuanatt.workers.dev"
FALLBACK_SERVERS = [
    "https://debrid-vip.trongtuanatt.workers.dev",
    "https://phim4k-vip.trongtuanatt.workers.dev",
]
AIO_SUB_WORKER = 'https://aioaddon.trongtuanatt.workers.dev'
BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"


def _clean_srv(url):
    u = (url or "").strip().rstrip("/")
    for s in ("/manifest.json", "/admin/login", "/admin", "/kodi-sync", "/kodi"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u


def _get_kodi_objs():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    addon = xbmcaddon.Addon(ADDON_ID)
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    base = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    os.makedirs(profile, exist_ok=True)
    return xbmc, xbmcaddon, xbmcgui, xbmcvfs, addon, profile, base


def _load_config(profile, base):
    cfg = {"server_url": DEFAULT_PRIMARY_SERVER, "customer_code": ""}
    preset_path = os.path.join(base, "debrid_cloud_config.json")
    if os.path.exists(preset_path):
        try:
            with open(preset_path, "r", encoding="utf-8") as f:
                p = json.load(f)
                if p.get("server_url"):
                    cfg["server_url"] = p["server_url"]
                if p.get("customer_code"):
                    cfg["customer_code"] = p["customer_code"]
        except Exception:
            pass
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    if os.path.exists(user_path):
        try:
            with open(user_path, "r", encoding="utf-8") as f:
                u = json.load(f)
                if u.get("server_url"):
                    cfg["server_url"] = u["server_url"]
                if "customer_code" in u and u["customer_code"]:
                    cfg["customer_code"] = u["customer_code"]
                if "last_state" in u and isinstance(u["last_state"], dict):
                    cfg["last_state"] = u["last_state"]
        except Exception:
            pass
    cleaned = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    cfg["server_url"] = cleaned
    return cfg


def _save_user_config(profile, server_url, customer_code, last_state=None):
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    data = {"server_url": _clean_srv(server_url) or DEFAULT_PRIMARY_SERVER, "customer_code": customer_code.strip().lower()}
    if last_state is not None:
        data["last_state"] = last_state
    try:
        with open(user_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_customer_code():
    try:
        _, _, _, _, _, profile, base = _get_kodi_objs()
        cfg = _load_config(profile, base)
        return (cfg.get("customer_code") or "").strip()
    except Exception:
        return ""


def _http_get_json(url, timeout=10):
    headers = {"User-Agent": BROWSER_UA, "Accept": "application/json"}
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout, verify=False)
        if 200 <= r.status_code < 300:
            return r.json()
    except Exception:
        pass
    req = urllib.request.Request(url, headers=headers)
    try:
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))


def _get_or_create_device_id():
    try:
        import uuid
        import xbmcvfs
        ud = xbmcvfs.translatePath("special://userdata/")
        os.makedirs(ud, exist_ok=True)
        dev_file = os.path.join(ud, "vip_debrid_device_id.txt")
        if os.path.exists(dev_file):
            with open(dev_file, "r", encoding="utf-8") as f:
                val = f.read().strip()
                if len(val) >= 8:
                    return val
        new_id = "kbox_" + uuid.uuid4().hex[:12]
        with open(dev_file, "w", encoding="utf-8") as f:
            f.write(new_id)
        return new_id
    except Exception:
        return ""


def _fetch_sync_with_fallback(primary_server, customer_code, report_dead=False):
    q = urllib.parse.urlencode({
        "user": customer_code,
        "addon": ADDON_TYPE,
        "dev_id": _get_or_create_device_id(),
        "report_dead": "1" if report_dead else "0",
    })
    candidates = []
    for srv in [primary_server] + FALLBACK_SERVERS:
        c = _clean_srv(srv)
        if c and c not in candidates:
            candidates.append(c)

    last_data = None
    used_server = primary_server
    last_err = None

    for srv in candidates:
        url = f"{srv}/kodi-sync?{q}"
        try:
            data = _http_get_json(url, timeout=10)
            if isinstance(data, dict):
                last_data = data
                used_server = srv
                if data.get("status") not in ("invalid_user", "out_of_keys"):
                    return data, srv, None
        except Exception as exc:
            last_err = exc

    return last_data, used_server, last_err


def _set_kodi_default_subtitle_addon(xbmc):
    """Tự động đăng ký plugin.video.tuankaka.aio làm dịch vụ tải phụ đề mặc định khi khách bấm nút Phụ đề."""
    try:
        for setting_key in ("subtitles.tv", "subtitles.movie"):
            rpc = json.dumps({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "Settings.SetSettingValue",
                "params": {"setting": setting_key, "value": "plugin.video.tuankaka.aio"},
            })
            xbmc.executeJSONRPC(rpc)
    except Exception:
        pass


def _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=False):
    tb = (keys_map.get("torbox") or "").strip()
    rd = (keys_map.get("realdebrid") or "").strip()
    ad = (keys_map.get("alldebrid") or "").strip()
    pm = (keys_map.get("premiumize") or "").strip()
    oc = (keys_map.get("offcloud") or "").strip()

    if ADDON_TYPE == "pov":
        pairs = [
            ("tb.token", tb), ("tb.enabled", "true" if tb else "false"),
            ("rd.token", rd), ("rd.enabled", "true" if rd else "false"),
            ("ad.token", ad), ("ad.enabled", "true" if ad else "false"),
            ("pm.token", pm), ("pm.enabled", "true" if pm else "false"),
            ("oc.token", oc), ("oc.enabled", "true" if oc else "false"),
            ("subtitles.subs_action", "2" if not AUTO_DOWNLOAD_SUB_ON_PLAY else "1"),
            ("subtitles.language", "Vietnamese"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("pov_settings")
            try:
                from modules import kodi_utils
                kodi_utils.make_settings_dict()
            except Exception:
                pass

    elif ADDON_TYPE == "torus":
        any_tok = tb or rd or ad or pm or oc
        if force_write or addon.getSetting("torbox_api_key") != any_tok:
            addon.setSetting("torbox_api_key", any_tok)
        tok_file = os.path.join(profile, "torbox_token.json")
        if any_tok:
            try:
                with open(tok_file, "w", encoding="utf-8") as f:
                    json.dump({
                        "token": any_tok,
                        "torbox": tb,
                        "realdebrid": rd,
                        "alldebrid": ad,
                        "premiumize": pm,
                        "offcloud": oc,
                    }, f)
            except Exception:
                pass
        else:
            try:
                if os.path.exists(tok_file):
                    os.remove(tok_file)
            except Exception:
                pass

    elif ADDON_TYPE == "umbrella":
        pairs = [
            ("torboxtoken", tb), ("torbox.enable", "true" if tb else "false"),
            ("realdebridtoken", rd), ("realdebrid.enable", "true" if rd else "false"),
            ("alldebridtoken", ad), ("alldebrid.enable", "true" if ad else "false"),
            ("premiumizetoken", pm), ("premiumize.enable", "true" if pm else "false"),
            ("offcloudtoken", oc), ("offcloud.enable", "true" if oc else "false"),
            ("subtitles", "true" if AUTO_DOWNLOAD_SUB_ON_PLAY else "false"),
            ("subtitles.lang.1", "Vietnamese"),
            ("subtitles.utf", "true"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("umbrella_settings")


def sync_now(force=False, interactive=False, force_rotate=False, report_dead=False):
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    _set_kodi_default_subtitle_addon(xbmc)
    win = xbmcgui.Window(10000)
    prop_ts = f"{ADDON_ID}.rent_sync_ts"
    now = time.time()

    if not force and not interactive and not force_rotate and not report_dead:
        last_ts = float(win.getProperty(prop_ts) or "0")
        if now - last_ts < SYNC_CACHE_TTL:
            return True

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    customer_code = (cfg.get("customer_code") or "").strip().lower()
    prev_state = cfg.get("last_state") if isinstance(cfg.get("last_state"), dict) else {}
    prev_ver = str(prev_state.get("version") or "")
    prev_keys = prev_state.get("keys") if isinstance(prev_state.get("keys"), dict) else {}

    if not customer_code:
        if interactive:
            return prompt_and_activate()
        return False

    data, active_srv, err = _fetch_sync_with_fallback(
        server_url,
        customer_code,
        report_dead=bool(report_dead),
    )

    if not isinstance(data, dict):
        if interactive:
            xbmcgui.Dialog().ok(
                "Lỗi kết nối Server",
                f"Không thể kết nối tới Server quản lý ({server_url}) - Chi tiết: {err}",
            )
        return False

    server_url = _clean_srv(data.get("new_server_url")) or active_srv
    win.setProperty(prop_ts, str(now))
    keys_map = data.get("keys") or {}
    ok = bool(data.get("ok"))
    status = data.get("status") or ""
    msg = data.get("message") or ""
    warn = data.get("warning") or ""
    new_ver = str(data.get("version") or "")
    days_left = data.get("days_left", "")
    auto_rotated = bool(data.get("auto_rotated"))
    keys_changed = bool(prev_keys and keys_map != prev_keys)
    version_changed = bool(new_ver and prev_ver and new_ver != prev_ver)

    if ok:
        _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=(version_changed or keys_changed or auto_rotated or interactive))
        _save_user_config(profile, server_url, customer_code, last_state=data)
        warn_prop = f"{ADDON_ID}.warn_shown"
        if not warn or version_changed:
            win.clearProperty(warn_prop)
        if interactive:
            xbmcgui.Dialog().ok("Kích hoạt VIP Debrid thành công", msg)
        elif auto_rotated or keys_changed:
            pass
        elif version_changed:
            xbmcgui.Dialog().notification(
                "Đã cập nhật VIP Debrid",
                f"Đồng bộ bản v{new_ver} thành công (Còn {days_left} ngày)",
                xbmcgui.NOTIFICATION_INFO,
                4500,
            )
        elif warn:
            if not win.getProperty(warn_prop):
                win.setProperty(warn_prop, "1")
                xbmcgui.Dialog().notification("Sắp hết hạn VIP", warn, xbmcgui.NOTIFICATION_WARNING, 6000)
        return True
    else:
        empty_keys = {"torbox": "", "realdebrid": "", "alldebrid": "", "premiumize": "", "offcloud": ""}
        _apply_keys_to_addon(addon, profile, xbmcgui, empty_keys, force_write=True)
        _save_user_config(profile, server_url, customer_code, last_state=data)
        if interactive or status in ("expired", "locked"):
            xbmcgui.Dialog().ok("Thông báo Tài khoản VIP", msg or "Gói dịch vụ đã hết hạn hoặc tạm khóa.")
        return False


def prompt_and_activate():
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    current_code = (cfg.get("customer_code") or "").strip()

    if current_code:
        choices = [
            f"Đồng bộ & Kiểm tra hạn dùng (Mã: {current_code})",
            "Nhập Mã khách hàng (PIN) khác",
            f"Đổi địa chỉ Server (Hiện tại: {server_url})",
        ]
        sel = xbmcgui.Dialog().select("Quản lý Tài khoản VIP Debrid", choices)
        if sel < 0:
            return False
        if sel == 0:
            return sync_now(force=True, interactive=True, force_rotate=False)
        if sel == 2:
            new_srv = xbmcgui.Dialog().input("Nhập địa chỉ Cloudflare Worker", defaultt=server_url, type=xbmcgui.INPUT_ALPHANUM)
            if new_srv and new_srv.strip():
                server_url = _clean_srv(new_srv)
                _save_user_config(profile, server_url, current_code)
            return sync_now(force=True, interactive=True, force_rotate=False)

    new_code = xbmcgui.Dialog().input(
        "Nhập Mã kích hoạt VIP (Admin cấp)",
        defaultt=current_code,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not new_code or not new_code.strip():
        return False

    _save_user_config(profile, server_url, new_code.strip().lower())
    ok = sync_now(force=True, interactive=True, force_rotate=False)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    return ok


# ==============================================================================
# HỆ THỐNG PHỤ ĐỀ THÔNG MINH (LỌC & XẾP HẠNG KHỚP VỚI FILE PHIM ĐANG PHÁT)
# ==============================================================================
SUBDL_UPSTREAMS = [
    "https://subdl.strem.top/c3ViZGxfMWd0MlNTRnQ0WlJNcGd4dG44SlN4ZE52MDhheTNkaE82blY4MGNlZUNndy9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfTVJaNE5IX0RkNjhJaG9LWGtpUUxlS2U3d1V0NUhsTVotaTlRWGNEU2R3QS9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfTkJXcVNIX2pHc1d0QnFWbGRnZlhraFA2NThINnQ4aDduRkdGRW8yMXp1OC9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfY1kyRUxOaXY2bUdTeXlGcDU2REtzYnRfUGFJci10TVQwNm1qMU9hcHhFWS9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfejhSVTJLM2w3TERyS21xNlNQRUdKRWNhSU9Hc1FDYWh2LVVLX2hvZXptSS9WSS9oaUluY2x1ZGUv",
]

SUBSOURCE_UPSTREAMS = [
    "https://subsource.strem.top/c2tfOGZjODA2YzBlYTI3ZGU1MDM3OTUwMzc1NjA4Yzc1MzMwYzY2NjAzMzY2N2ViNzA4OWM0Zjg4YTE0NWE3ZjYzNC92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
    "https://subsource.strem.top/c2tfMWIyZDYzZTU3ODNmYzFlY2M2Y2E4NjZkMzc5OGMyNjU3NDA2YzE5YmFlOTdlNTdmZTVjYmJhN2QzYzUzNGJmOC92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
    "https://subsource.strem.top/c2tfN2QwZmI2NzU2MTg0MjZmZDlhZDMyYjhhZWVmYmZjZTM3OGY1NDQwN2NhNGEzYWRiODNlNTcyMjIzMzM4YzFlNy92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
]

SUBDL_API_KEYS = [
    "subdl_1gt2SSFt4ZRMpgxtn8JSxdNv08ay3dhO6nV80ceeCgw",
    "subdl_MRZ4NH_Dd68IhoKXkiQLeKe7wUt5HlMZ-i9QXcDSdwA",
    "subdl_NBWqSH_jGsWtBqVldgfXkhP658H6t8h7nFGFEo21zu8",
    "subdl_cY2ELNiv6mGSyyFp56DKsbt_PaIr-tMT06mj1OapxEY",
    "subdl_z8RU2K3l7LDrKmq6SPEGJEcaIOGsQCahv-UK_hoezmI",
]

SUBSOURCE_API_KEYS = [
    "sk_8fc806c0ea27de5037950375608c75330c666033667eb7089c4f88a145a7f634",
    "sk_1b2d63e5783fc1ecc6ca866d3798c2657406c19bae97e57fe5cbba7d3c534bf8",
    "sk_7d0fb675618426fd9ad32b8aeefbfce378f54407ca4a3adb83e572223338c1e7",
]


def save_playing_context(imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename=""):
    """Ghi thông tin bộ phim và tên file gốc của luồng Debrid vào bộ nhớ Kodi để trình chọn Sub đối chiếu."""
    try:
        import xbmc
        import xbmcgui
        _set_kodi_default_subtitle_addon(xbmc)
        win = xbmcgui.Window(10000)
        if imdb_id:
            win.setProperty("tuankaka.imdb_id", str(imdb_id))
            win.setProperty("tuankaka.media_id", str(imdb_id))
        if tmdb_id:
            win.setProperty("tuankaka.tmdb_id", str(tmdb_id))
            if not imdb_id:
                win.setProperty("tuankaka.media_id", f"tmdb:{tmdb_id}")
        if mtype:
            win.setProperty("tuankaka.media_type", str(mtype))
        if season is not None:
            win.setProperty("tuankaka.season", str(season))
        if episode is not None:
            win.setProperty("tuankaka.episode", str(episode))
        if filename:
            clean_fn = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(str(filename)).path))
            win.setProperty("tuankaka.filename", clean_fn or str(filename))
    except Exception:
        pass


def _unwrap_stremio_sub_url(raw_url):
    u = str(raw_url or "").strip()
    if not u:
        return ""
    if "from=" in u:
        try:
            parsed = urllib.parse.urlsplit(u)
            qs = dict(urllib.parse.parse_qsl(parsed.query))
            if qs.get("from"):
                u = urllib.parse.unquote(qs["from"]).strip()
        except Exception:
            pass
    try:
        p = urllib.parse.urlsplit(u)
        clean_path = urllib.parse.quote(urllib.parse.unquote(p.path), safe="/:@!$&'()*+,;=-._~")
        u = urllib.parse.urlunsplit((p.scheme, p.netloc, clean_path, p.query, p.fragment))
    except Exception:
        pass
    return u


def _http_get_bytes(url, extra_headers=None, timeout=10):
    u = _unwrap_stremio_sub_url(url)
    if not u:
        return b""
    headers = {"User-Agent": BROWSER_UA, "Accept": "*/*"}
    if isinstance(extra_headers, dict):
        headers.update(extra_headers)
    try:
        import requests
        r = requests.get(u, headers=headers, timeout=timeout, verify=False)
        if 200 <= r.status_code < 300 and r.content:
            return r.content
    except Exception:
        pass
    try:
        req = urllib.request.Request(u, headers=headers)
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return resp.read()
    except Exception:
        pass
    try:
        proxy_url = f"{DEFAULT_PRIMARY_SERVER}/sub-proxy?url=" + urllib.parse.quote(u, safe="")
        import requests
        r2 = requests.get(proxy_url, headers={"User-Agent": BROWSER_UA}, timeout=timeout, verify=False)
        if 200 <= r2.status_code < 300 and r2.content:
            return r2.content
    except Exception:
        pass
    return b""


def _format_srt_time(h, m, s, ms):
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(ms):03d}"


def _parse_any_timestamp_to_srt(ts_str):
    t = ts_str.strip()
    m = re.match(r"^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})", t)
    if not m:
        return None
    hh = int(m.group(1) or 0)
    mm = int(m.group(2) or 0)
    ss = int(m.group(3) or 0)
    raw_ms = m.group(4)
    if len(raw_ms) == 1:
        ms = int(raw_ms) * 100
    elif len(raw_ms) == 2:
        ms = int(raw_ms) * 10
    else:
        ms = int(raw_ms[:3])
    return _format_srt_time(hh, mm, ss, ms)


def _convert_ass_to_srt_text(ass_text):
    out_blocks = []
    idx = 1
    for line in ass_text.splitlines():
        if not line.startswith("Dialogue:"):
            continue
        parts = line[9:].lstrip().split(",", 9)
        if len(parts) < 10:
            continue
        start_srt = _parse_any_timestamp_to_srt(parts[1])
        end_srt = _parse_any_timestamp_to_srt(parts[2])
        if not start_srt or not end_srt or start_srt == end_srt:
            continue
        dialogue = parts[9]
        dialogue = re.sub(r"\{[^\}]*\}", "", dialogue)
        dialogue = dialogue.replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ").strip()
        if not dialogue:
            continue
        out_blocks.append(f"{idx}\r\n{start_srt} --> {end_srt}\r\n{dialogue}")
        idx += 1
    return "\r\n\r\n".join(out_blocks) + ("\r\n" if out_blocks else "")


def _normalize_to_strict_srt(raw_text):
    if not raw_text:
        return ""
    txt = raw_text.replace("\ufeff", "").replace("\x00", "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not txt:
        return ""

    low_head = txt[:400].lower()
    if low_head.startswith("<!doctype") or low_head.startswith("<html") or low_head.startswith("{\"error"):
        return ""

    if "dialogue:" in txt.lower() and "-->" not in txt:
        txt = _convert_ass_to_srt_text(txt).replace("\r\n", "\n")

    if "-->" not in txt:
        return ""

    lines = txt.split("\n")
    cues = []
    i = 0
    n_lines = len(lines)

    while i < n_lines:
        line = lines[i].strip()
        if "-->" in line:
            parts = line.split("-->")
            if len(parts) >= 2:
                left_ts = _parse_any_timestamp_to_srt(parts[0])
                right_raw = parts[1].strip().split()[0] if parts[1].strip() else ""
                right_ts = _parse_any_timestamp_to_srt(right_raw)
                if left_ts and right_ts:
                    i += 1
                    text_lines = []
                    while i < n_lines and lines[i].strip() != "":
                        if "-->" in lines[i] and _parse_any_timestamp_to_srt(lines[i].split("-->")[0]):
                            break
                        if lines[i].strip().isdigit() and (i + 1 < n_lines) and "-->" in lines[i + 1]:
                            break
                        clean_l = re.sub(r"\{[^\}]*\}", "", lines[i].strip())
                        if clean_l:
                            text_lines.append(clean_l)
                        i += 1
                    if text_lines:
                        joined_text = "\r\n".join(text_lines)
                        low_t = joined_text.lower()
                        if left_ts.startswith("00:00:00") and any(w in low_t for w in ("subdl.strem", "subsource.strem", "donated", "support note")):
                            continue
                        cues.append((left_ts, right_ts, joined_text))
                    continue
        i += 1

    if len(cues) < 3:
        return ""

    out_lines = []
    for idx, (st, et, body) in enumerate(cues, 1):
        out_lines.append(f"{idx}\r\n{st} --> {et}\r\n{body}")
    return "\r\n\r\n".join(out_lines) + "\r\n"


def _extract_srt_from_bytes(raw_bytes, season=None, episode=None):
    if not raw_bytes or len(raw_bytes) < 40:
        return b""

    if raw_bytes[:2] == b"\x1f\x8b":
        try:
            import gzip
            raw_bytes = gzip.decompress(raw_bytes)
        except Exception:
            pass

    if raw_bytes[:4] == b"PK\x03\x04":
        try:
            import io
            import zipfile
            with zipfile.ZipFile(io.BytesIO(raw_bytes)) as zf:
                valid_names = []
                for n in zf.namelist():
                    if n.endswith("/") or "__MACOSX" in n or os.path.basename(n).startswith("._"):
                        continue
                    if n.lower().endswith((".srt", ".vtt", ".ass", ".ssa", ".sub")):
                        valid_names.append(n)
                if not valid_names:
                    return b""

                chosen_name = valid_names[0]
                try:
                    s_num = int(season) if season not in (None, "", "0", 0) else 0
                    e_num = int(episode) if episode not in (None, "", "0", 0) else 0
                    if s_num > 0 and e_num > 0 and len(valid_names) > 1:
                        pats = [
                            f"s{s_num:02d}e{e_num:02d}",
                            f"s{s_num}e{e_num:02d}",
                            f"{s_num}x{e_num:02d}",
                            f"e{e_num:02d}",
                            f"ep{e_num:02d}",
                        ]
                        for cand in valid_names:
                            c_low = os.path.basename(cand).lower()
                            if any(p in c_low for p in pats):
                                chosen_name = cand
                                break
                except Exception:
                    pass
                raw_bytes = zf.read(chosen_name)
        except Exception:
            return b""

    decoded_text = ""
    encodings_order = ("utf-8-sig", "utf-8", "utf-16", "cp1258", "windows-1252", "latin-1")
    if raw_bytes.startswith((b"\xff\xfe", b"\xfe\xff")):
        encodings_order = ("utf-16", "utf-8-sig", "utf-8", "cp1258", "latin-1")

    for enc in encodings_order:
        try:
            cand_txt = raw_bytes.decode(enc)
            if "-->" in cand_txt or "Dialogue:" in cand_txt:
                decoded_text = cand_txt
                break
        except Exception:
            continue

    if not decoded_text:
        return b""

    strict_srt = _normalize_to_strict_srt(decoded_text)
    if not strict_srt:
        return b""

    return b"\xef\xbb\xbf" + strict_srt.encode("utf-8")


def _fetch_subdl_direct_api(vid_id, is_series=False, s_num=0, e_num=0):
    import random
    if not vid_id.startswith("tt") or not SUBDL_API_KEYS:
        return []
    out = []
    keys_to_try = random.sample(SUBDL_API_KEYS, min(2, len(SUBDL_API_KEYS)))
    for api_k in keys_to_try:
        try:
            q_params = {
                "api_key": api_k,
                "imdb_id": vid_id,
                "languages": "VI",
                "subs_per_page": "30",
                "type": "tv" if (is_series and s_num > 0 and e_num > 0) else "movie",
            }
            if is_series and s_num > 0 and e_num > 0:
                q_params["season_number"] = str(s_num)
                q_params["episode_number"] = str(e_num)
            direct_url = "https://api.subdl.com/api/v1/subtitles?" + urllib.parse.urlencode(q_params)
            d_res = _http_get_json(direct_url, timeout=7)
            if isinstance(d_res, dict) and isinstance(d_res.get("subtitles"), list) and d_res["subtitles"]:
                for item in d_res["subtitles"]:
                    dl_link = item.get("url") or ""
                    if dl_link and not dl_link.startswith("http"):
                        dl_link = "https://dl.subdl.com" + (dl_link if dl_link.startswith("/") else "/" + dl_link)
                    rel_name = item.get("release_name") or item.get("name") or "SubDL_VI"
                    if dl_link:
                        out.append({
                            "id": str(rel_name),
                            "title": str(rel_name),
                            "release_name": str(rel_name),
                            "url": dl_link,
                            "lang": "vie",
                            "provider": "SubDL",
                            "source": "subdl_direct",
                        })
                if out:
                    break
        except Exception:
            continue
    return out


def _fetch_subsource_direct_api(vid_id, is_series=False, s_num=0, e_num=0):
    import random
    if not vid_id.startswith("tt") or not SUBSOURCE_API_KEYS:
        return []
    out = []
    api_k = random.choice(SUBSOURCE_API_KEYS)
    headers = {"User-Agent": BROWSER_UA, "Accept": "application/json", "X-API-Key": api_k}
    try:
        import requests
        q = {"imdb": vid_id, "language": "vietnamese"}
        if is_series and s_num > 0:
            q["season"] = str(s_num)
        r = requests.get("https://api.subsource.net/api/v1/subtitles", params=q, headers=headers, timeout=7, verify=False)
        if r.status_code == 200:
            data = r.json()
            sub_items = data if isinstance(data, list) else (data.get("subtitles") or data.get("data") or [])
            if isinstance(sub_items, list):
                for item in sub_items:
                    if not isinstance(item, dict):
                        continue
                    sub_id = item.get("id") or item.get("subtitleId") or item.get("subId")
                    dl_url = item.get("downloadUrl") or item.get("url") or (f"https://api.subsource.net/api/v1/subtitles/{sub_id}/download" if sub_id else "")
                    rel = item.get("releaseName") or item.get("release_info") or item.get("title") or "SubSource_VI"
                    if dl_url:
                        out.append({
                            "id": str(rel),
                            "title": str(rel),
                            "release_name": str(rel),
                            "url": dl_url,
                            "lang": "vie",
                            "provider": "SubSource",
                            "headers": {"X-API-Key": api_k},
                            "source": "subsource_direct",
                        })
    except Exception:
        pass
    return out


def _fetch_stremio_subtitles_list(imdb_id, tmdb_id="", mtype="movie", season=None, episode=None):
    import random
    import threading

    vid_id = str(imdb_id or "").strip()
    if vid_id and vid_id.isdigit():
        vid_id = "tt" + vid_id
    if not vid_id and tmdb_id:
        vid_id = f"tmdb:{tmdb_id}"
    if not vid_id:
        return []

    has_se = False
    try:
        s_num = int(season) if season not in (None, "", "0", 0) else 0
        e_num = int(episode) if episode not in (None, "", "0", 0) else 0
        has_se = s_num > 0 and e_num > 0
    except Exception:
        s_num, e_num = 0, 0

    is_series = has_se or str(mtype).lower() in ("series", "episode", "tv", "show")
    if is_series and has_se:
        stremio_type = "series"
        stremio_id = f"{vid_id}:{s_num}:{e_num}"
    else:
        stremio_type = "movie"
        stremio_id = vid_id

    sub_path = f"/subtitles/{stremio_type}/{stremio_id}.json"

    stremio_targets = [f"{AIO_SUB_WORKER}{sub_path}"]
    if SUBDL_UPSTREAMS:
        stremio_targets.append(f"{random.choice(SUBDL_UPSTREAMS)}{sub_path}")
    if SUBSOURCE_UPSTREAMS:
        stremio_targets.append(f"{random.choice(SUBSOURCE_UPSTREAMS)}{sub_path}")

    results_box = [[] for _ in range(len(stremio_targets) + 2)]

    def _stremio_worker(idx, u):
        try:
            data = _http_get_json(u, timeout=7)
            if isinstance(data, dict) and isinstance(data.get("subtitles"), list):
                prov = "AIO" if AIO_SUB_WORKER in u else ("SubDL" if "subdl" in u else "SubSource")
                items = []
                for s in data["subtitles"]:
                    if isinstance(s, dict):
                        sc = dict(s)
                        sc.setdefault("provider", prov)
                        items.append(sc)
                results_box[idx] = items
        except Exception:
            pass

    def _subdl_direct_worker(idx):
        results_box[idx] = _fetch_subdl_direct_api(vid_id, is_series, s_num, e_num)

    def _subsource_direct_worker(idx):
        results_box[idx] = _fetch_subsource_direct_api(vid_id, is_series, s_num, e_num)

    threads = [
        threading.Thread(target=_subdl_direct_worker, args=(0,)),
        threading.Thread(target=_subsource_direct_worker, args=(1,)),
    ]
    for i, u in enumerate(stremio_targets):
        threads.append(threading.Thread(target=_stremio_worker, args=(i + 2, u)))

    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(timeout=8)

    collected = []
    for sub_list in results_box:
        if sub_list:
            collected.extend(sub_list)

    seen_urls = set()
    vi_subs = []
    other_subs = []
    for s in collected:
        if not isinstance(s, dict):
            continue
        u = _unwrap_stremio_sub_url(s.get("url") or "")
        if not u or u in seen_urls:
            continue
        seen_urls.add(u)
        s_copy = dict(s)
        s_copy["url"] = u
        lang = str(s_copy.get("lang") or s_copy.get("language") or "vie").lower()
        if any(w in lang for w in ("vi", "vie", "viet", "vn")) or "subdl" in u or "subsource" in u:
            vi_subs.append(s_copy)
        else:
            other_subs.append(s_copy)

    return vi_subs + other_subs


def _extract_release_features(name_str):
    """Phân tích các thuộc tính kỹ thuật của tên file video / tên bản phụ đề để so khớp chính xác."""
    s = str(name_str or "").lower()
    features = {
        "res": "",
        "source": "",
        "service": "",
        "edition": set(),
        "group": "",
    }
    if any(k in s for k in ("2160p", "4k", "uhd")):
        features["res"] = "2160p"
    elif "1080p" in s:
        features["res"] = "1080p"
    elif "720p" in s:
        features["res"] = "720p"

    if any(k in s for k in ("remux", "bluray", "blu-ray", "bdrip", "brrip", "bdremux")):
        features["source"] = "BluRay"
    elif any(k in s for k in ("web-dl", "webdl", "webrip", "web-rip", ".web.")):
        features["source"] = "WEB"
    elif any(k in s for k in ("hdtv", "pdtv")):
        features["source"] = "HDTV"
    elif any(k in s for k in ("hdcam", "camrip", "hdts", "telesync")):
        features["source"] = "CAM"

    for srv in ("amzn", "nf", "netflix", "dsnp", "atvp", "hmax", "pcok", "hulu", "ip"):
        if re.search(r"\b" + srv + r"\b", s):
            features["service"] = "NF" if srv == "netflix" else srv.upper()
            break

    for ed in ("extended", "imax", "directors.cut", "director's cut", "unrated", "repack", "proper"):
        if ed in s:
            features["edition"].add(ed.split(".")[0].upper())

    # Tách Release Group ở cuối tên file (ví dụ: -FLUX, -NTb, -RARBG, -PSA)
    clean_no_ext = re.sub(r"\.(mkv|mp4|avi|srt|zip|vtt|ass)$", "", s.strip())
    m_grp = re.search(r"-([a-z0-9]{2,12})(?:\[.*\])?$", clean_no_ext)
    if m_grp:
        grp = m_grp.group(1)
        if grp not in ("dl", "rip", "hd", "sub", "vi", "vie", "x264", "x265", "h264", "h265", "hevc"):
            features["group"] = grp.upper()

    return features


def rank_and_annotate_subtitles(subs_list, filename=""):
    """
    Chấm điểm độ khớp của từng phụ đề với tên file video đang phát,
    sắp xếp các bản khớp nhất lên đầu và gắn nhãn hiển thị rõ ràng cho người dùng chọn.
    """
    if not subs_list:
        return []
    from difflib import SequenceMatcher

    clean_fn_raw = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(str(filename or "")).path))
    if clean_fn_raw.lower() in ("", "play", "stream", "video", "index.m3u8"):
        clean_fn_raw = str(filename or "")
    file_feat = _extract_release_features(clean_fn_raw)
    norm_fn = re.sub(r"\W+", " ", clean_fn_raw.lower()).strip()

    scored_items = []
    for idx, sub in enumerate(subs_list):
        raw_label = str(
            sub.get("release_name")
            or sub.get("title")
            or sub.get("SubFileName")
            or sub.get("id")
            or f"Phụ đề #{idx + 1}"
        ).strip()
        # Làm sạch tên hiển thị nếu chỉ là URL hoặc ID ngắn
        if raw_label.startswith("http"):
            raw_label = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(raw_label).path))

        sub_feat = _extract_release_features(raw_label)
        norm_sub = re.sub(r"\W+", " ", raw_label.lower()).strip()

        score = 0.0
        matched_tags = []

        if clean_fn_raw:
            # 1. So khớp Nhóm phát hành (Release Group: FLUX, NTb, RARBG, PSA...)
            if file_feat["group"] and sub_feat["group"] and file_feat["group"] == sub_feat["group"]:
                score += 38.0
                matched_tags.append(file_feat["group"])

            # 2. So khớp Nguồn video (WEB-DL/WEBRip vs BluRay/REMUX)
            if file_feat["source"] and sub_feat["source"]:
                if file_feat["source"] == sub_feat["source"]:
                    score += 28.0
                    matched_tags.append(sub_feat["source"])
                else:
                    score -= 12.0
            elif sub_feat["source"]:
                matched_tags.append(sub_feat["source"])

            # 3. So khớp Dịch vụ Streaming (AMZN, NF, DSNP, ATVP...)
            if file_feat["service"] and sub_feat["service"] and file_feat["service"] == sub_feat["service"]:
                score += 14.0
                matched_tags.append(sub_feat["service"])

            # 4. So khớp Độ phân giải (2160p, 1080p, 720p)
            if file_feat["res"] and sub_feat["res"] and file_feat["res"] == sub_feat["res"]:
                score += 10.0
                matched_tags.append(sub_feat["res"])
            elif sub_feat["res"]:
                matched_tags.append(sub_feat["res"])

            # 5. So khớp Phiên bản đặc biệt (EXTENDED, IMAX, DIRECTORS CUT)
            if file_feat["edition"] or sub_feat["edition"]:
                if file_feat["edition"] == sub_feat["edition"]:
                    score += 15.0
                    matched_tags.extend(list(sub_feat["edition"]))
                else:
                    score -= 20.0

            # 6. Độ tương đồng toàn chuỗi tên file
            seq_ratio = SequenceMatcher(None, norm_fn, norm_sub).ratio() if (norm_fn and norm_sub) else 0.0
            score += seq_ratio * 25.0
        else:
            if sub_feat["source"]:
                matched_tags.append(sub_feat["source"])
            if sub_feat["res"]:
                matched_tags.append(sub_feat["res"])
            if sub_feat["group"]:
                matched_tags.append(sub_feat["group"])

        # Ưu tiên nhẹ cho nguồn .zip gốc từ SubDL / SubSource Direct
        if sub.get("source") in ("subdl_direct", "subsource_direct"):
            score += 4.0

        pct = max(10, min(99, int(round(score))))
        if pct >= 75:
            rating_5 = "5"
            prefix = f"[COLOR springgreen][🎯 Khớp {pct}%][/COLOR]"
        elif pct >= 48:
            rating_5 = "4"
            prefix = f"[COLOR yellow][⭐ Khớp {pct}%][/COLOR]"
        elif clean_fn_raw and pct >= 28:
            rating_5 = "3"
            prefix = f"[COLOR deepskyblue][Khớp {pct}%][/COLOR]"
        else:
            rating_5 = "3"
            prefix = "[COLOR silver][Phụ đề][/COLOR]"

        provider_str = sub.get("provider") or ("SubDL" if "subdl" in str(sub.get("url", "")) else "SubSource")
        tag_str = f" • {' '.join(matched_tags)}" if matched_tags else ""
        display_label = f"{prefix} [{provider_str}{tag_str}] {raw_label}"

        item_copy = dict(sub)
        item_copy["match_score"] = score
        item_copy["rating_5"] = rating_5
        item_copy["display_label"] = display_label
        item_copy["sync_flag"] = bool(pct >= 65)
        scored_items.append((score, -idx, item_copy))

    scored_items.sort(reverse=True)
    return [x[2] for x in scored_items]


def _rank_subtitles_for_file(subs_list, filename=""):
    return rank_and_annotate_subtitles(subs_list, filename=filename)


def auto_load_stremio_subtitles(player=None, imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", poster=""):
    """
    Khi mở phim: Lưu thông tin tên file đang phát vào bộ nhớ Kodi.
    Nếu AUTO_DOWNLOAD_SUB_ON_PLAY = False (mặc định), KHÔNG tải sẵn sub ngầm mà để khách tự bấm chọn trong bảng Phụ đề!
    """
    save_playing_context(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode, filename=filename)
    if not AUTO_DOWNLOAD_SUB_ON_PLAY:
        return False

    try:
        xbmc, _, xbmcgui, xbmcvfs, addon, profile, _ = _get_kodi_objs()
    except Exception:
        return False

    vid_key = f"{imdb_id or tmdb_id}_{season or 0}_{episode or 0}"
    if not imdb_id and not tmdb_id:
        return False

    subs = _fetch_stremio_subtitles_list(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode)
    if not subs:
        return False

    ranked = rank_and_annotate_subtitles(subs, filename=filename)
    sub_dir = os.path.join(profile, "subtitles_vip")
    os.makedirs(sub_dir, exist_ok=True)
    clean_tag = "".join(c for c in vid_key if c.isalnum() or c == "_")

    for sub_item in ranked[:5]:
        sub_url = str(sub_item.get("url") or "").strip()
        if not sub_url:
            continue
        try:
            raw_bytes = _http_get_bytes(sub_url, extra_headers=sub_item.get("headers"), timeout=8)
            srt_bytes = _extract_srt_from_bytes(raw_bytes, season=season, episode=episode)
            if srt_bytes and len(srt_bytes) > 100:
                local_path = os.path.join(sub_dir, f"SubVIP_{clean_tag}_1.vi.srt")
                with open(local_path, "wb") as f:
                    f.write(srt_bytes)
                if player is None:
                    player = xbmc.Player()
                player.setSubtitles(local_path)
                player.showSubtitles(True)
                return True
        except Exception:
            continue
    return False


def auto_load_stremio_subtitles_async(imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", player=None, poster=""):
    save_playing_context(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode, filename=filename)
    if not AUTO_DOWNLOAD_SUB_ON_PLAY:
        return None
    import threading
    t = threading.Thread(
        target=auto_load_stremio_subtitles,
        kwargs={
            "player": player,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "mtype": mtype,
            "season": season,
            "episode": episode,
            "filename": filename,
            "poster": poster,
        },
    )
    t.daemon = True
    t.start()
    return t
