# -*- coding: utf-8 -*-
"""
Kodi Cloud Debrid Sync Engine, Direct Stream Scraper & Smart Subtitle Matcher (V7.3)
"""
import base64
import json
import os
import re
import ssl
import time
import urllib.parse
import urllib.request

ADDON_TYPE = 'aio'
AUTO_DOWNLOAD_SUB_ON_PLAY = False

ADDON_ID_MAP = {
    "pov": "plugin.video.pov",
    "torus": "plugin.video.torus",
    "umbrella": "plugin.video.umbrella",
    "aio": "plugin.video.tuankaka.aio",
}
ADDON_ID = ADDON_ID_MAP.get(ADDON_TYPE, "plugin.video.pov")
SYNC_CACHE_TTL = 20

DEFAULT_PRIMARY_SERVER = "https://debrid-vip.trongtuanatt.workers.dev"
FALLBACK_SERVERS = [
    "https://debrid-vip.trongtuanatt.workers.dev",
    "https://phim4k-vip.trongtuanatt.workers.dev",
]
AIO_SUB_WORKER = 'https://aioaddon.trongtuanatt.workers.dev'
BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"


def _clean_srv(url):
    u = (url or "").strip().rstrip("/")
    for s in ("/manifest.json", "/admin/login", "/admin", "/kodi-sync", "/kodi"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u


def _get_kodi_objs():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    addon = xbmcaddon.Addon(ADDON_ID)
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    base = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    os.makedirs(profile, exist_ok=True)
    return xbmc, xbmcaddon, xbmcgui, xbmcvfs, addon, profile, base


def _load_config(profile, base):
    cfg = {"server_url": DEFAULT_PRIMARY_SERVER, "customer_code": ""}
    preset_path = os.path.join(base, "debrid_cloud_config.json")
    if os.path.exists(preset_path):
        try:
            with open(preset_path, "r", encoding="utf-8") as f:
                p = json.load(f)
                if p.get("server_url"):
                    cfg["server_url"] = p["server_url"]
                if p.get("customer_code"):
                    cfg["customer_code"] = p["customer_code"]
                if isinstance(p.get("static_keys"), dict):
                    cfg["static_keys"] = p["static_keys"]
        except Exception:
            pass
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    if os.path.exists(user_path):
        try:
            with open(user_path, "r", encoding="utf-8") as f:
                u = json.load(f)
                if u.get("server_url"):
                    cfg["server_url"] = u["server_url"]
                if "customer_code" in u and u["customer_code"]:
                    cfg["customer_code"] = u["customer_code"]
                if "last_state" in u and isinstance(u["last_state"], dict):
                    cfg["last_state"] = u["last_state"]
        except Exception:
            pass
    cleaned = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    cfg["server_url"] = cleaned
    return cfg


def _save_user_config(profile, server_url, customer_code, last_state=None):
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    data = {"server_url": _clean_srv(server_url) or DEFAULT_PRIMARY_SERVER, "customer_code": customer_code.strip().lower()}
    if last_state is not None:
        data["last_state"] = last_state
    try:
        with open(user_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_customer_code():
    try:
        _, _, _, _, _, profile, base = _get_kodi_objs()
        cfg = _load_config(profile, base)
        return (cfg.get("customer_code") or "").strip()
    except Exception:
        return ""


def _http_get_json(url, timeout=8):
    headers = {"User-Agent": BROWSER_UA, "Accept": "application/json"}
    try:
        import requests
        r = requests.get(url, headers=headers, timeout=timeout, verify=False)
        if 200 <= r.status_code < 300:
            return r.json()
    except Exception:
        pass
    req = urllib.request.Request(url, headers=headers)
    try:
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))


def _get_or_create_device_id():
    try:
        import uuid
        import xbmcvfs
        ud = xbmcvfs.translatePath("special://userdata/")
        os.makedirs(ud, exist_ok=True)
        dev_file = os.path.join(ud, "vip_debrid_device_id.txt")
        if os.path.exists(dev_file):
            with open(dev_file, "r", encoding="utf-8") as f:
                val = f.read().strip()
                if len(val) >= 8:
                    return val
        new_id = "kbox_" + uuid.uuid4().hex[:12]
        with open(dev_file, "w", encoding="utf-8") as f:
            f.write(new_id)
        return new_id
    except Exception:
        return ""


def _fetch_sync_with_fallback(primary_server, customer_code, report_dead=False):
    q = urllib.parse.urlencode({
        "user": customer_code,
        "addon": ADDON_TYPE,
        "dev_id": _get_or_create_device_id(),
        "report_dead": "1" if report_dead else "0",
    })
    candidates = []
    for srv in [primary_server] + FALLBACK_SERVERS:
        c = _clean_srv(srv)
        if c and c not in candidates:
            candidates.append(c)

    last_data = None
    used_server = primary_server
    last_err = None

    for srv in candidates:
        url = f"{srv}/kodi-sync?{q}"
        try:
            data = _http_get_json(url, timeout=8)
            if isinstance(data, dict):
                last_data = data
                used_server = srv
                if data.get("status") not in ("invalid_user", "out_of_keys"):
                    return data, srv, None
        except Exception as exc:
            last_err = exc

    return last_data, used_server, last_err


def _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=False):
    tb = (keys_map.get("torbox") or keys_map.get("tb") or "").strip()
    rd = (keys_map.get("realdebrid") or keys_map.get("rd") or "").strip()
    ad = (keys_map.get("alldebrid") or keys_map.get("ad") or "").strip()
    pm = (keys_map.get("premiumize") or keys_map.get("pm") or "").strip()
    oc = (keys_map.get("offcloud") or keys_map.get("oc") or "").strip()

    if ADDON_TYPE == "pov":
        pairs = [
            ("tb.token", tb), ("tb.enabled", "true" if tb else "false"),
            ("rd.token", rd), ("rd.enabled", "true" if rd else "false"),
            ("ad.token", ad), ("ad.enabled", "true" if ad else "false"),
            ("pm.token", pm), ("pm.enabled", "true" if pm else "false"),
            ("oc.token", oc), ("oc.enabled", "true" if oc else "false"),
            ("subtitles.subs_action", "2" if not AUTO_DOWNLOAD_SUB_ON_PLAY else "1"),
            ("subtitles.language", "Vietnamese"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("pov_settings")
            try:
                from modules import kodi_utils
                kodi_utils.make_settings_dict()
            except Exception:
                pass

    elif ADDON_TYPE in ("torus", "aio"):
        any_tok = tb or rd or ad or pm or oc
        if ADDON_TYPE == "torus":
            try:
                if force_write or addon.getSetting("torbox_api_key") != any_tok:
                    addon.setSetting("torbox_api_key", any_tok)
            except Exception:
                pass
        tok_file = os.path.join(profile, "torbox_token.json")
        if any_tok:
            try:
                with open(tok_file, "w", encoding="utf-8") as f:
                    json.dump({
                        "token": any_tok,
                        "torbox": tb,
                        "realdebrid": rd,
                        "alldebrid": ad,
                        "premiumize": pm,
                        "offcloud": oc,
                    }, f)
            except Exception:
                pass
        else:
            try:
                if os.path.exists(tok_file):
                    os.remove(tok_file)
            except Exception:
                pass

    elif ADDON_TYPE == "umbrella":
        pairs = [
            ("torboxtoken", tb), ("torbox.enable", "true" if tb else "false"),
            ("realdebridtoken", rd), ("realdebrid.enable", "true" if rd else "false"),
            ("alldebridtoken", ad), ("alldebrid.enable", "true" if ad else "false"),
            ("premiumizetoken", pm), ("premiumize.enable", "true" if pm else "false"),
            ("offcloudtoken", oc), ("offcloud.enable", "true" if oc else "false"),
            ("subtitles", "true" if AUTO_DOWNLOAD_SUB_ON_PLAY else "false"),
            ("subtitles.lang.1", "Vietnamese"),
            ("subtitles.utf", "true"),
        ]
        changed = False
        for k, v in pairs:
            if force_write or addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed or force_write:
            xbmcgui.Window(10000).clearProperty("umbrella_settings")


def sync_now(force=False, interactive=False, force_rotate=False, report_dead=False):
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    win = xbmcgui.Window(10000)
    prop_ts = f"{ADDON_ID}.rent_sync_ts"
    now = time.time()

    if not force and not interactive and not force_rotate and not report_dead:
        last_ts = float(win.getProperty(prop_ts) or "0")
        if now - last_ts < SYNC_CACHE_TTL:
            return True

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    customer_code = (cfg.get("customer_code") or "").strip().lower()
    prev_state = cfg.get("last_state") if isinstance(cfg.get("last_state"), dict) else {}
    prev_ver = str(prev_state.get("version") or "")
    prev_keys = prev_state.get("keys") if isinstance(prev_state.get("keys"), dict) else {}

    if not customer_code:
        if interactive:
            return prompt_and_activate()
        return False

    data, active_srv, err = _fetch_sync_with_fallback(
        server_url,
        customer_code,
        report_dead=bool(report_dead),
    )

    if not isinstance(data, dict):
        if interactive:
            xbmcgui.Dialog().ok(
                "Lỗi kết nối Server",
                f"Không thể kết nối tới Server quản lý ({server_url}) - Chi tiết: {err}",
            )
        return False

    server_url = _clean_srv(data.get("new_server_url")) or active_srv
    win.setProperty(prop_ts, str(now))
    keys_map = data.get("keys") or {}
    ok = bool(data.get("ok"))
    status = data.get("status") or ""
    msg = data.get("message") or ""
    warn = data.get("warning") or ""
    new_ver = str(data.get("version") or "")
    days_left = data.get("days_left", "")
    auto_rotated = bool(data.get("auto_rotated"))
    keys_changed = bool(prev_keys and keys_map != prev_keys)
    version_changed = bool(new_ver and prev_ver and new_ver != prev_ver)

    if ok:
        _apply_keys_to_addon(addon, profile, xbmcgui, keys_map, force_write=(version_changed or keys_changed or auto_rotated or interactive))
        _save_user_config(profile, server_url, customer_code, last_state=data)
        warn_prop = f"{ADDON_ID}.warn_shown"
        if not warn or version_changed:
            win.clearProperty(warn_prop)
        if interactive:
            xbmcgui.Dialog().ok("Kích hoạt VIP Debrid thành công", msg)
        elif auto_rotated or keys_changed:
            pass
        elif version_changed:
            xbmcgui.Dialog().notification(
                "Đã cập nhật VIP Debrid",
                f"Đồng bộ bản v{new_ver} thành công (Còn {days_left} ngày)",
                xbmcgui.NOTIFICATION_INFO,
                4500,
            )
        elif warn:
            if not win.getProperty(warn_prop):
                win.setProperty(warn_prop, "1")
                xbmcgui.Dialog().notification("Sắp hết hạn VIP", warn, xbmcgui.NOTIFICATION_WARNING, 6000)
        return True
    else:
        empty_keys = {"torbox": "", "realdebrid": "", "alldebrid": "", "premiumize": "", "offcloud": ""}
        _apply_keys_to_addon(addon, profile, xbmcgui, empty_keys, force_write=True)
        _save_user_config(profile, server_url, customer_code, last_state=data)
        if interactive or status in ("expired", "locked"):
            xbmcgui.Dialog().ok("Thông báo Tài khoản VIP", msg or "Gói dịch vụ đã hết hạn hoặc tạm khóa.")
        return False


def prompt_and_activate():
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url")) or DEFAULT_PRIMARY_SERVER
    current_code = (cfg.get("customer_code") or "").strip()

    if current_code:
        choices = [
            f"Đồng bộ & Kiểm tra hạn dùng (Mã: {current_code})",
            "Nhập Mã khách hàng (PIN) khác",
            f"Đổi địa chỉ Server (Hiện tại: {server_url})",
        ]
        sel = xbmcgui.Dialog().select("Quản lý Tài khoản VIP Debrid", choices)
        if sel < 0:
            return False
        if sel == 0:
            return sync_now(force=True, interactive=True, force_rotate=False)
        if sel == 2:
            new_srv = xbmcgui.Dialog().input("Nhập địa chỉ Cloudflare Worker", defaultt=server_url, type=xbmcgui.INPUT_ALPHANUM)
            if new_srv and new_srv.strip():
                server_url = _clean_srv(new_srv)
                _save_user_config(profile, server_url, current_code)
            return sync_now(force=True, interactive=True, force_rotate=False)

    new_code = xbmcgui.Dialog().input(
        "Nhập Mã kích hoạt VIP (Admin cấp)",
        defaultt=current_code,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not new_code or not new_code.strip():
        return False

    _save_user_config(profile, server_url, new_code.strip().lower())
    ok = sync_now(force=True, interactive=True, force_rotate=False)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    return ok


# ==============================================================================
# QUẢN LÝ DANH SÁCH "PHIM ĐANG XEM DỞ" (CONTINUE WATCHING GIỐNG STREMIO)
# ==============================================================================
def _get_aio_profile_dir():
    import xbmcvfs
    p = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.tuankaka.aio/")
    os.makedirs(p, exist_ok=True)
    return p


def _cw_file_path():
    return os.path.join(_get_aio_profile_dir(), "continue_watching.json")


def load_continue_watching():
    fpath = _cw_file_path()
    if os.path.exists(fpath):
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            pass
    return []


def save_continue_watching(items_list):
    fpath = _cw_file_path()
    try:
        with open(fpath, "w", encoding="utf-8") as f:
            json.dump(items_list[:40], f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def upsert_continue_watching_item(item_dict):
    """Thêm hoặc cập nhật 1 bộ phim vào đầu danh sách Đang xem dở."""
    if not isinstance(item_dict, dict):
        return
    key_id = str(item_dict.get("id") or item_dict.get("imdb_id") or "").strip()
    if not key_id:
        return

    items = load_continue_watching()
    existing = None
    rest = []
    for it in items:
        it_key = str(it.get("id") or it.get("imdb_id") or "").strip()
        if it_key == key_id and existing is None:
            existing = it
        else:
            rest.append(it)

    merged = dict(existing) if existing else {}
    for k, v in item_dict.items():
        if v not in (None, ""):
            merged[k] = v

    # Nếu chuyển sang tập mới của phim bộ, đặt lại resume_time = 0 cho tập mới
    if existing and (str(existing.get("season", "")) != str(item_dict.get("season", "")) or str(existing.get("episode", "")) != str(item_dict.get("episode", ""))):
        if "resume_time" not in item_dict:
            merged["resume_time"] = 0
            merged["total_time"] = 0

    merged["updated_at"] = int(time.time())
    save_continue_watching([merged] + rest)


def update_continue_watching_progress(key_id, season="", episode="", resume_time=0.0, total_time=0.0):
    """Cập nhật tiến độ giây đang xem; nếu xem >= 88% phim lẻ thì xóa khỏi Đang xem dở, nếu là phim bộ thì tự nhảy sang Tập kế tiếp!"""
    if not key_id or total_time <= 0:
        return
    items = load_continue_watching()
    new_list = []
    changed = False
    ratio = float(resume_time) / float(total_time)

    for it in items:
        it_key = str(it.get("id") or it.get("imdb_id") or "").strip()
        if it_key == str(key_id).strip():
            changed = True
            mtype = str(it.get("type") or "movie")
            if ratio >= 0.88:
                if mtype == "series":
                    # Tự động tăng sang tập kế tiếp giống Stremio
                    cur_ep = int(episode or it.get("episode") or 1)
                    next_ep = cur_ep + 1
                    it["episode"] = str(next_ep)
                    it["ep_title"] = f"Tập {next_ep}"
                    it["resume_time"] = 0
                    it["total_time"] = 0
                    it["updated_at"] = int(time.time())
                    new_list.append(it)
                else:
                    # Phim lẻ đã xem xong (>88%) -> tự động dọn khỏi Đang xem dở
                    continue
            else:
                if resume_time >= 15:
                    it["resume_time"] = round(float(resume_time), 1)
                    it["total_time"] = round(float(total_time), 1)
                    it["updated_at"] = int(time.time())
                new_list.append(it)
        else:
            new_list.append(it)

    if changed:
        save_continue_watching(new_list)


def remove_continue_watching_item(key_id):
    items = load_continue_watching()
    filtered = [it for it in items if str(it.get("id") or it.get("imdb_id") or "").strip() != str(key_id).strip()]
    save_continue_watching(filtered)


# ==============================================================================
# LÕI TÌM KIẾM PHIM ĐA NGUỒN (CINEMETA STREMIO + XPERIENCE WORKER)
# ==============================================================================
def search_all_catalogs(query_str):
    """Quét song song Phim Lẻ & Phim Bộ từ Cinemeta (Chuẩn Stremio) và Xperience Worker."""
    import threading

    q_clean = str(query_str or "").strip()
    if not q_clean:
        return []
    q_enc = urllib.parse.quote(q_clean)

    endpoints = [
        ("movie", f"https://v3-cinemeta.strem.io/catalog/movie/top/search={q_enc}.json"),
        ("series", f"https://v3-cinemeta.strem.io/catalog/series/top/search={q_enc}.json"),
    ]

    results_box = [[] for _ in range(len(endpoints))]

    def _worker(idx, mtype, url):
        try:
            data = _http_get_json(url, timeout=7)
            metas = data.get("metas") if isinstance(data, dict) else []
            if isinstance(metas, list):
                out = []
                for m in metas:
                    if isinstance(m, dict):
                        mc = dict(m)
                        mc["type"] = mc.get("type") or mtype
                        out.append(mc)
                results_box[idx] = out
        except Exception:
            pass

    threads = []
    for i, (mt, u) in enumerate(endpoints):
        t = threading.Thread(target=_worker, args=(i, mt, u))
        t.daemon = True
        t.start()
        threads.append(t)

    for t in threads:
        t.join(timeout=7.5)

    # Trộn xen kẽ kết quả Phim Lẻ và Phim Bộ phù hợp nhất lên đầu
    movies = results_box[0]
    series = results_box[1]
    merged = []
    seen_ids = set()
    max_len = max(len(movies), len(series))
    for i in range(max_len):
        for lst in (movies, series):
            if i < len(lst):
                item = lst[i]
                iid = str(item.get("id") or item.get("imdb_id") or "").strip()
                if iid and iid not in seen_ids:
                    seen_ids.add(iid)
                    merged.append(item)
    return merged


# ==============================================================================
# LÕI QUÉT NGUỒN PHIM TRỰC TIẾP SIÊU TỐC (DIRECT TORRENTIO + COMET ENGINE)
# ==============================================================================
def get_shared_debrid_keys():
    import xbmcaddon
    import xbmcvfs

    merged = {"torbox": "", "realdebrid": "", "alldebrid": "", "premiumize": "", "offcloud": ""}

    def _merge_dict(d):
        if not isinstance(d, dict):
            return
        mapping = {
            "torbox": ("torbox", "tb", "torboxtoken", "tb.token", "torbox_api_key"),
            "realdebrid": ("realdebrid", "rd", "realdebridtoken", "rd.token"),
            "alldebrid": ("alldebrid", "ad", "alldebridtoken", "ad.token"),
            "premiumize": ("premiumize", "pm", "premiumizetoken", "pm.token"),
            "offcloud": ("offcloud", "oc", "offcloudtoken", "oc.token"),
        }
        for std_k, aliases in mapping.items():
            if not merged[std_k]:
                for al in aliases:
                    val = str(d.get(al) or "").strip()
                    if val and len(val) >= 8:
                        merged[std_k] = val
                        break

    userdata_root = xbmcvfs.translatePath("special://userdata/addon_data/")
    addon_folders = [
        "plugin.video.tuankaka.aio",
        "plugin.video.torus",
        "plugin.video.pov",
        "plugin.video.umbrella",
    ]
    for folder in addon_folders:
        p_dir = os.path.join(userdata_root, folder)
        u_file = os.path.join(p_dir, "debrid_cloud_user.json")
        if os.path.exists(u_file):
            try:
                with open(u_file, "r", encoding="utf-8") as f:
                    u_data = json.load(f)
                last_st = u_data.get("last_state") or {}
                if last_st.get("ok") and isinstance(last_st.get("keys"), dict):
                    _merge_dict(last_st["keys"])
                if not any(merged.values()) and u_data.get("customer_code"):
                    srv = _clean_srv(u_data.get("server_url")) or DEFAULT_PRIMARY_SERVER
                    d_sync, _, _ = _fetch_sync_with_fallback(srv, u_data["customer_code"])
                    if isinstance(d_sync, dict) and d_sync.get("ok") and isinstance(d_sync.get("keys"), dict):
                        _merge_dict(d_sync["keys"])
            except Exception:
                pass
        t_file = os.path.join(p_dir, "torbox_token.json")
        if os.path.exists(t_file):
            try:
                with open(t_file, "r", encoding="utf-8") as f:
                    _merge_dict(json.load(f))
            except Exception:
                pass

    addons_root = xbmcvfs.translatePath("special://home/addons/")
    for folder in addon_folders:
        a_dir = os.path.join(addons_root, folder)
        for cfg_name in ("debrid_cloud_config.json", "debrid_preset.json"):
            c_path = os.path.join(a_dir, cfg_name)
            if os.path.exists(c_path):
                try:
                    with open(c_path, "r", encoding="utf-8") as f:
                        c_data = json.load(f)
                    _merge_dict(c_data)
                    if isinstance(c_data.get("static_keys"), dict):
                        _merge_dict(c_data["static_keys"])
                    if not any(merged.values()) and c_data.get("customer_code"):
                        srv = _clean_srv(c_data.get("server_url")) or DEFAULT_PRIMARY_SERVER
                        d_sync, _, _ = _fetch_sync_with_fallback(srv, c_data["customer_code"])
                        if isinstance(d_sync, dict) and d_sync.get("ok") and isinstance(d_sync.get("keys"), dict):
                            _merge_dict(d_sync["keys"])
                except Exception:
                    pass

    addon_setting_probes = [
        ("plugin.video.pov", {"torbox": "tb.token", "realdebrid": "rd.token", "alldebrid": "ad.token", "premiumize": "pm.token", "offcloud": "oc.token"}),
        ("plugin.video.torus", {"torbox": "torbox_api_key"}),
        ("plugin.video.umbrella", {"torbox": "torboxtoken", "realdebrid": "realdebridtoken", "alldebrid": "alldebridtoken", "premiumize": "premiumizetoken", "offcloud": "offcloudtoken"}),
    ]
    for aid, smap in addon_setting_probes:
        if all(merged.values()):
            break
        try:
            ad_obj = xbmcaddon.Addon(aid)
            for std_k, setting_id in smap.items():
                if not merged[std_k]:
                    val = (ad_obj.getSetting(setting_id) or "").strip()
                    if val and len(val) >= 8:
                        merged[std_k] = val
        except Exception:
            pass

    return merged


def resolve_imdb_id_fast(imdb_id="", tmdb_id="", title="", year="", mtype="movie"):
    cid = str(imdb_id or "").strip()
    if cid.startswith("tt") and len(cid) >= 7:
        return cid

    clean_title = str(title or "").strip()
    if clean_title:
        try:
            q_slug = urllib.parse.quote(clean_title.lower())
            first_c = re.sub(r"[^a-z0-9]", "", clean_title.lower())[:1] or "x"
            sug_url = f"https://v3.sg.media-imdb.com/suggestion/{first_c}/{q_slug}.json"
            sug_data = _http_get_json(sug_url, timeout=4)
            items = sug_data.get("d") if isinstance(sug_data, dict) else []
            if isinstance(items, list):
                candidates = [it for it in items if isinstance(it, dict) and str(it.get("id", "")).startswith("tt")]
                if year and str(year).isdigit():
                    y_int = int(year)
                    for it in candidates:
                        if it.get("y") and abs(int(it["y"]) - y_int) <= 1:
                            return str(it["id"])
                if candidates:
                    return str(candidates[0]["id"])
        except Exception:
            pass

    clean_tmdb = str(tmdb_id or "").replace("tmdb:", "").strip()
    if clean_tmdb.isdigit() and SUBDL_API_KEYS:
        try:
            q_params = {
                "api_key": SUBDL_API_KEYS[0],
                "tmdb_id": clean_tmdb,
                "type": "tv" if str(mtype).lower() in ("series", "tv", "episode", "show") else "movie",
                "languages": "VI,EN",
            }
            d_res = _http_get_json("https://api.subdl.com/api/v1/subtitles?" + urllib.parse.urlencode(q_params), timeout=5)
            results_arr = d_res.get("results") if isinstance(d_res, dict) else []
            if isinstance(results_arr, list) and results_arr:
                found_tt = str(results_arr[0].get("imdb_id") or "").strip()
                if found_tt.startswith("tt"):
                    return found_tt
        except Exception:
            pass

    return ""


def _parse_stream_item(s_obj, provider_name):
    url = str(s_obj.get("url") or "").strip()
    if not url or not url.startswith("http"):
        return None

    name_field = str(s_obj.get("name") or "")
    title_field = str(s_obj.get("title") or s_obj.get("description") or "")
    bh = s_obj.get("behaviorHints") or {}
    filename = str(bh.get("filename") or "").strip()

    lines = [l.strip() for l in title_field.replace("\r", "").split("\n") if l.strip()]
    if not filename and lines:
        filename = lines[0]

    combined = f"{name_field} {title_field} {filename}"
    c_low = combined.lower()

    is_cached = any(tag in c_low for tag in ("[tb+]", "[rd+]", "[ad+]", "[pm+]", "[oc+]", "[dl+]", "+]", "⚡", "instant"))

    if any(k in c_low for k in ("2160p", "4k", "uhd")):
        res_label = "4K UHD"
        res_rank = 4
        res_color = "gold"
    elif "1080p" in c_low:
        res_label = "1080p"
        res_rank = 3
        res_color = "springgreen"
    elif "720p" in c_low:
        res_label = "720p"
        res_rank = 2
        res_color = "deepskyblue"
    else:
        res_label = "SD"
        res_rank = 1
        res_color = "silver"

    size_str = ""
    size_gb = 0.0
    m_size = re.search(r"💾\s*([0-9.]+)\s*(GB|MB)", combined, re.I) or re.search(r"\b([0-9.]+)\s*(GB|MB)\b", combined, re.I)
    if m_size:
        val = float(m_size.group(1))
        unit = m_size.group(2).upper()
        size_str = f"{val:.1f} {unit}" if unit == "GB" else f"{int(val)} MB"
        size_gb = val if unit == "GB" else (val / 1024.0)
    elif bh.get("videoSize"):
        try:
            size_gb = float(bh["videoSize"]) / (1024 ** 3)
            size_str = f"{size_gb:.1f} GB"
        except Exception:
            pass

    tags = []
    if "dv" in re.findall(r"\b\w+\b", c_low) or "dolby vision" in c_low or "dovi" in c_low:
        tags.append("DV")
    if "hdr10+" in c_low:
        tags.append("HDR10+")
    elif "hdr" in c_low:
        tags.append("HDR")
    if "atmos" in c_low:
        tags.append("Atmos")
    if "remux" in c_low:
        tags.append("REMUX")
    elif "bluray" in c_low or "blu-ray" in c_low:
        tags.append("BluRay")
    elif "web-dl" in c_low or "webdl" in c_low:
        tags.append("WEB-DL")

    tag_str = (" • " + "/".join(tags)) if tags else ""
    size_badge = f" • {size_str}" if size_str else ""
    cache_icon = "⚡" if is_cached else "☁️"
    clean_display_fn = filename or (lines[0] if lines else "Stream")

    label = (
        f"[COLOR {res_color}][B]{cache_icon} {res_label}[/B][/COLOR]"
        f"[COLOR cyan][{provider_name}{size_badge}{tag_str}][/COLOR] {clean_display_fn}"
    )

    return {
        "url": url,
        "filename": clean_display_fn,
        "label": label,
        "is_cached": is_cached,
        "res_rank": res_rank,
        "size_gb": size_gb,
        "provider": provider_name,
    }


def fetch_direct_debrid_streams(imdb_id, mtype="movie", season=None, episode=None, tmdb_id="", title="", year=""):
    import threading

    vid_id = str(imdb_id or "").strip()
    if not vid_id.startswith("tt"):
        vid_id = resolve_imdb_id_fast(imdb_id=vid_id, tmdb_id=tmdb_id, title=title, year=year, mtype=mtype)
    if not vid_id.startswith("tt"):
        return []

    keys = get_shared_debrid_keys()
    if not any(keys.values()):
        return []

    is_series = str(mtype).lower() in ("series", "episode", "tv", "show") and season and episode
    if is_series:
        stream_target = f"series/{vid_id}:{int(season)}:{int(episode)}.json"
    else:
        stream_target = f"movie/{vid_id}.json"

    t_parts = []
    for kname in ("torbox", "realdebrid", "alldebrid", "premiumize", "offcloud"):
        if keys.get(kname):
            t_parts.append(f"{kname}={keys[kname]}")
    t_cfg = "%7C".join(t_parts)
    torrentio_url = f"https://torrentio.strem.fun/{t_cfg}/stream/{stream_target}"

    c_services = []
    for kname in ("torbox", "realdebrid", "alldebrid", "premiumize", "offcloud"):
        if keys.get(kname):
            c_services.append({"service": kname, "apiKey": keys[kname]})
    first_svc = c_services[0]
    comet_cfg_obj = {
        "maxResultsPerResolution": 0,
        "maxSize": 0,
        "cachedOnly": False,
        "removeTrash": True,
        "resultFormat": ["all"],
        "debridService": first_svc["service"],
        "debridApiKey": first_svc["apiKey"],
        "debridServices": c_services,
        "debridStreamProxyPassword": "",
        "deduplicateStreams": True,
        "scrapeDebridAccountTorrents": False,
        "enableTorrent": False,
    }
    comet_b64 = base64.b64encode(json.dumps(comet_cfg_obj).encode("utf-8")).decode("utf-8")
    comet_url = f"https://comet.elfhosted.com/{comet_b64}/stream/{stream_target}"

    box = [[], []]

    def _poll_provider(idx, u, pname):
        try:
            data = _http_get_json(u, timeout=6)
            raw_list = data.get("streams") if isinstance(data, dict) else []
            if isinstance(raw_list, list):
                parsed = []
                for item in raw_list:
                    if isinstance(item, dict):
                        p = _parse_stream_item(item, pname)
                        if p:
                            parsed.append(p)
                box[idx] = parsed
        except Exception:
            pass

    t1 = threading.Thread(target=_poll_provider, args=(0, torrentio_url, "Torrentio"))
    t2 = threading.Thread(target=_poll_provider, args=(1, comet_url, "Comet"))
    t1.daemon = True
    t2.daemon = True
    t1.start()
    t2.start()
    t1.join(timeout=6.5)
    t2.join(timeout=6.5)

    all_streams = box[0] + box[1]
    seen_urls = set()
    unique_streams = []
    for st in all_streams:
        if st["url"] not in seen_urls:
            seen_urls.add(st["url"])
            unique_streams.append(st)

    unique_streams.sort(
        key=lambda x: (1 if x["is_cached"] else 0, x["res_rank"], x["size_gb"]),
        reverse=True,
    )
    return unique_streams


def resolve_playable_stream_url(raw_stream_url):
    u = str(raw_stream_url or "").strip().replace("|", "%7C")
    if not u:
        return ""
    try:
        import requests
        r = requests.get(
            u,
            headers={"User-Agent": BROWSER_UA},
            allow_redirects=False,
            stream=True,
            timeout=8,
            verify=False,
        )
        if r.status_code in (301, 302, 303, 307, 308) and r.headers.get("Location"):
            loc = r.headers["Location"].strip()
            r.close()
            if loc.startswith("http"):
                return loc
        r.close()
    except Exception:
        pass
    return f"{u}|User-Agent={urllib.parse.quote(BROWSER_UA)}"


# ==============================================================================
# HỆ THỐNG PHỤ ĐỀ THÔNG MINH (CHUẨN HÓA KEY TỪ AIO.TXT & LỌC KHỚP FILE PHIM)
# ==============================================================================
SUBDL_UPSTREAMS = [
    "https://subdl.strem.top/c3ViZGxfMWd0MlNTRnQ0WlJNcGd4dG44SlN4ZE52MDhheTNkaE82blY4MGNlZUNndy9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfTVJaNE5IX0RkNjhJaG9LWGtpUUxlS2U3d1V0NUhsTVotaTlRWGNEU2R3QS9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfTkJXcVNIX2pHc1d0QnFWbGRnZlhraFA2NThINnQ4aDduRkdGRW8yMXp1OC9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfY1kyRUxOaXY2bUdTeXlGcDU2REtzYnRfUGFJci10TVQwNm1qMU9hcHhFWS9WSS9oaUluY2x1ZGUv",
    "https://subdl.strem.top/c3ViZGxfejhSVTJLM2w3TERyS21xNlNQRUdKRWNhSU9Hc1FDYWh2LVVLX2hvZXptSS9WSS9oaUluY2x1ZGUv",
]

SUBSOURCE_UPSTREAMS = [
    "https://subsource.strem.top/c2tfOGZjODA2YzBlYTI3ZGU1MDM3OTUwMzc1NjA4Yzc1MzMwYzY2NjAzMzY2N2ViNzA4OWM0Zjg4YTE0NWE3ZjYzNC92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
    "https://subsource.strem.top/c2tfMWIyZDYzZTU3ODNmYzFlY2M2Y2E4NjZkMzc5OGMyNjU3NDA2YzE5YmFlOTdlNTdmZTVjYmJhN2QzYzUzNGJmOC92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
    "https://subsource.strem.top/c2tfN2QwZmI2NzU2MTg0MjZmZDlhZDMyYjhhZWVmYmZjZTM3OGY1NDQwN2NhNGEzYWRiODNlNTcyMjIzMzM4YzFlNy92aWV0bmFtZXNlL2hpSW5jbHVkZS90eXBlOjAv",
]

SUBDL_API_KEYS = [
    "subdl_1gt2SSRt4ZRMpgxtn8JSxdNv08ay3dhO6nV80ceeCgw",
    "subdl_MRZ4NH_Dd68IhoKXkiQLeKe7wUt5HlMZ-i9QXcDSdwA",
    "subdl_NBWqSH_jGsWtBqVldnfXhaP658H6q8d7nFGFGo21pu8",
    "subdl_cY2ELNiv6mGSyyFp56EKsbr_PaIr-tMT06mj19apxEY",
    "subdl_z8RU2K3l7TDrKmq6NPUGJECaIOGsQCyhv-UK_hoezmI",
]

SUBSOURCE_API_KEYS = [
    "sk_8fc806c0ea27de5037950375608c75330c666033667eb7089c4f88a145a7f634",
    "sk_1b2d63e5783fc1ecc6ce866d3798c2657406c19bae97e57fe5cbba7d3c534bf8",
    "sk_7d0fb675618426fd9ad32b8aeefbfce378f54407ca4a3adb83e572223338c1e7",
]


def save_playing_context(imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", title="", year="", raw_id=""):
    try:
        import xbmcgui
        win = xbmcgui.Window(10000)
        s_imdb = str(imdb_id or "").strip()
        s_tmdb = str(tmdb_id or "").replace("tmdb:", "").strip()

        if s_imdb and s_imdb.isdigit() and not s_tmdb:
            s_tmdb = s_imdb
            s_imdb = ""

        if s_imdb.startswith("tt"):
            win.setProperty("tuankaka.imdb_id", s_imdb)
            win.setProperty("tuankaka.media_id", s_imdb)
        if s_tmdb:
            win.setProperty("tuankaka.tmdb_id", s_tmdb)
            if not s_imdb.startswith("tt"):
                win.setProperty("tuankaka.media_id", f"tmdb:{s_tmdb}")
        if raw_id:
            win.setProperty("tuankaka.cw_key_id", str(raw_id))
        elif s_imdb.startswith("tt"):
            win.setProperty("tuankaka.cw_key_id", s_imdb)
        if mtype:
            win.setProperty("tuankaka.media_type", str(mtype))
        if title:
            win.setProperty("tuankaka.title", str(title))
        if year:
            win.setProperty("tuankaka.year", str(year))
        win.setProperty("tuankaka.season", str(season or ""))
        win.setProperty("tuankaka.episode", str(episode or ""))
        win.setProperty("tuankaka.cw_active", "1")
        if filename:
            clean_fn = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(str(filename)).path))
            win.setProperty("tuankaka.filename", clean_fn or str(filename))
    except Exception:
        pass


def _unwrap_stremio_sub_url(raw_url):
    u = str(raw_url or "").strip()
    if not u:
        return ""
    if "from=" in u:
        try:
            parsed = urllib.parse.urlsplit(u)
            qs = dict(urllib.parse.parse_qsl(parsed.query))
            if qs.get("from"):
                u = urllib.parse.unquote(qs["from"]).strip()
        except Exception:
            pass
    try:
        p = urllib.parse.urlsplit(u)
        clean_path = urllib.parse.quote(urllib.parse.unquote(p.path), safe="/:@!$&'()*+,;=-._~")
        u = urllib.parse.urlunsplit((p.scheme, p.netloc, clean_path, p.query, p.fragment))
    except Exception:
        pass
    return u


def _http_get_bytes(url, extra_headers=None, timeout=10):
    u = _unwrap_stremio_sub_url(url)
    if not u:
        return b""
    headers = {"User-Agent": BROWSER_UA, "Accept": "*/*"}
    if isinstance(extra_headers, dict):
        headers.update(extra_headers)
    try:
        import requests
        r = requests.get(u, headers=headers, timeout=timeout, verify=False)
        if 200 <= r.status_code < 300 and r.content:
            return r.content
    except Exception:
        pass
    try:
        req = urllib.request.Request(u, headers=headers)
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return resp.read()
    except Exception:
        pass
    try:
        proxy_url = f"{DEFAULT_PRIMARY_SERVER}/sub-proxy?url=" + urllib.parse.quote(u, safe="")
        import requests
        r2 = requests.get(proxy_url, headers={"User-Agent": BROWSER_UA}, timeout=timeout, verify=False)
        if 200 <= r2.status_code < 300 and r2.content:
            return r2.content
    except Exception:
        pass
    return b""


def _format_srt_time(h, m, s, ms):
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(ms):03d}"


def _parse_any_timestamp_to_srt(ts_str):
    t = ts_str.strip()
    m = re.match(r"^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})", t)
    if not m:
        return None
    hh = int(m.group(1) or 0)
    mm = int(m.group(2) or 0)
    ss = int(m.group(3) or 0)
    raw_ms = m.group(4)
    if len(raw_ms) == 1:
        ms = int(raw_ms) * 100
    elif len(raw_ms) == 2:
        ms = int(raw_ms) * 10
    else:
        ms = int(raw_ms[:3])
    return _format_srt_time(hh, mm, ss, ms)


def _convert_ass_to_srt_text(ass_text):
    out_blocks = []
    idx = 1
    for line in ass_text.splitlines():
        if not line.startswith("Dialogue:"):
            continue
        parts = line[9:].lstrip().split(",", 9)
        if len(parts) < 10:
            continue
        start_srt = _parse_any_timestamp_to_srt(parts[1])
        end_srt = _parse_any_timestamp_to_srt(parts[2])
        if not start_srt or not end_srt or start_srt == end_srt:
            continue
        dialogue = parts[9]
        dialogue = re.sub(r"\{[^\}]*\}", "", dialogue)
        dialogue = dialogue.replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ").strip()
        if not dialogue:
            continue
        out_blocks.append(f"{idx}\r\n{start_srt} --> {end_srt}\r\n{dialogue}")
        idx += 1
    return "\r\n\r\n".join(out_blocks) + ("\r\n" if out_blocks else "")


def _normalize_to_strict_srt(raw_text):
    if not raw_text:
        return ""
    txt = raw_text.replace("\ufeff", "").replace("\x00", "").replace("\r\n", "\n").replace("\r", "\n").strip()
    if not txt:
        return ""

    low_head = txt[:400].lower()
    if low_head.startswith("<!doctype") or low_head.startswith("<html") or low_head.startswith('{"error'):
        return ""

    if "dialogue:" in txt.lower() and "-->" not in txt:
        txt = _convert_ass_to_srt_text(txt).replace("\r\n", "\n")

    if "-->" not in txt:
        return ""

    lines = txt.split("\n")
    cues = []
    i = 0
    n_lines = len(lines)

    while i < n_lines:
        line = lines[i].strip()
        if "-->" in line:
            parts = line.split("-->")
            if len(parts) >= 2:
                left_ts = _parse_any_timestamp_to_srt(parts[0])
                right_raw = parts[1].strip().split()[0] if parts[1].strip() else ""
                right_ts = _parse_any_timestamp_to_srt(right_raw)
                if left_ts and right_ts:
                    i += 1
                    text_lines = []
                    while i < n_lines and lines[i].strip() != "":
                        if "-->" in lines[i] and _parse_any_timestamp_to_srt(lines[i].split("-->")[0]):
                            break
                        if lines[i].strip().isdigit() and (i + 1 < n_lines) and "-->" in lines[i + 1]:
                            break
                        clean_l = re.sub(r"\{[^\}]*\}", "", lines[i].strip())
                        if clean_l:
                            text_lines.append(clean_l)
                        i += 1
                    if text_lines:
                        joined_text = "\r\n".join(text_lines)
                        low_t = joined_text.lower()
                        if left_ts.startswith("00:00:00") and any(w in low_t for w in ("subdl.strem", "subsource.strem", "donated", "support note")):
                            continue
                        cues.append((left_ts, right_ts, joined_text))
                    continue
        i += 1

    if len(cues) < 3:
        return ""

    out_lines = []
    for idx, (st, et, body) in enumerate(cues, 1):
        out_lines.append(f"{idx}\r\n{st} --> {et}\r\n{body}")
    return "\r\n\r\n".join(out_lines) + "\r\n"


def _extract_srt_from_bytes(raw_bytes, season=None, episode=None):
    if not raw_bytes or len(raw_bytes) < 40:
        return b""

    if raw_bytes[:2] == b"\x1f\x8b":
        try:
            import gzip
            raw_bytes = gzip.decompress(raw_bytes)
        except Exception:
            pass

    if raw_bytes[:4] == b"PK\x03\x04":
        try:
            import io
            import zipfile
            with zipfile.ZipFile(io.BytesIO(raw_bytes)) as zf:
                valid_names = []
                for n in zf.namelist():
                    if n.endswith("/") or "__MACOSX" in n or os.path.basename(n).startswith("._"):
                        continue
                    if n.lower().endswith((".srt", ".vtt", ".ass", ".ssa", ".sub")):
                        valid_names.append(n)
                if not valid_names:
                    return b""

                chosen_name = valid_names[0]
                try:
                    s_num = int(season) if season not in (None, "", "0", 0) else 0
                    e_num = int(episode) if episode not in (None, "", "0", 0) else 0
                    if s_num > 0 and e_num > 0 and len(valid_names) > 1:
                        pats = [
                            f"s{s_num:02d}e{e_num:02d}",
                            f"s{s_num}e{e_num:02d}",
                            f"{s_num}x{e_num:02d}",
                            f"e{e_num:02d}",
                            f"ep{e_num:02d}",
                        ]
                        for cand in valid_names:
                            c_low = os.path.basename(cand).lower()
                            if any(p in c_low for p in pats):
                                chosen_name = cand
                                break
                except Exception:
                    pass
                raw_bytes = zf.read(chosen_name)
        except Exception:
            return b""

    decoded_text = ""
    encodings_order = ("utf-8-sig", "utf-8", "utf-16", "cp1258", "windows-1252", "latin-1")
    if raw_bytes.startswith((b"\xff\xfe", b"\xfe\xff")):
        encodings_order = ("utf-16", "utf-8-sig", "utf-8", "cp1258", "latin-1")

    for enc in encodings_order:
        try:
            cand_txt = raw_bytes.decode(enc)
            if "-->" in cand_txt or "Dialogue:" in cand_txt:
                decoded_text = cand_txt
                break
        except Exception:
            continue

    if not decoded_text:
        return b""

    strict_srt = _normalize_to_strict_srt(decoded_text)
    if not strict_srt:
        return b""

    return b"\xef\xbb\xbf" + strict_srt.encode("utf-8")


def _fetch_subdl_direct_api(vid_id="", tmdb_id="", title="", year="", is_series=False, s_num=0, e_num=0):
    import random
    if not SUBDL_API_KEYS:
        return []

    clean_tt = str(vid_id or "").strip() if str(vid_id or "").startswith("tt") else ""
    clean_tmdb = str(tmdb_id or "").replace("tmdb:", "").strip()
    if not clean_tmdb and str(vid_id or "").startswith("tmdb:"):
        clean_tmdb = str(vid_id).replace("tmdb:", "").strip()
    clean_title = str(title or "").strip()

    if not clean_tt and not clean_tmdb.isdigit() and not clean_title:
        return []

    out = []
    keys_to_try = random.sample(SUBDL_API_KEYS, min(3, len(SUBDL_API_KEYS)))
    for api_k in keys_to_try:
        try:
            q_params = {
                "api_key": api_k,
                "languages": "VI,EN",
                "subs_per_page": "30",
                "type": "tv" if (is_series and s_num > 0 and e_num > 0) else "movie",
            }
            if clean_tt:
                q_params["imdb_id"] = clean_tt
            elif clean_tmdb.isdigit():
                q_params["tmdb_id"] = clean_tmdb
            else:
                q_params["film_name"] = clean_title
                if year and str(year).isdigit():
                    q_params["year"] = str(year)

            if is_series and s_num > 0 and e_num > 0:
                q_params["season_number"] = str(s_num)
                q_params["episode_number"] = str(e_num)

            direct_url = "https://api.subdl.com/api/v1/subtitles?" + urllib.parse.urlencode(q_params)
            d_res = _http_get_json(direct_url, timeout=7)
            if isinstance(d_res, dict) and isinstance(d_res.get("subtitles"), list) and d_res["subtitles"]:
                for item in d_res["subtitles"]:
                    dl_link = item.get("url") or ""
                    if dl_link and not dl_link.startswith("http"):
                        dl_link = "https://dl.subdl.com" + (dl_link if dl_link.startswith("/") else "/" + dl_link)
                    rel_name = item.get("release_name") or item.get("name") or "SubDL"
                    lang_raw = str(item.get("language") or item.get("lang") or "vi").lower()
                    is_vi = any(w in lang_raw for w in ("vi", "vie", "viet"))
                    if dl_link:
                        out.append({
                            "id": str(rel_name),
                            "title": str(rel_name),
                            "release_name": str(rel_name),
                            "url": dl_link,
                            "lang": "vie" if is_vi else "eng",
                            "provider": "SubDL",
                            "source": "subdl_direct",
                        })
                if out:
                    break
        except Exception:
            continue
    return out


def _fetch_subsource_direct_api(vid_id, is_series=False, s_num=0, e_num=0):
    import random
    if not str(vid_id or "").startswith("tt") or not SUBSOURCE_API_KEYS:
        return []
    out = []
    api_k = random.choice(SUBSOURCE_API_KEYS)
    headers = {"User-Agent": BROWSER_UA, "Accept": "application/json", "X-API-Key": api_k}
    try:
        import requests
        q = {"imdb": vid_id, "language": "vietnamese"}
        if is_series and s_num > 0:
            q["season"] = str(s_num)
        r = requests.get("https://api.subsource.net/api/v1/subtitles", params=q, headers=headers, timeout=7, verify=False)
        if r.status_code == 200:
            data = r.json()
            sub_items = data if isinstance(data, list) else (data.get("subtitles") or data.get("data") or [])
            if isinstance(sub_items, list):
                for item in sub_items:
                    if not isinstance(item, dict):
                        continue
                    sub_id = item.get("id") or item.get("subtitleId") or item.get("subId")
                    dl_url = item.get("downloadUrl") or item.get("url") or (f"https://api.subsource.net/api/v1/subtitles/{sub_id}/download" if sub_id else "")
                    rel = item.get("releaseName") or item.get("release_info") or item.get("title") or "SubSource_VI"
                    if dl_url:
                        out.append({
                            "id": str(rel),
                            "title": str(rel),
                            "release_name": str(rel),
                            "url": dl_url,
                            "lang": "vie",
                            "provider": "SubSource",
                            "headers": {"X-API-Key": api_k},
                            "source": "subsource_direct",
                        })
    except Exception:
        pass
    return out


def _fetch_stremio_subtitles_list(imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, title="", year=""):
    import random
    import threading

    s_imdb = str(imdb_id or "").strip()
    s_tmdb = str(tmdb_id or "").replace("tmdb:", "").strip()
    if s_imdb and s_imdb.isdigit() and not s_tmdb:
        s_tmdb = s_imdb
        s_imdb = ""

    if not s_imdb.startswith("tt"):
        s_imdb = resolve_imdb_id_fast(imdb_id=s_imdb, tmdb_id=s_tmdb, title=title, year=year, mtype=mtype)

    has_se = False
    try:
        s_num = int(season) if season not in (None, "", "0", 0) else 0
        e_num = int(episode) if episode not in (None, "", "0", 0) else 0
        has_se = s_num > 0 and e_num > 0
    except Exception:
        s_num, e_num = 0, 0

    is_series = has_se or str(mtype).lower() in ("series", "episode", "tv", "show")

    stremio_targets = []
    if s_imdb.startswith("tt"):
        if is_series and has_se:
            sub_path = f"/subtitles/series/{s_imdb}:{s_num}:{e_num}.json"
        else:
            sub_path = f"/subtitles/movie/{s_imdb}.json"

        stremio_targets.append(f"{AIO_SUB_WORKER}{sub_path}")
        stremio_targets.append(f"https://opensubtitles-v3.strem.io{sub_path}")
        if SUBDL_UPSTREAMS:
            stremio_targets.append(f"{random.choice(SUBDL_UPSTREAMS)}{sub_path}")
        if SUBSOURCE_UPSTREAMS:
            stremio_targets.append(f"{random.choice(SUBSOURCE_UPSTREAMS)}{sub_path}")

    results_box = [[] for _ in range(len(stremio_targets) + 2)]

    def _stremio_worker(idx, u):
        try:
            data = _http_get_json(u, timeout=7)
            if isinstance(data, dict) and isinstance(data.get("subtitles"), list):
                prov = "AIO" if AIO_SUB_WORKER in u else ("OpenSub" if "opensubtitles" in u else ("SubDL" if "subdl" in u else "SubSource"))
                items = []
                for s in data["subtitles"]:
                    if isinstance(s, dict):
                        sc = dict(s)
                        sc.setdefault("provider", prov)
                        items.append(sc)
                results_box[idx] = items
        except Exception:
            pass

    def _subdl_direct_worker(idx):
        results_box[idx] = _fetch_subdl_direct_api(
            vid_id=s_imdb,
            tmdb_id=s_tmdb,
            title=title,
            year=year,
            is_series=is_series,
            s_num=s_num,
            e_num=e_num,
        )

    def _subsource_direct_worker(idx):
        if s_imdb.startswith("tt"):
            results_box[idx] = _fetch_subsource_direct_api(s_imdb, is_series, s_num, e_num)

    threads = [
        threading.Thread(target=_subdl_direct_worker, args=(0,)),
        threading.Thread(target=_subsource_direct_worker, args=(1,)),
    ]
    for i, u in enumerate(stremio_targets):
        threads.append(threading.Thread(target=_stremio_worker, args=(i + 2, u)))

    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(timeout=8)

    collected = []
    for sub_list in results_box:
        if sub_list:
            collected.extend(sub_list)

    seen_urls = set()
    vi_subs = []
    en_subs = []
    for s in collected:
        if not isinstance(s, dict):
            continue
        u = _unwrap_stremio_sub_url(s.get("url") or "")
        if not u or u in seen_urls:
            continue
        seen_urls.add(u)
        s_copy = dict(s)
        s_copy["url"] = u
        lang = str(s_copy.get("lang") or s_copy.get("language") or "vie").lower()
        if any(w in lang for w in ("vi", "vie", "viet", "vn")) or ("subdl.strem.top" in u) or ("subsource.strem.top" in u):
            s_copy["lang"] = "vie"
            vi_subs.append(s_copy)
        elif any(w in lang for w in ("en", "eng", "english")):
            s_copy["lang"] = "eng"
            en_subs.append(s_copy)

    return vi_subs + en_subs[:10]


def _extract_release_features(name_str):
    s = str(name_str or "").lower()
    features = {
        "res": "",
        "source": "",
        "service": "",
        "edition": set(),
        "group": "",
    }
    if any(k in s for k in ("2160p", "4k", "uhd")):
        features["res"] = "2160p"
    elif "1080p" in s:
        features["res"] = "1080p"
    elif "720p" in s:
        features["res"] = "720p"

    if any(k in s for k in ("remux", "bluray", "blu-ray", "bdrip", "brrip", "bdremux")):
        features["source"] = "BluRay"
    elif any(k in s for k in ("web-dl", "webdl", "webrip", "web-rip", ".web.")):
        features["source"] = "WEB"
    elif any(k in s for k in ("hdtv", "pdtv")):
        features["source"] = "HDTV"
    elif any(k in s for k in ("hdcam", "camrip", "hdts", "telesync")):
        features["source"] = "CAM"

    for srv in ("amzn", "nf", "netflix", "dsnp", "atvp", "hmax", "pcok", "hulu", "ip"):
        if re.search(r"\b" + srv + r"\b", s):
            features["service"] = "NF" if srv == "netflix" else srv.upper()
            break

    for ed in ("extended", "imax", "directors.cut", "director's cut", "unrated", "repack", "proper"):
        if ed in s:
            features["edition"].add(ed.split(".")[0].upper())

    clean_no_ext = re.sub(r"\.(mkv|mp4|avi|srt|zip|vtt|ass)$", "", s.strip())
    m_grp = re.search(r"-([a-z0-9]{2,12})(?:\[.*\])?$", clean_no_ext)
    if m_grp:
        grp = m_grp.group(1)
        if grp not in ("dl", "rip", "hd", "sub", "vi", "vie", "x264", "x265", "h264", "h265", "hevc"):
            features["group"] = grp.upper()

    return features


def rank_and_annotate_subtitles(subs_list, filename=""):
    if not subs_list:
        return []
    from difflib import SequenceMatcher

    clean_fn_raw = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(str(filename or "")).path))
    if clean_fn_raw.lower() in ("", "play", "stream", "video", "index.m3u8"):
        clean_fn_raw = str(filename or "")
    file_feat = _extract_release_features(clean_fn_raw)
    norm_fn = re.sub(r"\W+", " ", clean_fn_raw.lower()).strip()

    scored_items = []
    for idx, sub in enumerate(subs_list):
        raw_label = str(
            sub.get("release_name")
            or sub.get("title")
            or sub.get("SubFileName")
            or sub.get("id")
            or f"Phụ đề #{idx + 1}"
        ).strip()
        if raw_label.startswith("http"):
            raw_label = urllib.parse.unquote(os.path.basename(urllib.parse.urlsplit(raw_label).path))

        is_vi = str(sub.get("lang") or "vie").lower() in ("vi", "vie", "vietnamese")
        sub_feat = _extract_release_features(raw_label)
        norm_sub = re.sub(r"\W+", " ", raw_label.lower()).strip()

        score = 0.0
        matched_tags = []

        if clean_fn_raw:
            if file_feat["group"] and sub_feat["group"] and file_feat["group"] == sub_feat["group"]:
                score += 38.0
                matched_tags.append(file_feat["group"])

            if file_feat["source"] and sub_feat["source"]:
                if file_feat["source"] == sub_feat["source"]:
                    score += 28.0
                    matched_tags.append(sub_feat["source"])
                else:
                    score -= 12.0
            elif sub_feat["source"]:
                matched_tags.append(sub_feat["source"])

            if file_feat["service"] and sub_feat["service"] and file_feat["service"] == sub_feat["service"]:
                score += 14.0
                matched_tags.append(sub_feat["service"])

            if file_feat["res"] and sub_feat["res"] and file_feat["res"] == sub_feat["res"]:
                score += 10.0
                matched_tags.append(sub_feat["res"])
            elif sub_feat["res"]:
                matched_tags.append(sub_feat["res"])

            if file_feat["edition"] or sub_feat["edition"]:
                if file_feat["edition"] == sub_feat["edition"]:
                    score += 15.0
                    matched_tags.extend(list(sub_feat["edition"]))
                else:
                    score -= 20.0

            seq_ratio = SequenceMatcher(None, norm_fn, norm_sub).ratio() if (norm_fn and norm_sub) else 0.0
            score += seq_ratio * 25.0
        else:
            if sub_feat["source"]:
                matched_tags.append(sub_feat["source"])
            if sub_feat["res"]:
                matched_tags.append(sub_feat["res"])
            if sub_feat["group"]:
                matched_tags.append(sub_feat["group"])

        if sub.get("source") in ("subdl_direct", "subsource_direct"):
            score += 4.0

        pct = max(12, min(99, int(round(score))))
        lang_priority = 1000.0 if is_vi else 0.0

        if is_vi:
            if pct >= 75:
                rating_5 = "5"
                prefix = f"[COLOR springgreen][🎯 Khớp {pct}%][/COLOR]"
            elif pct >= 45:
                rating_5 = "4"
                prefix = f"[COLOR yellow][⭐ Khớp {pct}%][/COLOR]"
            else:
                rating_5 = "4"
                prefix = f"[COLOR deepskyblue][Tiếng Việt • {pct}%][/COLOR]"
        else:
            rating_5 = "3"
            prefix = f"[COLOR silver][English • {pct}%][/COLOR]"

        provider_str = sub.get("provider") or ("SubDL" if "subdl" in str(sub.get("url", "")) else "SubSource")
        tag_str = f" • {' '.join(matched_tags)}" if matched_tags else ""
        display_label = f"{prefix} [{provider_str}{tag_str}] {raw_label}"

        item_copy = dict(sub)
        item_copy["match_score"] = lang_priority + score
        item_copy["rating_5"] = rating_5
        item_copy["display_label"] = display_label
        item_copy["kodi_lang_name"] = "Vietnamese" if is_vi else "English"
        item_copy["kodi_lang_flag"] = "vi" if is_vi else "en"
        item_copy["sync_flag"] = bool(pct >= 60)
        scored_items.append((lang_priority + score, -idx, item_copy))

    scored_items.sort(reverse=True)
    return [x[2] for x in scored_items]


def _rank_subtitles_for_file(subs_list, filename=""):
    return rank_and_annotate_subtitles(subs_list, filename=filename)


def auto_load_stremio_subtitles(player=None, imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", poster="", title="", year=""):
    save_playing_context(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode, filename=filename, title=title, year=year)
    if not AUTO_DOWNLOAD_SUB_ON_PLAY:
        return False

    try:
        xbmc, _, xbmcgui, xbmcvfs, addon, profile, _ = _get_kodi_objs()
    except Exception:
        return False

    subs = _fetch_stremio_subtitles_list(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode, title=title, year=year)
    if not subs:
        return False

    ranked = rank_and_annotate_subtitles(subs, filename=filename)
    sub_dir = os.path.join(profile, "subtitles_vip")
    os.makedirs(sub_dir, exist_ok=True)
    vid_key = f"{imdb_id or tmdb_id or 'sub'}_{season or 0}_{episode or 0}"
    clean_tag = "".join(c for c in vid_key if c.isalnum() or c == "_")

    for sub_item in ranked[:5]:
        sub_url = str(sub_item.get("url") or "").strip()
        if not sub_url:
            continue
        try:
            raw_bytes = _http_get_bytes(sub_url, extra_headers=sub_item.get("headers"), timeout=8)
            srt_bytes = _extract_srt_from_bytes(raw_bytes, season=season, episode=episode)
            if srt_bytes and len(srt_bytes) > 100:
                local_path = os.path.join(sub_dir, f"SubVIP_{clean_tag}_1.vi.srt")
                with open(local_path, "wb") as f:
                    f.write(srt_bytes)
                if player is None:
                    player = xbmc.Player()
                player.setSubtitles(local_path)
                player.showSubtitles(True)
                return True
        except Exception:
            continue
    return False


def auto_load_stremio_subtitles_async(imdb_id="", tmdb_id="", mtype="movie", season=None, episode=None, filename="", player=None, poster="", title="", year=""):
    save_playing_context(imdb_id=imdb_id, tmdb_id=tmdb_id, mtype=mtype, season=season, episode=episode, filename=filename, title=title, year=year)
    if not AUTO_DOWNLOAD_SUB_ON_PLAY:
        return None
    import threading
    t = threading.Thread(
        target=auto_load_stremio_subtitles,
        kwargs={
            "player": player,
            "imdb_id": imdb_id,
            "tmdb_id": tmdb_id,
            "mtype": mtype,
            "season": season,
            "episode": episode,
            "filename": filename,
            "poster": poster,
            "title": title,
            "year": year,
        },
    )
    t.daemon = True
    t.start()
    return t
