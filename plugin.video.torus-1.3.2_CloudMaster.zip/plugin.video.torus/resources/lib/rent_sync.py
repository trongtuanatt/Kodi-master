# -*- coding: utf-8 -*-
"""
Kodi Cloud Debrid Sync Engine (Auto Time-Based Key Management & Rotation)
Tự động đồng bộ API Key theo thời hạn thuê từ Cloudflare Worker.
"""
import json
import os
import time
import urllib.parse
import urllib.request

ADDON_TYPE = 'torus'
ADDON_ID_MAP = {
    "pov": "plugin.video.pov",
    "torus": "plugin.video.torus",
    "umbrella": "plugin.video.umbrella",
}
ADDON_ID = ADDON_ID_MAP.get(ADDON_TYPE, "plugin.video.pov")
SYNC_CACHE_TTL = 900  # Kiểm tra ngầm mỗi 15 phút (900 giây)


def _clean_srv(url):
    u = (url or "").strip().rstrip("/")
    for s in ("/admin/login", "/admin", "/kodi-sync"):
        if u.lower().endswith(s):
            u = u[:-len(s)].rstrip("/")
    return u


def _get_kodi_objs():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    addon = xbmcaddon.Addon(ADDON_ID)
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    base = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    os.makedirs(profile, exist_ok=True)
    return xbmc, xbmcaddon, xbmcgui, xbmcvfs, addon, profile, base


def _load_config(profile, base):
    cfg = {"server_url": "", "customer_code": ""}
    preset_path = os.path.join(base, "debrid_cloud_config.json")
    if os.path.exists(preset_path):
        try:
            with open(preset_path, "r", encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    if os.path.exists(user_path):
        try:
            with open(user_path, "r", encoding="utf-8") as f:
                u = json.load(f)
                if u.get("server_url"):
                    cfg["server_url"] = u["server_url"]
                if "customer_code" in u and u["customer_code"]:
                    cfg["customer_code"] = u["customer_code"]
        except Exception:
            pass
    cfg["server_url"] = _clean_srv(cfg.get("server_url"))
    return cfg


def _save_user_config(profile, server_url, customer_code, last_state=None):
    user_path = os.path.join(profile, "debrid_cloud_user.json")
    data = {"server_url": _clean_srv(server_url), "customer_code": customer_code.strip().lower()}
    if last_state is not None:
        data["last_state"] = last_state
    try:
        with open(user_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def get_customer_code():
    try:
        _, _, _, _, _, profile, base = _get_kodi_objs()
        cfg = _load_config(profile, base)
        return (cfg.get("customer_code") or "").strip()
    except Exception:
        return ""


def _apply_keys_to_addon(addon, profile, xbmcgui, keys_map):
    """Ghi hoặc thu hồi (xóa trắng) API Key trên từng loại Addon."""
    tb = (keys_map.get("torbox") or "").strip()
    rd = (keys_map.get("realdebrid") or "").strip()
    ad = (keys_map.get("alldebrid") or "").strip()
    pm = (keys_map.get("premiumize") or "").strip()
    oc = (keys_map.get("offcloud") or "").strip()

    if ADDON_TYPE == "pov":
        pairs = [
            ("tb.token", tb), ("tb.enabled", "true" if tb else "false"),
            ("rd.token", rd), ("rd.enabled", "true" if rd else "false"),
            ("ad.token", ad), ("ad.enabled", "true" if ad else "false"),
            ("pm.token", pm), ("pm.enabled", "true" if pm else "false"),
            ("oc.token", oc), ("oc.enabled", "true" if oc else "false"),
        ]
        changed = False
        for k, v in pairs:
            if addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed:
            xbmcgui.Window(10000).clearProperty("pov_settings")
            try:
                from modules import kodi_utils
                kodi_utils.make_settings_dict()
            except Exception:
                pass

    elif ADDON_TYPE == "torus":
        if addon.getSetting("torbox_api_key") != tb:
            addon.setSetting("torbox_api_key", tb)
        tok_file = os.path.join(profile, "torbox_token.json")
        if tb:
            try:
                with open(tok_file, "w", encoding="utf-8") as f:
                    json.dump({"token": tb}, f)
            except Exception:
                pass
        else:
            try:
                if os.path.exists(tok_file):
                    os.remove(tok_file)
            except Exception:
                pass

    elif ADDON_TYPE == "umbrella":
        pairs = [
            ("torboxtoken", tb), ("torbox.enable", "true" if tb else "false"),
            ("realdebridtoken", rd), ("realdebrid.enable", "true" if rd else "false"),
            ("alldebridtoken", ad), ("alldebrid.enable", "true" if ad else "false"),
            ("premiumizetoken", pm), ("premiumize.enable", "true" if pm else "false"),
            ("offcloudtoken", oc), ("offcloud.enable", "true" if oc else "false"),
        ]
        changed = False
        for k, v in pairs:
            if addon.getSetting(k) != v:
                addon.setSetting(k, v)
                changed = True
        if changed:
            xbmcgui.Window(10000).clearProperty("umbrella_settings")


def sync_now(force=False, interactive=False, force_rotate=False):
    """Đồng bộ API key với Cloudflare Worker."""
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    win = xbmcgui.Window(10000)
    prop_ts = f"{ADDON_ID}.rent_sync_ts"
    now = time.time()

    if not force and not interactive and not force_rotate:
        last_ts = float(win.getProperty(prop_ts) or "0")
        if now - last_ts < SYNC_CACHE_TTL:
            return True

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url"))
    customer_code = (cfg.get("customer_code") or "").strip().lower()

    if not server_url:
        if interactive:
            xbmcgui.Dialog().ok("Chưa cấu hình Server", "Add-on chưa có địa chỉ Server quản lý.")
        return False

    if not customer_code:
        if interactive:
            return prompt_and_activate()
        return False

    q = urllib.parse.urlencode({
        "user": customer_code,
        "addon": ADDON_TYPE,
        "force_rotate": "1" if force_rotate else "0",
    })
    url = f"{server_url}/kodi-sync?{q}"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Kodi-CloudSync/5.0", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        if interactive:
            xbmcgui.Dialog().notification("VIP Debrid", "Không thể kết nối Server kiểm tra hạn!", xbmcgui.NOTIFICATION_WARNING, 4000)
        return False

    win.setProperty(prop_ts, str(now))
    keys_map = data.get("keys") or {}
    ok = bool(data.get("ok"))
    status = data.get("status") or ""
    msg = data.get("message") or ""
    warn = data.get("warning") or ""

    if ok:
        _apply_keys_to_addon(addon, profile, xbmcgui, keys_map)
        _save_user_config(profile, server_url, customer_code, last_state=data)
        if interactive:
            xbmcgui.Dialog().ok("Kích hoạt VIP Debrid thành công", msg)
        elif warn:
            warn_prop = f"{ADDON_ID}.warn_shown"
            if not win.getProperty(warn_prop):
                win.setProperty(warn_prop, "1")
                xbmcgui.Dialog().notification("Sắp hết hạn VIP", warn, xbmcgui.NOTIFICATION_WARNING, 6000)
        return True
    else:
        # Hết hạn, bị khóa hoặc mã sai -> Tự động xóa sạch key trên Kodi để ngắt quyền xem
        empty_keys = {"torbox": "", "realdebrid": "", "alldebrid": "", "premiumize": "", "offcloud": ""}
        _apply_keys_to_addon(addon, profile, xbmcgui, empty_keys)
        _save_user_config(profile, server_url, customer_code, last_state=data)
        if interactive or status in ("expired", "locked"):
            xbmcgui.Dialog().ok("Thông báo Tài khoản VIP", msg or "Gói dịch vụ đã hết hạn hoặc tạm khóa.")
        return False


def prompt_and_activate():
    """Hộp thoại trên TV/Kodi cho phép khách nhập Mã khách hàng, Đổi Key mới hoặc Xem hạn dùng."""
    try:
        xbmc, _, xbmcgui, _, addon, profile, base = _get_kodi_objs()
    except Exception:
        return False

    cfg = _load_config(profile, base)
    server_url = _clean_srv(cfg.get("server_url"))
    current_code = (cfg.get("customer_code") or "").strip()

    if current_code:
        choices = [
            f"🔄 Đồng bộ & Kiểm tra hạn dùng (Mã: {current_code})",
            "🔀 Đổi sang Key VIP khác (Nếu xem phim bị lỗi nguồn)",
            "🔑 Nhập Mã khách hàng (PIN) khác",
        ]
        sel = xbmcgui.Dialog().select("Quản lý Tài khoản VIP Debrid", choices)
        if sel < 0:
            return False
        if sel == 0:
            return sync_now(force=True, interactive=True, force_rotate=False)
        if sel == 1:
            return sync_now(force=True, interactive=True, force_rotate=True)

    new_code = xbmcgui.Dialog().input(
        "Nhập Mã kích hoạt VIP (Admin cấp)",
        defaultt=current_code,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not new_code or not new_code.strip():
        return False

    if not server_url:
        srv = xbmcgui.Dialog().input("Nhập địa chỉ Server (https://...)", type=xbmcgui.INPUT_ALPHANUM)
        if not srv:
            return False
        server_url = _clean_srv(srv)

    _save_user_config(profile, server_url, new_code.strip().lower())
    ok = sync_now(force=True, interactive=True, force_rotate=False)
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass
    return ok
