# -*- coding: utf-8 -*-
import sys
from resources.lib import rent_sync
if __name__ == '__main__':
    rent_sync.handle_kodi_subtitle_module(sys.argv)
